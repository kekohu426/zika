
  # CreaTA AI Tool (Copy)

  This is a code bundle for CreaTA AI Tool (Copy). The original project is available at https://www.figma.com/design/iDwb6Fbxn7USF4zP5AHSYg/CreaTA-AI-Tool--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  