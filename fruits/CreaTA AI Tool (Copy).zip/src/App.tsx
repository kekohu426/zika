import { useState, useEffect } from "react"
import Auth from "./components/Auth"
import ProfileSetup from "./components/ProfileSetup"
import ProfileManager from "./components/ProfileManager"

import Sidebar from "./components/Sidebar"
import ContentGenerator from "./components/ContentGenerator"
import DocumentManager from "./components/DocumentManager"
import UpgradePro from "./components/UpgradePro"
import Settings from "./components/Settings"
import AICommunity from "./components/AICommunity"
import KnowledgeBase from "./components/KnowledgeBase"
import Analytics from "./components/Analytics"
import { Toaster } from "./components/ui/sonner"

interface UserData {
  id: string
  email: string
  name: string
  isNewUser: boolean
  profiles: ProfileData[]
}

interface ProfileData {
  id: string
  name: string
  nickname: string
  coreIdentity: string
  oldIdentity: string
  newIdentity: string
  targetPlatform: string[]
  audienceA: string
  audienceB: string
  creatorValue: string
  contentPillar1: string
  contentPillar2: string
  contentPillar3: string
  commonQuestions: string[]
  proudAchievements: string[]
  avoidTags: string[]
  coreValues: string
  sensitiveWords: string[]
  products: string[]
  createdAt: string
  lastUsed: string
  isActive: boolean
}

export default function App() {
  const [user, setUser] = useState<UserData | null>(null)
  const [activeProfile, setActiveProfile] = useState<ProfileData | null>(null)
  const [showProfileSetup, setShowProfileSetup] = useState(false)
  const [showProfileManager, setShowProfileManager] = useState(false)
  const [activeTab, setActiveTab] = useState('generator')

  // 載入本地儲存的用戶資料和檔案
  useEffect(() => {
    const savedUser = localStorage.getItem('creata_user')
    const savedProfiles = localStorage.getItem('creata_profiles')
    const savedActiveProfile = localStorage.getItem('creata_active_profile')

    if (savedUser) {
      const userData = JSON.parse(savedUser)
      setUser(userData)
      
      if (savedProfiles) {
        const profiles = JSON.parse(savedProfiles)
        setUser(prev => ({ ...prev!, profiles }))
        
        if (savedActiveProfile) {
          const activeProfileData = JSON.parse(savedActiveProfile)
          setActiveProfile(activeProfileData)
        }
      }
    }
  }, [])

  const handleLogin = (userData: UserData) => {
    setUser(userData)
    localStorage.setItem('creata_user', JSON.stringify(userData))
    
    // 如果是新用戶且沒有檔案，顯示檔案設定
    if (userData.isNewUser && userData.profiles.length === 0) {
      setShowProfileSetup(true)
    }
  }

  const handleProfileSetupComplete = (profileData: any) => {
    const newProfile: ProfileData = {
      ...profileData,
      id: 'profile_' + Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toLocaleDateString('zh-HK'),
      lastUsed: new Date().toLocaleDateString('zh-HK'),
      isActive: true
    }

    const updatedProfiles = [...(user?.profiles || []), newProfile]
    const updatedUser = { ...user!, profiles: updatedProfiles, isNewUser: false }
    
    setUser(updatedUser)
    setActiveProfile(newProfile)
    setShowProfileSetup(false)
    
    // 儲存到本地儲存
    localStorage.setItem('creata_user', JSON.stringify(updatedUser))
    localStorage.setItem('creata_profiles', JSON.stringify(updatedProfiles))
    localStorage.setItem('creata_active_profile', JSON.stringify(newProfile))
  }

  const handleProfileSetupSkip = () => {
    setShowProfileSetup(false)
    const updatedUser = { ...user!, isNewUser: false }
    setUser(updatedUser)
    localStorage.setItem('creata_user', JSON.stringify(updatedUser))
  }

  const handleProfileSelect = (profile: ProfileData) => {
    const updatedProfile = { ...profile, lastUsed: new Date().toLocaleDateString('zh-HK') }
    setActiveProfile(updatedProfile)
    
    // 更新檔案的最後使用時間
    const updatedProfiles = user!.profiles.map(p => 
      p.id === profile.id ? updatedProfile : p
    )
    const updatedUser = { ...user!, profiles: updatedProfiles }
    setUser(updatedUser)
    
    localStorage.setItem('creata_profiles', JSON.stringify(updatedProfiles))
    localStorage.setItem('creata_active_profile', JSON.stringify(updatedProfile))
    setShowProfileManager(false)
  }

  const handleProfileCreate = () => {
    setShowProfileSetup(true)
    setShowProfileManager(false)
  }

  const handleProfileEdit = (profile: ProfileData) => {
    // TODO: 實現編輯功能
    console.log('Edit profile:', profile.id)
  }

  const handleProfileDelete = (profileId: string) => {
    const updatedProfiles = user!.profiles.filter(p => p.id !== profileId)
    const updatedUser = { ...user!, profiles: updatedProfiles }
    setUser(updatedUser)
    
    // 如果刪除的是目前活躍檔案，清除活躍檔案
    if (activeProfile?.id === profileId) {
      setActiveProfile(null)
      localStorage.removeItem('creata_active_profile')
    }
    
    localStorage.setItem('creata_profiles', JSON.stringify(updatedProfiles))
  }

  const handleProfileDuplicate = (profile: ProfileData) => {
    const duplicatedProfile: ProfileData = {
      ...profile,
      id: 'profile_' + Math.random().toString(36).substr(2, 9),
      name: profile.name + ' 副本',
      createdAt: new Date().toLocaleDateString('zh-HK'),
      lastUsed: new Date().toLocaleDateString('zh-HK'),
      isActive: false
    }

    const updatedProfiles = [...user!.profiles, duplicatedProfile]
    const updatedUser = { ...user!, profiles: updatedProfiles }
    setUser(updatedUser)
    
    localStorage.setItem('creata_profiles', JSON.stringify(updatedProfiles))
  }

  const renderContent = () => {
    if (showProfileManager) {
      return (
        <ProfileManager
          profiles={user?.profiles || []}
          activeProfile={activeProfile}
          onProfileSelect={handleProfileSelect}
          onProfileCreate={handleProfileCreate}
          onProfileEdit={handleProfileEdit}
          onProfileDelete={handleProfileDelete}
          onProfileDuplicate={handleProfileDuplicate}
        />
      )
    }

    switch (activeTab) {
      case 'generator':
        return <ContentGenerator activeProfile={activeProfile} />
      case 'documents':
        return <DocumentManager activeProfile={activeProfile} />
      case 'community':
        return <AICommunity activeProfile={activeProfile} />

      case 'knowledge':
        return <KnowledgeBase />

      case 'upgrade':
        return <UpgradePro />
      case 'settings':
        if (!user) {
          return <div>Loading...</div>
        }
        return (
          <Settings
            user={user}
            activeProfile={activeProfile}
            profiles={user.profiles || []}
            onUserUpdate={(updatedUser) => {
              setUser(updatedUser)
              localStorage.setItem('creata_user', JSON.stringify(updatedUser))
            }}
            onProfileSelect={handleProfileSelect}
            onProfileCreate={handleProfileCreate}
            onProfileEdit={handleProfileEdit}
            onProfileDelete={handleProfileDelete}
            onProfileDuplicate={handleProfileDuplicate}
            onLogout={() => {
              setUser(null)
              setActiveProfile(null)
              localStorage.removeItem('creata_user')
              localStorage.removeItem('creata_profiles')
              localStorage.removeItem('creata_active_profile')
            }}
          />
        )
      case 'analytics':
        return <Analytics />
      default:
        return <ContentGenerator activeProfile={activeProfile} />
    }
  }

  // 如果未登入，顯示登入界面
  if (!user) {
    return <Auth onLogin={handleLogin} />
  }

  // 如果需要設定檔案，顯示檔案設定界面
  if (showProfileSetup) {
    return (
      <ProfileSetup
        userData={user}
        onComplete={handleProfileSetupComplete}
        onSkip={handleProfileSetupSkip}
      />
    )
  }

  return (
    <>
      <div className="h-screen flex bg-background relative overflow-hidden">
        {/* Background elements */}
        <div className="absolute inset-0 neural-pattern opacity-20"></div>
        <div className="absolute top-0 right-0 w-96 h-96 gradient-ai opacity-5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 gradient-primary opacity-5 rounded-full blur-3xl"></div>
        
        <div className="relative z-10 flex w-full h-full min-h-0">
        <Sidebar 
          activeTab={activeTab} 
          onTabChange={(tab) => {
            setActiveTab(tab)
            setShowProfileManager(false)
          }}
          user={user}
          activeProfile={activeProfile}
          profiles={user?.profiles || []}
          onProfileSelect={handleProfileSelect}
          onProfileCreate={() => setShowProfileSetup(true)}
          onProfileEdit={handleProfileEdit}
          onProfileDelete={handleProfileDelete}
          onProfileDuplicate={handleProfileDuplicate}
          onLogout={() => {
            setUser(null)
            setActiveProfile(null)
            localStorage.removeItem('creata_user')
            localStorage.removeItem('creata_profiles')
            localStorage.removeItem('creata_active_profile')
          }}
        />
        
        <main className="flex-1 bg-background-secondary/50 scrollbar-apple" style={{ minHeight: 0 }}>
          {(activeTab === 'documents') ? (
            <div className="h-full w-full">
              {renderContent()}
            </div>
          ) : (
            <div className="h-full overflow-auto">
              <div className="max-w-7xl mx-auto p-6 lg:p-8">
                {renderContent()}
              </div>
            </div>
          )}
        </main>
        </div>
      </div>
      <Toaster />
    </>
  )
}