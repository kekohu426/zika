import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Input } from "./ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { ImageWithFallback } from "./figma/ImageWithFallback"
import AIProjectManager from "./AIProjectManager"
import { 
  Search, 
  Users, 
  Star, 
  MessageCircle, 
  Plus,
  Filter,
  TrendingUp,
  Clock,
  Zap,
  Bot,
  User,
  Settings,
  PlayCircle,
  Pause,
  CheckCircle,
  Rocket
} from "lucide-react"

interface AICommunityProps {
  activeProfile?: any
}

export default function AICommunity({ activeProfile }: AICommunityProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const categories = [
    { id: "all", label: "全部", count: 156 },
    { id: "content", label: "內容創作", count: 45 },
    { id: "design", label: "設計美化", count: 32 },
    { id: "analysis", label: "數據分析", count: 28 },
    { id: "automation", label: "自動化", count: 51 }
  ]

  const aiAgents = [
    {
      id: 1,
      name: "小紅書文案大師",
      description: "專業產生小紅書爆款文案，擅長各種風格的內容創作",
      category: "content",
      rating: 4.9,
      users: 12567,
      price: "免費",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=400&fit=crop",
      tags: ["文案產生", "小紅書", "營銷"],
      featured: true,
      author: {
        name: "AI創作工坊",
        avatar: ""
      }
    },
    {
      id: 2,
      name: "視覺設計助手",
      description: "自動產生封面圖和配圖，支援多種設計風格",
      category: "design",
      rating: 4.7,
      users: 8934,
      price: "¥29/月",
      image: "https://images.unsplash.com/photo-1675703817777-e5f48ed78f40?w=400&h=400&fit=crop",
      tags: ["圖像設計", "封面製作", "UI設計"],
      featured: false,
      author: {
        name: "設計師小王",
        avatar: ""
      }
    },
    {
      id: 3,
      name: "數據洞察專家",
      description: "深度分析內容表現，提供優化建議和趨勢預測",
      category: "analysis",
      rating: 4.8,
      users: 5623,
      price: "¥49/月",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=400&fit=crop",
      tags: ["數據分析", "趨勢預測", "優化建議"],
      featured: true,
      author: {
        name: "數據科學團隊",
        avatar: ""
      }
    },
    {
      id: 4,
      name: "品牌策略顧問",
      description: "制定個人IP品牌策略，提升影響力和商業價值",
      category: "content",
      rating: 4.6,
      users: 3456,
      price: "¥99/月",
      image: "https://images.unsplash.com/photo-1566314748563-31d8ce08123b?w=400&h=400&fit=crop",
      tags: ["品牌策略", "IP打造", "商業變現"],
      featured: false,
      author: {
        name: "品牌專家",
        avatar: ""
      }
    }
  ]

  const myProjects = [
    {
      id: 1,
      name: "美妝內容自動產生",
      description: "自動產生美妝產品推薦文案和配圖",
      agents: ["小紅書文案大師", "視覺設計助手"],
      status: "運行中",
      lastRun: "2小時前",
      successRate: 95
    },
    {
      id: 2,
      name: "科技產品評測流程",
      description: "從產品分析到文案產生的完整自動化流程",
      agents: ["數據洞察專家", "小紅書文案大師"],
      status: "已暫停",
      lastRun: "1天前",
      successRate: 88
    },
    {
      id: 3,
      name: "生活方式內容策劃",
      description: "基於用戶畫像產生個人化生活方式內容",
      agents: ["品牌策略顧問", "小紅書文案大師", "視覺設計助手"],
      status: "已完成",
      lastRun: "3天前",
      successRate: 92
    }
  ]

  const filteredAgents = aiAgents.filter(agent => {
    const matchesSearch = agent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         agent.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || agent.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="flex items-center space-x-2">
            <Users className="w-6 h-6 text-purple-600" />
            <span>AI 社群</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            發現和使用專業的AI助手，構建您的自動化工作流
          </p>
        </div>
        <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          建立AI助手
        </Button>
      </div>

      <Tabs defaultValue="marketplace" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-lg">
          <TabsTrigger value="marketplace">AI 市場</TabsTrigger>
          <TabsTrigger value="projects">我的項目</TabsTrigger>
          <TabsTrigger value="ai-projects">AI項目管理</TabsTrigger>
        </TabsList>

        <TabsContent value="marketplace" className="space-y-6">
          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="搜尋AI助手..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              篩選
            </Button>
          </div>

          {/* Categories */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className="h-8"
              >
                {category.label}
                <Badge variant="secondary" className="ml-2 text-xs">
                  {category.count}
                </Badge>
              </Button>
            ))}
          </div>

          {/* Featured Agents */}
          <div className="space-y-4">
            <h3 className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              <span>精選推薦</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAgents.filter(agent => agent.featured).map((agent) => (
                <Card key={agent.id} className="hover:shadow-lg transition-shadow border-2 border-transparent hover:border-purple-200">
                  <CardContent className="p-0">
                    <div className="relative">
                      <div className="aspect-video overflow-hidden rounded-t-lg">
                        <ImageWithFallback
                          src={agent.image}
                          alt={agent.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <Badge className="absolute top-2 right-2 bg-orange-500 hover:bg-orange-600">
                        精選
                      </Badge>
                    </div>
                    <div className="p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1 flex-1">
                          <h4 className="font-semibold">{agent.name}</h4>
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {agent.description}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-1">
                        {agent.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span>{agent.rating}</span>
                          </div>
                          <div className="flex items-center space-x-1 text-muted-foreground">
                            <Users className="w-4 h-4" />
                            <span>{agent.users.toLocaleString()}</span>
                          </div>
                        </div>
                        <span className="font-semibold text-purple-600">{agent.price}</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Avatar className="w-6 h-6">
                            <AvatarFallback className="text-xs">
                              {agent.author.name.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-muted-foreground">
                            {agent.author.name}
                          </span>
                        </div>
                        <Button size="sm" className="h-8">
                          <Plus className="w-4 h-4 mr-1" />
                          加入
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* All Agents */}
          <div className="space-y-4">
            <h3 className="flex items-center space-x-2">
              <Bot className="w-5 h-5 text-blue-500" />
              <span>全部AI助手</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAgents.filter(agent => !agent.featured).map((agent) => (
                <Card key={agent.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-0">
                    <div className="aspect-video overflow-hidden rounded-t-lg">
                      <ImageWithFallback
                        src={agent.image}
                        alt={agent.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-4 space-y-3">
                      <div className="space-y-1">
                        <h4 className="font-semibold">{agent.name}</h4>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {agent.description}
                        </p>
                      </div>
                      
                      <div className="flex flex-wrap gap-1">
                        {agent.tags.slice(0, 2).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span>{agent.rating}</span>
                          </div>
                          <div className="flex items-center space-x-1 text-muted-foreground">
                            <Users className="w-4 h-4" />
                            <span>{agent.users.toLocaleString()}</span>
                          </div>
                        </div>
                        <span className="font-semibold text-purple-600">{agent.price}</span>
                      </div>

                      <Button size="sm" variant="outline" className="w-full">
                        <Plus className="w-4 h-4 mr-1" />
                        加入項目
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="projects" className="space-y-6">
          {/* My Projects Header */}
          <div className="flex items-center justify-between">
            <div>
              <h3 className="flex items-center space-x-2">
                <User className="w-5 h-5 text-green-500" />
                <span>我的自動化項目</span>
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                管理您的AI自動化工作流程
              </p>
            </div>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              新建項目
            </Button>
          </div>

          {/* Projects List */}
          <div className="space-y-4">
            {myProjects.map((project) => (
              <Card key={project.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-3 flex-1">
                      <div className="flex items-center space-x-3">
                        <h4 className="font-semibold">{project.name}</h4>
                        <Badge 
                          variant={
                            project.status === '運行中' ? 'default' :
                            project.status === '已暫停' ? 'secondary' : 'outline'
                          }
                          className="text-xs"
                        >
                          {project.status === '運行中' && <PlayCircle className="w-3 h-3 mr-1" />}
                          {project.status === '已暫停' && <Pause className="w-3 h-3 mr-1" />}
                          {project.status === '已完成' && <CheckCircle className="w-3 h-3 mr-1" />}
                          {project.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {project.description}
                      </p>
                      
                      <div className="space-y-2">
                        <div className="text-sm text-muted-foreground">使用的AI助手:</div>
                        <div className="flex flex-wrap gap-2">
                          {project.agents.map((agent, index) => (
                            <div key={index} className="flex items-center space-x-2 bg-muted/50 rounded-full px-3 py-1">
                              <Bot className="w-4 h-4 text-purple-600" />
                              <span className="text-sm">{agent}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                        <div className="flex items-center space-x-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="text-muted-foreground">最後運行:</span>
                          <span>{project.lastRun}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <TrendingUp className="w-4 h-4 text-green-500" />
                          <span className="text-muted-foreground">成功率:</span>
                          <span className="text-green-600 font-medium">{project.successRate}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col space-y-2 ml-4">
                      <Button variant="outline" size="sm">
                        <Settings className="w-4 h-4 mr-1" />
                        設定
                      </Button>
                      {project.status === '運行中' ? (
                        <Button variant="outline" size="sm">
                          <Pause className="w-4 h-4 mr-1" />
                          暫停
                        </Button>
                      ) : (
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          <PlayCircle className="w-4 h-4 mr-1" />
                          運行
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ai-projects">
          <AIProjectManager activeProfile={activeProfile} />
        </TabsContent>
      </Tabs>
    </div>
  )
}