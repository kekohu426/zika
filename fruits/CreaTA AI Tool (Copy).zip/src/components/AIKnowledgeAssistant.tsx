import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Input } from "./ui/input"
import { Textarea } from "./ui/textarea"
import { Progress } from "./ui/progress"
import { 
  Bot, 
  Sparkles, 
  Brain,
  Wand2,
  TrendingUp,
  Search,
  Lightbulb,
  Target,
  ArrowRight,
  CheckCircle,
  Clock,
  Zap
} from "lucide-react"

interface Suggestion {
  id: string
  type: 'content' | 'connection' | 'tag' | 'optimization'
  title: string
  description: string
  confidence: number
  impact: 'high' | 'medium' | 'low'
  estimatedTime: string
  category: string
}

interface KnowledgeAnalysis {
  completeness: number
  connectivity: number
  diversity: number
  growth: number
}

export default function AIKnowledgeAssistant() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [query, setQuery] = useState("")
  const [selectedSuggestion, setSelectedSuggestion] = useState<string | null>(null)

  const knowledgeAnalysis: KnowledgeAnalysis = {
    completeness: 78,
    connectivity: 85,
    diversity: 72,
    growth: 92
  }

  const suggestions: Suggestion[] = [
    {
      id: "1",
      type: "content",
      title: "补充科技评测内容",
      description: "AI发现您的科技产品评测内容较少，建议添加更多手机、电脑等产品评测文案模板",
      confidence: 0.89,
      impact: "high",
      estimatedTime: "2小时",
      category: "内容扩充"
    },
    {
      id: "2", 
      type: "connection",
      title: "建立美妆与心理学关联",
      description: "您的美妆内容可以与消费心理学建立更深层次的连接，提升内容深度",
      confidence: 0.76,
      impact: "medium",
      estimatedTime: "1小时",
      category: "关联优化"
    },
    {
      id: "3",
      type: "tag",
      title: "优化标签分类体系",
      description: "当前标签可以更加细分，建议创建二级标签以提升内容发现效率",
      confidence: 0.82,
      impact: "medium", 
      estimatedTime: "30分钟",
      category: "结构优化"
    },
    {
      id: "4",
      type: "optimization",
      title: "创建营销策略专题",
      description: "您的文案技巧可以整合成营销策略专题，形成更系统的知识体系",
      confidence: 0.91,
      impact: "high",
      estimatedTime: "1.5小时",
      category: "体系建设"
    }
  ]

  const recentActivities = [
    {
      type: "auto_tag",
      description: "为'口红试色文案'自动添加了3个相关标签",
      time: "5分钟前",
      status: "completed"
    },
    {
      type: "connection",
      description: "发现'用户心理'与'美妆文案'的潜在关联",
      time: "10分钟前", 
      status: "pending"
    },
    {
      type: "analysis",
      description: "完成知识库结构分析，发现2个优化机会",
      time: "15分钟前",
      status: "completed"
    }
  ]

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-red-600 bg-red-100'
      case 'medium': return 'text-yellow-600 bg-yellow-100'
      case 'low': return 'text-green-600 bg-green-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  const runAnalysis = async () => {
    setIsAnalyzing(true)
    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 3000))
    setIsAnalyzing(false)
  }

  const applySuggestion = (suggestionId: string) => {
    setSelectedSuggestion(suggestionId)
    // Simulate applying suggestion
    setTimeout(() => {
      setSelectedSuggestion(null)
    }, 2000)
  }

  return (
    <div className="space-y-6">
      {/* AI Assistant Header */}
      <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-purple-700">AI 知识助手</h3>
                <p className="text-sm text-purple-600">智能分析您的知识库，提供个性化优化建议</p>
              </div>
            </div>
            <Button 
              onClick={runAnalysis}
              disabled={isAnalyzing}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {isAnalyzing ? (
                <>
                  <Brain className="w-4 h-4 mr-2 animate-pulse" />
                  分析中...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  开始分析
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Knowledge Analysis */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center space-x-2">
                <TrendingUp className="w-4 h-4" />
                <span>知识库健康度</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>内容完整性</span>
                    <span className="font-medium">{knowledgeAnalysis.completeness}%</span>
                  </div>
                  <Progress value={knowledgeAnalysis.completeness} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>内容关联度</span>
                    <span className="font-medium">{knowledgeAnalysis.connectivity}%</span>
                  </div>
                  <Progress value={knowledgeAnalysis.connectivity} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>内容多样性</span>
                    <span className="font-medium">{knowledgeAnalysis.diversity}%</span>
                  </div>
                  <Progress value={knowledgeAnalysis.diversity} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>成长潜力</span>
                    <span className="font-medium">{knowledgeAnalysis.growth}%</span>
                  </div>
                  <Progress value={knowledgeAnalysis.growth} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Smart Query */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center space-x-2">
                <Search className="w-4 h-4" />
                <span>智能查询</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Textarea 
                placeholder="问我任何关于知识库的问题，例如：'如何提升美妆文案的转化率？'"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="h-20 text-sm"
              />
              <Button size="sm" className="w-full">
                <Brain className="w-4 h-4 mr-2" />
                AI 解答
              </Button>
            </CardContent>
          </Card>

          {/* Recent AI Activities */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>最近活动</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-start space-x-3 text-sm">
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    activity.status === 'completed' ? 'bg-green-500' : 'bg-yellow-500'
                  }`} />
                  <div className="flex-1">
                    <p className="text-muted-foreground">{activity.description}</p>
                    <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* AI Suggestions */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Lightbulb className="w-5 h-5 text-yellow-500" />
                <span>智能建议</span>
                <Badge variant="secondary" className="text-xs">
                  {suggestions.length} 条建议
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {suggestions.map((suggestion) => (
                <Card key={suggestion.id} className="border-l-4 border-l-purple-500">
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2 flex-1">
                          <div className="flex items-center space-x-2">
                            <h4 className="font-medium">{suggestion.title}</h4>
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${getImpactColor(suggestion.impact)}`}
                            >
                              {suggestion.impact === 'high' ? '高影响' : 
                               suggestion.impact === 'medium' ? '中影响' : '低影响'}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {suggestion.description}
                          </p>
                          <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                            <div className="flex items-center space-x-1">
                              <Target className="w-3 h-3" />
                              <span>置信度: {Math.round(suggestion.confidence * 100)}%</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Clock className="w-3 h-3" />
                              <span>预计用时: {suggestion.estimatedTime}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col space-y-2 ml-4">
                          <Badge variant="secondary" className="text-xs">
                            {suggestion.category}
                          </Badge>
                          <Button 
                            size="sm" 
                            onClick={() => applySuggestion(suggestion.id)}
                            disabled={selectedSuggestion === suggestion.id}
                            className="h-8"
                          >
                            {selectedSuggestion === suggestion.id ? (
                              <>
                                <CheckCircle className="w-4 h-4 mr-1" />
                                已应用
                              </>
                            ) : (
                              <>
                                <ArrowRight className="w-4 h-4 mr-1" />
                                应用
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>

          {/* Auto Actions */}
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-blue-700">
                <Wand2 className="w-5 h-5" />
                <span>自动化操作</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Button variant="outline" className="justify-start h-auto p-3 bg-white/50">
                  <div className="flex items-center space-x-3">
                    <Zap className="w-5 h-5 text-blue-600" />
                    <div className="text-left">
                      <div className="font-medium text-sm">智能标签生成</div>
                      <div className="text-xs text-muted-foreground">自动为内容生成相关标签</div>
                    </div>
                  </div>
                </Button>
                
                <Button variant="outline" className="justify-start h-auto p-3 bg-white/50">
                  <div className="flex items-center space-x-3">
                    <Brain className="w-5 h-5 text-purple-600" />
                    <div className="text-left">
                      <div className="font-medium text-sm">关联发现</div>
                      <div className="text-xs text-muted-foreground">发现内容间的潜在关联</div>
                    </div>
                  </div>
                </Button>
                
                <Button variant="outline" className="justify-start h-auto p-3 bg-white/50">
                  <div className="flex items-center space-x-3">
                    <Target className="w-5 h-5 text-green-600" />
                    <div className="text-left">
                      <div className="font-medium text-sm">内容推荐</div>
                      <div className="text-xs text-muted-foreground">推荐相关的创作素材</div>
                    </div>
                  </div>
                </Button>
                
                <Button variant="outline" className="justify-start h-auto p-3 bg-white/50">
                  <div className="flex items-center space-x-3">
                    <Sparkles className="w-5 h-5 text-yellow-600" />
                    <div className="text-left">
                      <div className="font-medium text-sm">质量评估</div>
                      <div className="text-xs text-muted-foreground">评估内容质量和完整性</div>
                    </div>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}