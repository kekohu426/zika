import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Input } from "./ui/input"
import { Textarea } from "./ui/textarea"
import { Label } from "./ui/label"
import { Progress } from "./ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import AIProjectTemplates from "./AIProjectTemplates"
import { 
  Bot,
  Users,
  Calendar,
  Clock,
  Target,
  CheckCircle2,
  Circle,
  AlertCircle,
  Plus,
  Settings,
  GitBranch,
  Zap,
  ArrowRight,
  Play,
  Pause,
  MoreVertical,
  User,
  MessageSquare,
  FileText,
  Lightbulb,
  Search,
  Brain,
  Rocket,
  TrendingUp
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select"

interface Task {
  id: string
  title: string
  description: string
  status: 'pending' | 'in-progress' | 'completed' | 'blocked'
  priority: 'low' | 'medium' | 'high'
  assignee?: string
  dueDate: string
  estimatedHours: number
  dependencies: string[]
  category: string
  aiSuggestions: string[]
}

interface Project {
  id: string
  title: string
  description: string
  type: 'content-creation' | 'brand-building' | 'audience-growth' | 'product-launch'
  status: 'planning' | 'active' | 'paused' | 'completed'
  progress: number
  createdAt: string
  deadline: string
  tasks: Task[]
  team: string[]
  aiAnalysis: {
    complexity: 'simple' | 'medium' | 'complex'
    estimatedDuration: string
    riskFactors: string[]
    successMetrics: string[]
    recommendedResources: string[]
  }
}

interface AIProjectManagerProps {
  activeProfile?: any
}

export default function AIProjectManager({ activeProfile }: AIProjectManagerProps) {
  const [showTemplates, setShowTemplates] = useState(false)
  const [projects, setProjects] = useState<Project[]>([
    {
      id: 'proj_1',
      title: '小紅書美妝博主內容矩陣',
      description: '為美妝博主打造3個月內容創作計劃，包含產品測評、護膚教學、美妝技巧等內容支柱',
      type: 'content-creation',
      status: 'active',
      progress: 65,
      createdAt: '2024-01-15',
      deadline: '2024-04-15',
      team: ['AI助手', '內容策劃師', '設計師'],
      tasks: [
        {
          id: 'task_1',
          title: '受眾分析與定位',
          description: '分析目標受眾特徵，定義內容調性和風格',
          status: 'completed',
          priority: 'high',
          assignee: 'AI助手',
          dueDate: '2024-01-20',
          estimatedHours: 8,
          dependencies: [],
          category: '策略規劃',
          aiSuggestions: ['使用用戶畫像工具', '分析競品內容', '制定內容日曆']
        },
        {
          id: 'task_2',
          title: '內容支柱規劃',
          description: '基於3×3矩陣設計內容支柱和主題方向',
          status: 'completed',
          priority: 'high',
          assignee: '內容策劃師',
          dueDate: '2024-01-25',
          estimatedHours: 12,
          dependencies: ['task_1'],
          category: '內容策略',
          aiSuggestions: ['產品測評佔40%', '教學內容佔35%', '生活分享佔25%']
        },
        {
          id: 'task_3',
          title: '第一批文案創作',
          description: '創作前兩週的小紅書文案內容',
          status: 'in-progress',
          priority: 'medium',
          assignee: 'AI助手',
          dueDate: '2024-02-01',
          estimatedHours: 16,
          dependencies: ['task_2'],
          category: '內容製作',
          aiSuggestions: ['使用CreaTA文案產生器', '結合熱點話題', '優化SEO關鍵詞']
        },
        {
          id: 'task_4',
          title: '视觉设计配图',
          description: '为文案内容设计配套的视觉素材',
          status: 'pending',
          priority: 'medium',
          assignee: '设计师',
          dueDate: '2024-02-05',
          estimatedHours: 20,
          dependencies: ['task_3'],
          category: '视觉设计',
          aiSuggestions: ['保持品牌色调一致', '使用高质量图片', '设计模板库']
        }
      ],
      aiAnalysis: {
        complexity: 'medium',
        estimatedDuration: '3个月',
        riskFactors: ['内容同质化风险', '平台算法变化', '竞争加剧'],
        successMetrics: ['粉丝增长率', '内容互动率', '品牌曝光度', '转化率'],
        recommendedResources: ['专业摄影设备', '数据分析工具', '内容管理系统']
      }
    }
  ])

  const [selectedProject, setSelectedProject] = useState<Project | null>(projects[0])
  const [view, setView] = useState<'overview' | 'tasks' | 'timeline' | 'analytics'>('overview')
  const [showCreateProject, setShowCreateProject] = useState(false)
  const [newProjectData, setNewProjectData] = useState({
    title: '',
    description: '',
    type: 'content-creation' as const,
    deadline: '',
    goals: ''
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500'
      case 'in-progress': return 'bg-blue-500'
      case 'pending': return 'bg-gray-400'
      case 'blocked': return 'bg-red-500'
      default: return 'bg-gray-400'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50'
      case 'medium': return 'text-yellow-600 bg-yellow-50'
      case 'low': return 'text-green-600 bg-green-50'
      default: return 'text-gray-600 bg-gray-50'
    }
  }

  const handleCreateProject = async () => {
    if (!newProjectData.title || !newProjectData.description) return

    // AI智能项目分析和任务拆分
    const aiAnalysis = await analyzeProjectWithAI(newProjectData)
    const generatedTasks = await generateTasksWithAI(newProjectData, activeProfile)

    const newProject: Project = {
      id: 'proj_' + Math.random().toString(36).substr(2, 9),
      title: newProjectData.title,
      description: newProjectData.description,
      type: newProjectData.type,
      status: 'planning',
      progress: 0,
      createdAt: new Date().toLocaleDateString('zh-CN'),
      deadline: newProjectData.deadline,
      tasks: generatedTasks,
      team: ['AI助手'],
      aiAnalysis
    }

    setProjects([...projects, newProject])
    setSelectedProject(newProject)
    setShowCreateProject(false)
    setNewProjectData({ title: '', description: '', type: 'content-creation', deadline: '', goals: '' })
  }

  const handleTemplateSelect = (template: any) => {
    // 基于模板创建项目
    setNewProjectData({
      title: template.title,
      description: template.description,
      type: template.category === 'content' ? 'content-creation' : 
            template.category === 'branding' ? 'brand-building' :
            template.category === 'audience' ? 'audience-growth' : 'content-creation',
      deadline: '',
      goals: template.expectedResults.join(', ')
    })
    setShowTemplates(false)
    setShowCreateProject(true)
  }

  const analyzeProjectWithAI = async (projectData: any) => {
    // 模拟AI分析
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    return {
      complexity: Math.random() > 0.5 ? 'medium' : 'complex',
      estimatedDuration: '2-4个月',
      riskFactors: [
        '内容质量控制',
        '时间管理挑战',
        '资源协调问题'
      ],
      successMetrics: [
        '项目完成度',
        '质量评分',
        '时间效率',
        'ROI指标'
      ],
      recommendedResources: [
        'AI内容生成工具',
        '项目管理系统',
        '数据分析平台'
      ]
    }
  }

  const generateTasksWithAI = async (projectData: any, profile: any) => {
    // 模拟AI任务生成
    await new Promise(resolve => setTimeout(resolve, 1500))

    const taskTemplates = {
      'content-creation': [
        {
          title: '市场调研与竞品分析',
          description: '深入了解目标市场和竞争对手情况',
          category: '调研分析',
          estimatedHours: 8,
          priority: 'high'
        },
        {
          title: '内容策略制定',
          description: '基于调研结果制定内容创作策略',
          category: '策略规划',
          estimatedHours: 12,
          priority: 'high'
        },
        {
          title: '内容日历规划',
          description: '制定详细的内容发布计划',
          category: '计划制定',
          estimatedHours: 6,
          priority: 'medium'
        },
        {
          title: '内容创作执行',
          description: '按计划创作和优化内容',
          category: '内容制作',
          estimatedHours: 40,
          priority: 'medium'
        }
      ],
      'brand-building': [
        {
          title: '品牌定位分析',
          description: '明确品牌价值主张和差异化优势',
          category: '品牌策略',
          estimatedHours: 10,
          priority: 'high'
        },
        {
          title: '品牌视觉系统设计',
          description: '设计logo、色彩、字体等视觉元素',
          category: '视觉设计',
          estimatedHours: 20,
          priority: 'high'
        }
      ]
    }

    const templates = taskTemplates[projectData.type] || taskTemplates['content-creation']
    
    return templates.map((template, index) => ({
      id: 'task_' + Math.random().toString(36).substr(2, 9),
      title: template.title,
      description: template.description,
      status: 'pending' as const,
      priority: template.priority as 'low' | 'medium' | 'high',
      assignee: 'AI助手',
      dueDate: new Date(Date.now() + (index + 1) * 7 * 24 * 60 * 60 * 1000).toLocaleDateString('zh-CN'),
      estimatedHours: template.estimatedHours,
      dependencies: index > 0 ? [`task_${index}`] : [],
      category: template.category,
      aiSuggestions: [
        '使用AI工具提高效率',
        '参考行业最佳实践',
        '定期评估和优化'
      ]
    }))
  }

  const updateTaskStatus = (taskId: string, newStatus: Task['status']) => {
    if (!selectedProject) return

    const updatedTasks = selectedProject.tasks.map(task =>
      task.id === taskId ? { ...task, status: newStatus } : task
    )

    const completedTasks = updatedTasks.filter(task => task.status === 'completed').length
    const progress = Math.round((completedTasks / updatedTasks.length) * 100)

    const updatedProject = { ...selectedProject, tasks: updatedTasks, progress }
    setSelectedProject(updatedProject)
    setProjects(projects.map(p => p.id === selectedProject.id ? updatedProject : p))
  }

  if (!selectedProject) {
    return (
      <div className="space-y-6">
        <div className="text-center p-12">
          <Bot className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">AI项目管理</h3>
          <p className="text-muted-foreground mb-6">
            让AI为您智能规划和管理创作项目
          </p>
          <div className="flex space-x-3">
            <Button onClick={() => setShowTemplates(true)} className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
              <Lightbulb className="w-4 h-4 mr-2" />
              智能模板
            </Button>
            <Button variant="outline" onClick={() => setShowCreateProject(true)}>
              <Plus className="w-4 h-4 mr-2" />
              自定义项目
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="flex items-center space-x-2">
            <Bot className="w-6 h-6 text-purple-600" />
            <span>AI项目管理</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            智能任务拆分，清晰执行路径
          </p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" onClick={() => setShowTemplates(true)}>
            <Lightbulb className="w-4 h-4 mr-2" />
            使用模板
          </Button>
          <Button variant="outline" onClick={() => setShowCreateProject(true)}>
            <Plus className="w-4 h-4 mr-2" />
            自定义项目
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Project Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2">
                <Rocket className="w-4 h-4" />
                <span>项目列表</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {projects.map((project) => (
                <div
                  key={project.id}
                  className={`p-3 rounded-lg cursor-pointer transition-colors ${
                    selectedProject?.id === project.id
                      ? 'bg-purple-50 border-purple-200 border'
                      : 'hover:bg-muted/50'
                  }`}
                  onClick={() => setSelectedProject(project)}
                >
                  <h4 className="font-medium text-sm">{project.title}</h4>
                  <div className="flex items-center justify-between mt-2">
                    <Badge variant="secondary" className="text-xs">
                      {project.status === 'active' ? '进行中' : 
                       project.status === 'planning' ? '规划中' :
                       project.status === 'completed' ? '已完成' : '暂停'}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{project.progress}%</span>
                  </div>
                  <Progress value={project.progress} className="h-1 mt-1" />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* AI Analysis Card */}
          <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2 text-purple-700">
                <Brain className="w-4 h-4" />
                <span>AI分析</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-sm">
                <span className="text-purple-600 font-medium">复杂度：</span>
                <Badge variant="secondary" className="ml-2 bg-purple-100 text-purple-700">
                  {selectedProject.aiAnalysis.complexity === 'simple' ? '简单' :
                   selectedProject.aiAnalysis.complexity === 'medium' ? '中等' : '复杂'}
                </Badge>
              </div>
              <div className="text-sm">
                <span className="text-purple-600 font-medium">预计周期：</span>
                <span className="ml-2 text-purple-700">{selectedProject.aiAnalysis.estimatedDuration}</span>
              </div>
              <div className="text-sm">
                <span className="text-purple-600 font-medium">成功指标：</span>
                <div className="mt-1 space-y-1">
                  {selectedProject.aiAnalysis.successMetrics.slice(0, 2).map((metric, index) => (
                    <div key={index} className="text-xs text-purple-600">• {metric}</div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Project Header */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h2 className="text-xl font-semibold">{selectedProject.title}</h2>
                    <Badge className={`${
                      selectedProject.status === 'active' ? 'bg-green-500' :
                      selectedProject.status === 'planning' ? 'bg-yellow-500' :
                      selectedProject.status === 'completed' ? 'bg-blue-500' : 'bg-gray-500'
                    }`}>
                      {selectedProject.status === 'active' ? '进行中' : 
                       selectedProject.status === 'planning' ? '规划中' :
                       selectedProject.status === 'completed' ? '已完成' : '暂停'}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground mb-4">{selectedProject.description}</p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-sm">
                      <span className="text-muted-foreground">进度</span>
                      <div className="flex items-center space-x-2 mt-1">
                        <Progress value={selectedProject.progress} className="flex-1" />
                        <span className="font-medium">{selectedProject.progress}%</span>
                      </div>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">截止日期</span>
                      <p className="font-medium">{selectedProject.deadline}</p>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">任务数量</span>
                      <p className="font-medium">{selectedProject.tasks.length}个</p>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">团队成员</span>
                      <p className="font-medium">{selectedProject.team.length}人</p>
                    </div>
                  </div>
                </div>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <Settings className="w-4 h-4 mr-2" />
                      项目设置
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Play className="w-4 h-4 mr-2" />
                      启动项目
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Pause className="w-4 h-4 mr-2" />
                      暂停项目
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardContent>
          </Card>

          {/* Navigation Tabs */}
          <Tabs value={view} onValueChange={(value: any) => setView(value)}>
            <TabsList>
              <TabsTrigger value="overview">概览</TabsTrigger>
              <TabsTrigger value="tasks">任务</TabsTrigger>
              <TabsTrigger value="timeline">时间线</TabsTrigger>
              <TabsTrigger value="analytics">分析</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* AI Insights */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Lightbulb className="w-5 h-5 text-yellow-500" />
                    <span>AI洞察建议</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-3 text-red-600">⚠️ 风险因素</h4>
                      <div className="space-y-2">
                        {selectedProject.aiAnalysis.riskFactors.map((risk, index) => (
                          <div key={index} className="flex items-center space-x-2 text-sm">
                            <AlertCircle className="w-4 h-4 text-red-500" />
                            <span>{risk}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-3 text-green-600">🎯 推荐资源</h4>
                      <div className="space-y-2">
                        {selectedProject.aiAnalysis.recommendedResources.map((resource, index) => (
                          <div key={index} className="flex items-center space-x-2 text-sm">
                            <CheckCircle2 className="w-4 h-4 text-green-500" />
                            <span>{resource}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Task Overview */}
              <Card>
                <CardHeader>
                  <CardTitle>任务概览</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-semibold text-blue-600">
                        {selectedProject.tasks.filter(t => t.status === 'pending').length}
                      </div>
                      <div className="text-sm text-muted-foreground">待开始</div>
                    </div>
                    <div className="text-center p-4 bg-yellow-50 rounded-lg">
                      <div className="text-2xl font-semibold text-yellow-600">
                        {selectedProject.tasks.filter(t => t.status === 'in-progress').length}
                      </div>
                      <div className="text-sm text-muted-foreground">进行中</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-semibold text-green-600">
                        {selectedProject.tasks.filter(t => t.status === 'completed').length}
                      </div>
                      <div className="text-sm text-muted-foreground">已完成</div>
                    </div>
                    <div className="text-center p-4 bg-red-50 rounded-lg">
                      <div className="text-2xl font-semibold text-red-600">
                        {selectedProject.tasks.filter(t => t.status === 'blocked').length}
                      </div>
                      <div className="text-sm text-muted-foreground">受阻</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="tasks" className="space-y-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>任务列表</CardTitle>
                  <Button variant="outline" size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    添加任务
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {selectedProject.tasks.map((task) => (
                      <Card key={task.id} className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <button 
                                onClick={() => {
                                  const newStatus = task.status === 'completed' ? 'pending' : 
                                                  task.status === 'pending' ? 'in-progress' : 'completed'
                                  updateTaskStatus(task.id, newStatus)
                                }}
                                className="mt-1"
                              >
                                {task.status === 'completed' ? (
                                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                                ) : (
                                  <Circle className="w-5 h-5 text-muted-foreground hover:text-blue-500" />
                                )}
                              </button>
                              <div className="flex-1">
                                <h4 className="font-medium">{task.title}</h4>
                                <p className="text-sm text-muted-foreground">{task.description}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-4 ml-8">
                              <Badge className={getPriorityColor(task.priority)}>
                                {task.priority === 'high' ? '高优先级' : 
                                 task.priority === 'medium' ? '中优先级' : '低优先级'}
                              </Badge>
                              <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                                <Calendar className="w-4 h-4" />
                                <span>{task.dueDate}</span>
                              </div>
                              <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                                <Clock className="w-4 h-4" />
                                <span>{task.estimatedHours}小时</span>
                              </div>
                              <Badge variant="secondary">{task.category}</Badge>
                            </div>

                            {task.aiSuggestions.length > 0 && (
                              <div className="ml-8 mt-3 p-3 bg-purple-50 rounded-lg">
                                <div className="flex items-center space-x-2 mb-2">
                                  <Bot className="w-4 h-4 text-purple-600" />
                                  <span className="text-sm font-medium text-purple-700">AI建议</span>
                                </div>
                                <div className="space-y-1">
                                  {task.aiSuggestions.map((suggestion, index) => (
                                    <div key={index} className="text-sm text-purple-600">
                                      • {suggestion}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <div className={`w-3 h-3 rounded-full ${getStatusColor(task.status)}`} />
                            <span className="text-sm text-muted-foreground">
                              {task.status === 'completed' ? '已完成' :
                               task.status === 'in-progress' ? '进行中' :
                               task.status === 'blocked' ? '受阻' : '待开始'}
                            </span>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="timeline" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>项目时间线</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {selectedProject.tasks.map((task, index) => (
                      <div key={task.id} className="flex items-start space-x-4">
                        <div className="flex flex-col items-center">
                          <div className={`w-4 h-4 rounded-full ${getStatusColor(task.status)}`} />
                          {index < selectedProject.tasks.length - 1 && (
                            <div className="w-0.5 h-12 bg-gray-200 mt-2" />
                          )}
                        </div>
                        <div className="flex-1 pb-6">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">{task.title}</h4>
                            <span className="text-sm text-muted-foreground">{task.dueDate}</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge variant="secondary">{task.category}</Badge>
                            <Badge className={getPriorityColor(task.priority)}>
                              {task.priority === 'high' ? '高' : task.priority === 'medium' ? '中' : '低'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <TrendingUp className="w-5 h-5" />
                      <span>项目进度</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span>总体完成度</span>
                        <span className="font-semibold">{selectedProject.progress}%</span>
                      </div>
                      <Progress value={selectedProject.progress} className="h-3" />
                      
                      <div className="grid grid-cols-2 gap-4 mt-6">
                        <div className="text-center p-3 bg-green-50 rounded-lg">
                          <div className="text-lg font-semibold text-green-600">
                            {selectedProject.tasks.filter(t => t.status === 'completed').length}
                          </div>
                          <div className="text-sm text-muted-foreground">已完成任务</div>
                        </div>
                        <div className="text-center p-3 bg-blue-50 rounded-lg">
                          <div className="text-lg font-semibold text-blue-600">
                            {selectedProject.tasks.length - selectedProject.tasks.filter(t => t.status === 'completed').length}
                          </div>
                          <div className="text-sm text-muted-foreground">剩余任务</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>效率分析</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span>预计总工时</span>
                        <span className="font-semibold">
                          {selectedProject.tasks.reduce((sum, task) => sum + task.estimatedHours, 0)}小时
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>已完成工时</span>
                        <span className="font-semibold">
                          {selectedProject.tasks
                            .filter(task => task.status === 'completed')
                            .reduce((sum, task) => sum + task.estimatedHours, 0)}小时
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>剩余工时</span>
                        <span className="font-semibold">
                          {selectedProject.tasks
                            .filter(task => task.status !== 'completed')
                            .reduce((sum, task) => sum + task.estimatedHours, 0)}小时
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Create Project Dialog */}
      <Dialog open={showCreateProject} onOpenChange={setShowCreateProject}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Bot className="w-5 h-5 text-purple-600" />
              <span>创建AI项目</span>
            </DialogTitle>
            <DialogDescription>
              AI将为您智能分析项目需求，自动拆分任务并制定执行计划
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">项目名称</Label>
              <Input
                id="title"
                placeholder="输入项目名称..."
                value={newProjectData.title}
                onChange={(e) => setNewProjectData({...newProjectData, title: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">项目描述</Label>
              <Textarea
                id="description"
                placeholder="详细描述项目目标、要求和期望成果..."
                value={newProjectData.description}
                onChange={(e) => setNewProjectData({...newProjectData, description: e.target.value})}
                className="h-24"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="type">项目类型</Label>
                <Select value={newProjectData.type} onValueChange={(value: any) => setNewProjectData({...newProjectData, type: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="content-creation">内容创作</SelectItem>
                    <SelectItem value="brand-building">品牌建设</SelectItem>
                    <SelectItem value="audience-growth">粉丝增长</SelectItem>
                    <SelectItem value="product-launch">产品推广</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="deadline">截止日期</Label>
                <Input
                  id="deadline"
                  type="date"
                  value={newProjectData.deadline}
                  onChange={(e) => setNewProjectData({...newProjectData, deadline: e.target.value})}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="goals">项目目标</Label>
              <Textarea
                id="goals"
                placeholder="描述您希望通过这个项目达成的具体目标..."
                value={newProjectData.goals}
                onChange={(e) => setNewProjectData({...newProjectData, goals: e.target.value})}
                className="h-20"
              />
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-start space-x-3">
                <Brain className="w-5 h-5 text-purple-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-purple-700">AI智能分析</h4>
                  <p className="text-sm text-purple-600 mt-1">
                    AI将根据您的项目信息自动：
                  </p>
                  <ul className="text-sm text-purple-600 mt-2 space-y-1">
                    <li>• 分析项目复杂度和执行难度</li>
                    <li>• 智能拆分任务和制定时间计划</li>
                    <li>• 识别潜在风险和推荐解决方案</li>
                    <li>• 提供执行建议和优化策略</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setShowCreateProject(false)}>
                取消
              </Button>
              <Button 
                onClick={handleCreateProject}
                disabled={!newProjectData.title || !newProjectData.description}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                <Zap className="w-4 h-4 mr-2" />
                AI智能创建
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Templates Dialog */}
      <Dialog open={showTemplates} onOpenChange={setShowTemplates}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Lightbulb className="w-5 h-5 text-purple-600" />
              <span>AI项目模板</span>
            </DialogTitle>
            <DialogDescription>
              选择适合您的项目模板，AI将自动为您生成完整的项目计划
            </DialogDescription>
          </DialogHeader>
          
          <AIProjectTemplates 
            activeProfile={activeProfile}
            onSelectTemplate={handleTemplateSelect}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}