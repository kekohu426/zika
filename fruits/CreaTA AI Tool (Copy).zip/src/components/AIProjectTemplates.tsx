import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Avatar, AvatarFallback } from "./ui/avatar"
import { Progress } from "./ui/progress"
import { 
  Sparkles,
  Target,
  TrendingUp,
  Clock,
  Users,
  Star,
  CheckCircle,
  Calendar,
  Zap,
  Brain,
  Plus,
  ArrowRight,
  Camera,
  PenTool,
  BarChart3,
  Heart,
  Gift,
  MapPin,
  Book,
  Coffee,
  Dumbbell,
  Baby
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog"

interface ProjectTemplate {
  id: string
  title: string
  description: string
  category: string
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  duration: string
  expectedResults: string[]
  keyTasks: string[]
  targetAudience: string
  estimatedEffort: string
  icon: any
  color: string
  tags: string[]
  successRate: number
  userCount: number
  aiFeatures: string[]
}

interface AIProjectTemplatesProps {
  activeProfile?: any
  onSelectTemplate: (template: ProjectTemplate) => void
}

export default function AIProjectTemplates({ activeProfile, onSelectTemplate }: AIProjectTemplatesProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedTemplate, setSelectedTemplate] = useState<ProjectTemplate | null>(null)

  const categories = [
    { id: 'all', label: '全部模板', count: 24 },
    { id: 'content', label: '内容创作', count: 8 },
    { id: 'branding', label: '品牌建设', count: 6 },
    { id: 'audience', label: '粉丝增长', count: 5 },
    { id: 'monetization', label: '变现优化', count: 5 }
  ]

  const projectTemplates: ProjectTemplate[] = [
    {
      id: 'beauty-blogger-growth',
      title: '美妆博主成长计划',
      description: '从零开始打造美妆博主IP，系统性提升影响力和变现能力',
      category: 'content',
      difficulty: 'intermediate',
      duration: '3个月',
      expectedResults: [
        '粉丝增长50%+',
        '互动率提升30%',
        '品牌合作机会增加',
        '个人IP价值提升'
      ],
      keyTasks: [
        '受众画像分析与定位',
        '内容矩阵规划设计',
        '爆款文案批量创作',
        '视觉风格统一设计',
        '数据追踪与优化',
        '商业合作对接'
      ],
      targetAudience: '18-35岁女性，关注美妆护肤',
      estimatedEffort: '每周8-12小时',
      icon: Sparkles,
      color: 'bg-pink-500',
      tags: ['美妆', '护肤', '种草', '测评'],
      successRate: 92,
      userCount: 1247,
      aiFeatures: [
        'AI智能文案生成',
        '受众行为分析',
        '最佳发布时间预测',
        '热点话题推荐'
      ]
    },
    {
      id: 'tech-reviewer-system',
      title: '科技评测师体系',
      description: '建立专业的科技产品评测流程，提升内容质量和影响力',
      category: 'content',
      difficulty: 'advanced',
      duration: '4个月',
      expectedResults: [
        '专业度认知提升',
        '品牌方主动合作',
        '评测影响力扩大',
        '商业价值提升'
      ],
      keyTasks: [
        '评测标准制定',
        '专业内容模板',
        '数据可视化设计',
        '测试流程优化',
        '观点输出体系',
        '行业关系建立'
      ],
      targetAudience: '18-40岁男性，科技爱好者',
      estimatedEffort: '每周12-16小时',
      icon: Target,
      color: 'bg-blue-500',
      tags: ['科技', '评测', '数码', '专业'],
      successRate: 88,
      userCount: 856,
      aiFeatures: [
        '产品特性智能分析',
        '竞品对比报告',
        '专业术语优化',
        '评测维度推荐'
      ]
    },
    {
      id: 'lifestyle-influencer',
      title: '生活方式博主',
      description: '打造个人生活美学品牌，分享高质量生活内容',
      category: 'branding',
      difficulty: 'beginner',
      duration: '2个月',
      expectedResults: [
        '个人风格确立',
        '内容质量提升',
        '用户粘性增强',
        '合作机会增加'
      ],
      keyTasks: [
        '个人风格定位',
        '生活场景挖掘',
        '美学内容创作',
        '故事化表达',
        '社群互动建设',
        '品牌调性维护'
      ],
      targetAudience: '20-40岁追求品质生活的用户',
      estimatedEffort: '每周6-10小时',
      icon: Heart,
      color: 'bg-rose-500',
      tags: ['生活方式', '美学', '品质', '分享'],
      successRate: 94,
      userCount: 2134,
      aiFeatures: [
        '生活场景推荐',
        '美学元素分析',
        '情感共鸣优化',
        '品牌调性保持'
      ]
    },
    {
      id: 'food-content-creator',
      title: '美食内容创作者',
      description: '从美食分享到专业内容创作，建立美食领域影响力',
      category: 'content',
      difficulty: 'intermediate',
      duration: '3个月',
      expectedResults: [
        '美食内容专业化',
        '粉丝忠诚度提升',
        '餐厅合作增加',
        '商业变现能力提升'
      ],
      keyTasks: [
        '美食摄影技巧',
        '菜谱内容创作',
        '餐厅探店规划',
        '烹饪教程制作',
        '美食文化挖掘',
        '合作资源整合'
      ],
      targetAudience: '美食爱好者，烹饪爱好者',
      estimatedEffort: '每周8-12小时',
      icon: Coffee,
      color: 'bg-orange-500',
      tags: ['美食', '烹饪', '探店', '菜谱'],
      successRate: 90,
      userCount: 1678,
      aiFeatures: [
        '菜谱智能生成',
        '营养价值分析',
        '口味偏好预测',
        '季节性推荐'
      ]
    },
    {
      id: 'travel-blogger-path',
      title: '旅行博主成长路径',
      description: '打造专业旅行内容创作能力，建立旅行领域个人品牌',
      category: 'branding',
      difficulty: 'intermediate',
      duration: '4个月',
      expectedResults: [
        '旅行内容专业化',
        '目的地影响力',
        '旅游合作增加',
        '个人IP价值提升'
      ],
      keyTasks: [
        '旅行路线规划',
        '目的地内容创作',
        '旅行攻略制作',
        '文化体验分享',
        '摄影技能提升',
        '旅游资源整合'
      ],
      targetAudience: '旅行爱好者，年轻群体',
      estimatedEffort: '每周10-15小时',
      icon: MapPin,
      color: 'bg-green-500',
      tags: ['旅行', '攻略', '摄影', '文化'],
      successRate: 87,
      userCount: 934,
      aiFeatures: [
        '行程智能规划',
        '天气预测分析',
        '景点推荐系统',
        '文化背景挖掘'
      ]
    },
    {
      id: 'fitness-coach-online',
      title: '在线健身教练',
      description: '建立线上健身指导体系，提供专业健身内容和服务',
      category: 'monetization',
      difficulty: 'advanced',
      duration: '6个月',
      expectedResults: [
        '专业认知建立',
        '会员体系搭建',
        '服务收入增长',
        '行业影响力提升'
      ],
      keyTasks: [
        '训练体系设计',
        '营养指导内容',
        '会员服务流程',
        '专业认证展示',
        '成功案例积累',
        '社群运营管理'
      ],
      targetAudience: '健身爱好者，减肥人群',
      estimatedEffort: '每周15-20小时',
      icon: Dumbbell,
      color: 'bg-indigo-500',
      tags: ['健身', '教练', '减肥', '营养'],
      successRate: 85,
      userCount: 567,
      aiFeatures: [
        '个性化训练计划',
        '营养搭配建议',
        '进度跟踪分析',
        '健康数据监控'
      ]
    },
    {
      id: 'parenting-expert',
      title: '育儿专家养成',
      description: '分享专业育儿知识，建立育儿领域权威性和影响力',
      category: 'content',
      difficulty: 'intermediate',
      duration: '5个月',
      expectedResults: [
        '育儿专业度认知',
        '家长信任建立',
        '咨询服务收入',
        '行业声誉提升'
      ],
      keyTasks: [
        '育儿知识体系',
        '案例分析分享',
        '互动问答内容',
        '专业观点输出',
        '家长社群建设',
        '合作资源拓展'
      ],
      targetAudience: '新手父母，育儿焦虑群体',
      estimatedEffort: '每周10-14小时',
      icon: Baby,
      color: 'bg-purple-500',
      tags: ['育儿', '教育', '心理', '成长'],
      successRate: 91,
      userCount: 1456,
      aiFeatures: [
        '成长阶段分析',
        '问题智能诊断',
        '解决方案推荐',
        '发展趋势预测'
      ]
    },
    {
      id: 'book-reviewer-system',
      title: '书评人影响力体系',
      description: '建立专业书评创作能力，成为读书领域意见领袖',
      category: 'content',
      difficulty: 'beginner',
      duration: '3个月',
      expectedResults: [
        '书评专业度提升',
        '读者群体扩大',
        '出版社合作',
        '个人品牌建立'
      ],
      keyTasks: [
        '阅读体系建立',
        '书评写作技巧',
        '读书笔记整理',
        '主题书单制作',
        '读者互动设计',
        '行业资源积累'
      ],
      targetAudience: '读书爱好者，知识工作者',
      estimatedEffort: '每周8-12小时',
      icon: Book,
      color: 'bg-cyan-500',
      tags: ['读书', '书评', '知识', '分享'],
      successRate: 89,
      userCount: 823,
      aiFeatures: [
        '阅读偏好分析',
        '书籍推荐系统',
        '观点提炼优化',
        '读者兴趣匹配'
      ]
    }
  ]

  // 根据用户档案智能推荐模板
  const getRecommendedTemplates = () => {
    if (!activeProfile) return projectTemplates.slice(0, 3)
    
    const identity = activeProfile.coreIdentity?.toLowerCase() || ''
    const platforms = activeProfile.targetPlatform || []
    
    const scored = projectTemplates.map(template => {
      let score = 0
      
      // 基于核心身份匹配
      if (identity.includes('美妆') && template.id.includes('beauty')) score += 10
      if (identity.includes('科技') && template.id.includes('tech')) score += 10
      if (identity.includes('生活') && template.id.includes('lifestyle')) score += 8
      if (identity.includes('美食') && template.id.includes('food')) score += 10
      if (identity.includes('旅行') && template.id.includes('travel')) score += 10
      if (identity.includes('健身') && template.id.includes('fitness')) score += 10
      if (identity.includes('育儿') && template.id.includes('parenting')) score += 10
      if (identity.includes('书评') && template.id.includes('book')) score += 10
      
      // 基于平台匹配
      if (platforms.includes('xiaohongshu')) score += 5
      if (platforms.includes('douyin') && template.category === 'content') score += 3
      
      // 基于用户价值观匹配
      if (activeProfile.coreValues?.includes('专业') && template.difficulty === 'advanced') score += 3
      if (activeProfile.coreValues?.includes('简单') && template.difficulty === 'beginner') score += 3
      
      return { ...template, score }
    })
    
    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, 3)
  }

  const filteredTemplates = selectedCategory === 'all' 
    ? projectTemplates 
    : projectTemplates.filter(template => template.category === selectedCategory)

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'text-green-600 bg-green-50'
      case 'intermediate': return 'text-yellow-600 bg-yellow-50'
      case 'advanced': return 'text-red-600 bg-red-50'
      default: return 'text-gray-600 bg-gray-50'
    }
  }

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return '入门级'
      case 'intermediate': return '进阶级'
      case 'advanced': return '专家级'
      default: return '未知'
    }
  }

  return (
    <div className="space-y-6">
      {/* AI智能推荐 */}
      {activeProfile && (
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-purple-700">
              <Brain className="w-5 h-5" />
              <span>AI为您推荐</span>
            </CardTitle>
            <p className="text-sm text-purple-600">
              基于您的身份档案"{activeProfile.coreIdentity}"，为您量身推荐最适合的项目模板
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {getRecommendedTemplates().map((template) => {
                const IconComponent = template.icon
                return (
                  <Card key={template.id} className="hover:shadow-md transition-shadow cursor-pointer border-2 border-transparent hover:border-purple-200">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className={`w-10 h-10 rounded-lg ${template.color} flex items-center justify-center`}>
                          <IconComponent className="w-5 h-5 text-white" />
                        </div>
                        <Badge className="bg-purple-100 text-purple-700 border-purple-200">
                          推荐
                        </Badge>
                      </div>
                      <h4 className="font-medium mb-2">{template.title}</h4>
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {template.description}
                      </p>
                      <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                        <span>{template.duration}</span>
                        <Badge className={getDifficultyColor(template.difficulty)}>
                          {getDifficultyLabel(template.difficulty)}
                        </Badge>
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => onSelectTemplate(template)}
                      >
                        使用模板
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* 分类筛选 */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.id ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(category.id)}
            className="h-8"
          >
            {category.label}
            <Badge variant="secondary" className="ml-2 text-xs">
              {category.count}
            </Badge>
          </Button>
        ))}
      </div>

      {/* 模板网格 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template) => {
          const IconComponent = template.icon
          return (
            <Card key={template.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="p-6 space-y-4">
                  <div className="flex items-start justify-between">
                    <div className={`w-12 h-12 rounded-xl ${template.color} flex items-center justify-center`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <Badge className={getDifficultyColor(template.difficulty)}>
                      {getDifficultyLabel(template.difficulty)}
                    </Badge>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">{template.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-3">
                      {template.description}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {template.tags.slice(0, 3).map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">项目周期：</span>
                      <span>{template.duration}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">预计投入：</span>
                      <span>{template.estimatedEffort}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">成功率：</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={template.successRate} className="w-16 h-2" />
                        <span className="font-medium text-green-600">{template.successRate}%</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Users className="w-4 h-4" />
                      <span>{template.userCount}人使用</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>4.{Math.floor(Math.random() * 3) + 7}</span>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="flex-1">
                          查看详情
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="flex items-center space-x-3">
                            <div className={`w-10 h-10 rounded-lg ${template.color} flex items-center justify-center`}>
                              <IconComponent className="w-5 h-5 text-white" />
                            </div>
                            <span>{template.title}</span>
                          </DialogTitle>
                          <DialogDescription>
                            {template.description}
                          </DialogDescription>
                        </DialogHeader>
                        
                        <div className="space-y-6">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-medium mb-2">项目信息</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">难度等级：</span>
                                  <Badge className={getDifficultyColor(template.difficulty)}>
                                    {getDifficultyLabel(template.difficulty)}
                                  </Badge>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">项目周期：</span>
                                  <span>{template.duration}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">预计投入：</span>
                                  <span>{template.estimatedEffort}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">目标受众：</span>
                                  <span className="text-right max-w-40">{template.targetAudience}</span>
                                </div>
                              </div>
                            </div>
                            
                            <div>
                              <h4 className="font-medium mb-2">使用统计</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">使用人数：</span>
                                  <span>{template.userCount.toLocaleString()}人</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">成功率：</span>
                                  <span className="text-green-600 font-medium">{template.successRate}%</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">用户评分：</span>
                                  <div className="flex items-center space-x-1">
                                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                    <span>4.{Math.floor(Math.random() * 3) + 7}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div>
                            <h4 className="font-medium mb-3 flex items-center space-x-2">
                              <Target className="w-4 h-4" />
                              <span>预期成果</span>
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              {template.expectedResults.map((result, index) => (
                                <div key={index} className="flex items-center space-x-2 text-sm">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  <span>{result}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h4 className="font-medium mb-3 flex items-center space-x-2">
                              <Calendar className="w-4 h-4" />
                              <span>关键任务</span>
                            </h4>
                            <div className="space-y-2">
                              {template.keyTasks.map((task, index) => (
                                <div key={index} className="flex items-start space-x-3 text-sm">
                                  <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xs font-medium mt-0.5">
                                    {index + 1}
                                  </div>
                                  <span>{task}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h4 className="font-medium mb-3 flex items-center space-x-2">
                              <Zap className="w-4 h-4" />
                              <span>AI功能特性</span>
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              {template.aiFeatures.map((feature, index) => (
                                <div key={index} className="flex items-center space-x-2 text-sm bg-purple-50 rounded-lg p-2">
                                  <Brain className="w-4 h-4 text-purple-600" />
                                  <span>{feature}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="flex space-x-3 pt-4 border-t">
                            <Button 
                              className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                              onClick={() => {
                                onSelectTemplate(template)
                                setSelectedTemplate(null)
                              }}
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              使用此模板
                            </Button>
                            <Button variant="outline" className="flex-1">
                              收藏模板
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    
                    <Button 
                      size="sm" 
                      className="flex-1"
                      onClick={() => onSelectTemplate(template)}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      使用模板
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}