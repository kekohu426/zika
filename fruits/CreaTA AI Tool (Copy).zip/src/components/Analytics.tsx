import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Button } from "./ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Progress } from "./ui/progress"
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Heart,
  MessageCircle,
  Share2,
  Eye,
  Target,
  Calendar,
  Filter,
  Download,
  RefreshCw,
  Zap,
  Award,
  Clock
} from "lucide-react"

export default function Analytics() {
  const overviewStats = [
    {
      title: "總瀏覽量",
      value: "45.2K",
      change: "+12.5%",
      changeType: "positive" as const,
      icon: Eye,
      description: "本月累計瀏覽量"
    },
    {
      title: "互動率",
      value: "8.3%",
      change: "+2.1%",
      changeType: "positive" as const,
      icon: Heart,
      description: "平均互動率"
    },
    {
      title: "粉絲增長",
      value: "1.2K",
      change: "+18.7%",
      changeType: "positive" as const,
      icon: Users,
      description: "本月新增粉絲"
    },
    {
      title: "內容發佈",
      value: "28",
      change: "+3.7%",
      changeType: "positive" as const,
      icon: BarChart3,
      description: "本月發佈內容數"
    }
  ]

  const contentPerformance = [
    {
      title: "✨ 這款AI工具太神了！一鍵產生爆款文案",
      type: "AI工具推薦",
      publishDate: "2024-01-20",
      views: "12.5K",
      likes: "1.8K",
      comments: "342",
      shares: "156",
      engagementRate: "14.2%",
      score: 95
    },
    {
      title: "🔥 小紅書營運必備的5個神器分享",
      type: "工具分享",
      publishDate: "2024-01-18",
      views: "8.3K",
      likes: "1.2K",
      comments: "189",
      shares: "89",
      engagementRate: "17.8%",
      score: 88
    },
    {
      title: "📱 2024年最值得入手的手機推薦",
      type: "產品評測",
      publishDate: "2024-01-15",
      views: "15.7K",
      likes: "2.1K",
      comments: "567",
      shares: "234",
      engagementRate: "18.5%",
      score: 92
    },
    {
      title: "💄 平價唇膏測評，這些真的太好用了",
      type: "美妝評測",
      publishDate: "2024-01-12",
      views: "22.1K",
      likes: "3.2K",
      comments: "789",
      shares: "445",
      engagementRate: "20.1%",
      score: 98
    }
  ]

  const trendsData = [
    { category: "AI工具", growth: "+45%", posts: 12, avgViews: "8.5K", color: "purple" },
    { category: "美妆护肤", growth: "+32%", posts: 8, avgViews: "12.3K", color: "pink" },
    { category: "科技数码", growth: "+28%", posts: 5, avgViews: "15.7K", color: "blue" },
    { category: "生活方式", growth: "+18%", posts: 3, avgViews: "6.8K", color: "green" }
  ]

  const aiInsights = [
    {
      type: "趋势预测",
      title: "AI工具类内容持续走热",
      description: "基于数据分析，AI相关内容在未来2周内预计有35%的增长空间",
      confidence: 92,
      action: "建议增加AI工具推荐类内容"
    },
    {
      type: "优化建议",
      title: "发布时间优化",
      description: "您的受众在晚上8-10点最活跃，建议在此时间段发布内容",
      confidence: 85,
      action: "调整发布时间策略"
    },
    {
      type: "内容建议",
      title: "互动率提升机会",
      description: "问答类内容互动率比普通内容高60%，建议多使用提问式标题",
      confidence: 78,
      action: "优化标题写作策略"
    }
  ]

  const getScoreColor = (score: number) => {
    if (score >= 95) return "text-green-600 bg-green-100"
    if (score >= 85) return "text-blue-600 bg-blue-100"
    if (score >= 75) return "text-yellow-600 bg-yellow-100"
    return "text-red-600 bg-red-100"
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="flex items-center space-x-2">
            <BarChart3 className="w-6 h-6 text-purple-600" />
            <span>数据洞察</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            深度分析您的内容表现，获取AI驱动的优化建议
          </p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            刷新数据
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            导出报告
          </Button>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            筛选
          </Button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {overviewStats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <div className="flex items-center space-x-2">
                    <span className="text-3xl font-bold">{stat.value}</span>
                    <Badge 
                      variant={stat.changeType === 'positive' ? 'default' : 'secondary'}
                      className="text-xs"
                    >
                      {stat.change}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {stat.description}
                  </p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-blue-100 rounded-full flex items-center justify-center">
                  <stat.icon className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="performance" className="w-full">
        <TabsList className="grid w-full grid-cols-4 max-w-2xl">
          <TabsTrigger value="performance">内容表现</TabsTrigger>
          <TabsTrigger value="trends">趋势分析</TabsTrigger>
          <TabsTrigger value="audience">受众画像</TabsTrigger>
          <TabsTrigger value="ai-insights">AI洞察</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5" />
                <span>内容表现排行</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {contentPerformance.map((content, index) => (
                  <div key={index} className="p-4 border rounded-lg space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium">{content.title}</h4>
                          <Badge variant="outline" className="text-xs">
                            {content.type}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          发布时间: {content.publishDate}
                        </p>
                      </div>
                      <div className={`px-3 py-1 rounded-full text-sm font-medium ${getScoreColor(content.score)}`}>
                        {content.score}分
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                      <div className="flex items-center space-x-2">
                        <Eye className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <div className="font-medium">{content.views}</div>
                          <div className="text-xs text-muted-foreground">浏览</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Heart className="w-4 h-4 text-red-500" />
                        <div>
                          <div className="font-medium">{content.likes}</div>
                          <div className="text-xs text-muted-foreground">点赞</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MessageCircle className="w-4 h-4 text-blue-500" />
                        <div>
                          <div className="font-medium">{content.comments}</div>
                          <div className="text-xs text-muted-foreground">评论</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Share2 className="w-4 h-4 text-green-500" />
                        <div>
                          <div className="font-medium">{content.shares}</div>
                          <div className="text-xs text-muted-foreground">分享</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Target className="w-4 h-4 text-purple-500" />
                        <div>
                          <div className="font-medium">{content.engagementRate}</div>
                          <div className="text-xs text-muted-foreground">互动率</div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-green-500" />
                  <span>内容类型趋势</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {trendsData.map((trend, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-4 h-4 rounded-full ${
                          trend.color === 'purple' ? 'bg-purple-500' :
                          trend.color === 'pink' ? 'bg-pink-500' :
                          trend.color === 'blue' ? 'bg-blue-500' :
                          'bg-green-500'
                        }`} />
                        <span className="font-medium">{trend.category}</span>
                      </div>
                      <Badge variant="default" className="text-green-700 bg-green-100">
                        {trend.growth}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                      <div>发布数量: {trend.posts} 篇</div>
                      <div>平均浏览: {trend.avgViews}</div>
                    </div>
                    <Progress 
                      value={parseInt(trend.growth.replace('+', '').replace('%', ''))} 
                      className="h-2" 
                    />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5 text-blue-500" />
                  <span>发布时间分析</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="text-sm">
                    <div className="flex justify-between mb-1">
                      <span>周一-周五</span>
                      <span className="text-muted-foreground">65% 互动率</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                  <div className="text-sm">
                    <div className="flex justify-between mb-1">
                      <span>周末</span>
                      <span className="text-muted-foreground">45% 互动率</span>
                    </div>
                    <Progress value={45} className="h-2" />
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <h4 className="font-medium mb-3">最佳发布时间</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>🌟 晚上 8-10点</span>
                      <span className="text-green-600 font-medium">最佳</span>
                    </div>
                    <div className="flex justify-between">
                      <span>📈 中午 12-2点</span>
                      <span className="text-blue-600 font-medium">良好</span>
                    </div>
                    <div className="flex justify-between">
                      <span>⏰ 早上 7-9点</span>
                      <span className="text-yellow-600 font-medium">一般</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="audience" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-purple-500" />
                  <span>受众构成</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-1 text-sm">
                      <span>女性用户</span>
                      <span>78%</span>
                    </div>
                    <Progress value={78} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1 text-sm">
                      <span>男性用户</span>
                      <span>22%</span>
                    </div>
                    <Progress value={22} className="h-2" />
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <h4 className="font-medium mb-3">年龄分布</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>18-24岁</span>
                      <span className="text-muted-foreground">35%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>25-30岁</span>
                      <span className="text-muted-foreground">42%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>31-35岁</span>
                      <span className="text-muted-foreground">18%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>36岁以上</span>
                      <span className="text-muted-foreground">5%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-orange-500" />
                  <span>兴趣偏好</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { interest: "科技数码", percentage: 85 },
                    { interest: "美妆护肤", percentage: 72 },
                    { interest: "生活方式", percentage: 68 },
                    { interest: "职场成长", percentage: 54 },
                    { interest: "健康养生", percentage: 41 }
                  ].map((item, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1 text-sm">
                        <span>{item.interest}</span>
                        <span>{item.percentage}%</span>
                      </div>
                      <Progress value={item.percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="ai-insights" className="space-y-6">
          <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Zap className="w-5 h-5 text-purple-600" />
                <span className="text-purple-700">AI 智能洞察</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {aiInsights.map((insight, index) => (
                <div key={index} className="bg-white rounded-lg p-4 border border-purple-100">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center space-x-2">
                          <Badge 
                            variant="secondary" 
                            className="text-xs bg-purple-100 text-purple-700"
                          >
                            {insight.type}
                          </Badge>
                          <div className="flex items-center space-x-1">
                            <Award className="w-4 h-4 text-yellow-500" />
                            <span className="text-sm text-muted-foreground">
                              置信度 {insight.confidence}%
                            </span>
                          </div>
                        </div>
                        <h4 className="font-semibold text-purple-700">{insight.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {insight.description}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-purple-600 font-medium">
                        💡 {insight.action}
                      </div>
                      <Button size="sm" variant="outline" className="text-purple-600 border-purple-200">
                        采纳建议
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-green-500" />
                  <span>实时优化建议</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm font-medium text-green-800">
                        当前发布时机很好
                      </p>
                      <p className="text-xs text-green-600">
                        目标受众活跃度较高，建议立即发布
                      </p>
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm font-medium text-blue-800">
                        标签优化机会
                      </p>
                      <p className="text-xs text-blue-600">
                        添加 #AI工具 标签可提升20%曝光
                      </p>
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm font-medium text-yellow-800">
                        封面图优化
                      </p>
                      <p className="text-xs text-yellow-600">
                        使用更明亮的色彩可增加点击率
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-blue-500" />
                  <span>预测表现</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600 mb-1">预计 8.5K+</div>
                  <div className="text-sm text-muted-foreground">24小时内浏览量</div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">互动率预测</span>
                    <span className="text-sm font-medium text-green-600">12.3%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">热门概率</span>
                    <span className="text-sm font-medium text-purple-600">78%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">推荐指数</span>
                    <span className="text-sm font-medium text-blue-600">★★★★☆</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}