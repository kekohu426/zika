import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { 
  Mail, 
  Lock, 
  Phone, 
  User,
  ArrowRight,
  Sparkles,
  Shield,
  Zap
} from "lucide-react"

interface AuthProps {
  onLogin: (userData: any) => void
}

export default function Auth({ onLogin }: AuthProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    phone: "",
    name: "",
    confirmPassword: ""
  })

  const handleLogin = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Mock user data - in real app this would come from API
    const userData = {
      id: "user_123",
      email: formData.email,
      name: formData.name || "新用戶",
      isNewUser: !formData.name, // If no name provided, treat as new user
      profiles: [] // Empty profiles for new user
    }
    
    onLogin(userData)
    setIsLoading(false)
  }

  const handleRegister = async () => {
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    const userData = {
      id: "user_" + Math.random().toString(36).substr(2, 9),
      email: formData.email,
      name: formData.name,
      isNewUser: true,
      profiles: []
    }
    
    onLogin(userData)
    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 flex items-center justify-center p-4 neural-pattern">
      <div className="w-full max-w-md space-y-8">
        {/* Logo */}
        <div className="text-center space-y-3 animate-fade-in-up">
          <div className="w-20 h-20 bg-gradient-to-br from-purple-600 to-blue-600 rounded-3xl flex items-center justify-center mx-auto shadow-lg">
            <span className="text-white font-bold text-3xl">C</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            CreaTA
          </h1>
          <p className="text-gray-600 text-lg">
            AI驅動的內容創作平台
          </p>
        </div>

        <Card className="border-0 shadow-2xl bg-white/90 backdrop-blur-xl animate-scale-in">
          <CardContent className="p-8">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100/80 p-1 rounded-2xl">
                <TabsTrigger 
                  value="login" 
                  className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-md transition-all duration-300"
                >
                  登入
                </TabsTrigger>
                <TabsTrigger 
                  value="register"
                  className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-md transition-all duration-300"
                >
                  註冊
                </TabsTrigger>
              </TabsList>

              <TabsContent value="login" className="space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="login-email" className="text-gray-700 font-medium text-sm">電郵</Label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
                      <Mail className="w-5 h-5 text-gray-400" />
                    </div>
                    <Input
                      id="login-email"
                      type="email"
                      placeholder="輸入您的電郵"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="h-14 pl-12 pr-4 bg-gray-50/80 border-2 border-gray-200/80 rounded-xl text-gray-900 placeholder:text-gray-400 
                               focus:border-blue-500 focus:bg-white focus:shadow-lg focus:ring-4 focus:ring-blue-100 
                               transition-all duration-300 hover:border-gray-300 hover:bg-white/60"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="login-password" className="text-gray-700 font-medium text-sm">密碼</Label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
                      <Lock className="w-5 h-5 text-gray-400" />
                    </div>
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="輸入您的密碼"
                      value={formData.password}
                      onChange={(e) => setFormData({...formData, password: e.target.value})}
                      className="h-14 pl-12 pr-4 bg-gray-50/80 border-2 border-gray-200/80 rounded-xl text-gray-900 placeholder:text-gray-400 
                               focus:border-blue-500 focus:bg-white focus:shadow-lg focus:ring-4 focus:ring-blue-100 
                               transition-all duration-300 hover:border-gray-300 hover:bg-white/60"
                    />
                  </div>
                </div>

                <Button 
                  className="w-full h-14 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 
                           rounded-xl text-white font-medium text-base shadow-lg hover:shadow-xl transform hover:scale-[1.02] 
                           transition-all duration-300 button-press mt-8"
                  onClick={handleLogin}
                  disabled={isLoading || !formData.email || !formData.password}
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-3">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>登入中...</span>
                    </div>
                  ) : (
                    <>
                      <span>立即登入</span>
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>

                <div className="text-center pt-4">
                  <Button variant="link" className="text-sm text-gray-500 hover:text-blue-600 transition-colors duration-200">
                    忘記密碼？
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="register" className="space-y-5">
                <div className="space-y-3">
                  <Label htmlFor="register-name" className="text-gray-700 font-medium text-sm">姓名</Label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
                      <User className="w-5 h-5 text-gray-400" />
                    </div>
                    <Input
                      id="register-name"
                      placeholder="輸入您的姓名"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="h-14 pl-12 pr-4 bg-gray-50/80 border-2 border-gray-200/80 rounded-xl text-gray-900 placeholder:text-gray-400 
                               focus:border-blue-500 focus:bg-white focus:shadow-lg focus:ring-4 focus:ring-blue-100 
                               transition-all duration-300 hover:border-gray-300 hover:bg-white/60"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="register-email" className="text-gray-700 font-medium text-sm">電郵</Label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
                      <Mail className="w-5 h-5 text-gray-400" />
                    </div>
                    <Input
                      id="register-email"
                      type="email"
                      placeholder="輸入您的電郵"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="h-14 pl-12 pr-4 bg-gray-50/80 border-2 border-gray-200/80 rounded-xl text-gray-900 placeholder:text-gray-400 
                               focus:border-blue-500 focus:bg-white focus:shadow-lg focus:ring-4 focus:ring-blue-100 
                               transition-all duration-300 hover:border-gray-300 hover:bg-white/60"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="register-phone" className="text-gray-700 font-medium text-sm">手機號碼</Label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
                      <Phone className="w-5 h-5 text-gray-400" />  
                    </div>
                    <Input
                      id="register-phone"
                      placeholder="輸入您的手機號碼"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="h-14 pl-12 pr-4 bg-gray-50/80 border-2 border-gray-200/80 rounded-xl text-gray-900 placeholder:text-gray-400 
                               focus:border-blue-500 focus:bg-white focus:shadow-lg focus:ring-4 focus:ring-blue-100 
                               transition-all duration-300 hover:border-gray-300 hover:bg-white/60"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="register-password" className="text-gray-700 font-medium text-sm">密碼</Label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
                      <Lock className="w-5 h-5 text-gray-400" />
                    </div>
                    <Input
                      id="register-password"
                      type="password"
                      placeholder="設定密碼"
                      value={formData.password}
                      onChange={(e) => setFormData({...formData, password: e.target.value})}
                      className="h-14 pl-12 pr-4 bg-gray-50/80 border-2 border-gray-200/80 rounded-xl text-gray-900 placeholder:text-gray-400 
                               focus:border-blue-500 focus:bg-white focus:shadow-lg focus:ring-4 focus:ring-blue-100 
                               transition-all duration-300 hover:border-gray-300 hover:bg-white/60"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="confirm-password" className="text-gray-700 font-medium text-sm">確認密碼</Label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
                      <Shield className="w-5 h-5 text-gray-400" />
                    </div>
                    <Input
                      id="confirm-password"
                      type="password"
                      placeholder="再次輸入密碼"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                      className="h-14 pl-12 pr-4 bg-gray-50/80 border-2 border-gray-200/80 rounded-xl text-gray-900 placeholder:text-gray-400 
                               focus:border-blue-500 focus:bg-white focus:shadow-lg focus:ring-4 focus:ring-blue-100 
                               transition-all duration-300 hover:border-gray-300 hover:bg-white/60"
                    />
                  </div>
                </div>

                <Button 
                  className="w-full h-14 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 
                           rounded-xl text-white font-medium text-base shadow-lg hover:shadow-xl transform hover:scale-[1.02] 
                           transition-all duration-300 button-press mt-8"
                  onClick={handleRegister}
                  disabled={isLoading || !formData.email || !formData.password || !formData.name || formData.password !== formData.confirmPassword}
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-3">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>註冊中...</span>
                    </div>
                  ) : (
                    <>
                      <span>立即註冊</span>
                      <Sparkles className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Features */}
        <div className="grid grid-cols-3 gap-6 text-center animate-fade-in-up">
          <div className="space-y-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-purple-50 rounded-2xl flex items-center justify-center mx-auto shadow-md hover:shadow-lg transition-all duration-300 hover:scale-110">
              <Sparkles className="w-6 h-6 text-purple-600" />
            </div>
            <p className="text-sm text-gray-600 font-medium">AI文案產生</p>
          </div>
          <div className="space-y-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-blue-50 rounded-2xl flex items-center justify-center mx-auto shadow-md hover:shadow-lg transition-all duration-300 hover:scale-110">
              <Zap className="w-6 h-6 text-blue-600" />
            </div>
            <p className="text-sm text-gray-600 font-medium">智能知識庫</p>
          </div>
          <div className="space-y-3">
            <div className="w-12 h-12 bg-gradient-to-br from-green-100 to-green-50 rounded-2xl flex items-center justify-center mx-auto shadow-md hover:shadow-lg transition-all duration-300 hover:scale-110">
              <Shield className="w-6 h-6 text-green-600" />
            </div>
            <p className="text-sm text-gray-600 font-medium">數據分析</p>
          </div>
        </div>
      </div>
    </div>
  )
}