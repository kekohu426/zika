import { useState, useRef, useEffect } from "react"
import { Button } from "./ui/button"
import { Textarea } from "./ui/textarea"
import { ImageWithFallback } from "./figma/ImageWithFallback"
import { toast } from "sonner@2.0.3"
import { 
  Sparkles, 
  Send,
  Mic,
  Paperclip,
  Smile,
  Hash,
  Target,
  Users,
  Loader2,
  CheckCircle,
  Copy,
  RefreshCw,
  Eye,
  Heart,
  Share2,
  TrendingUp,
  BarChart3,
  Image as ImageIcon,
  FileText,
  Wand2
} from "lucide-react"
import { cn } from "./ui/utils"

interface ContentGeneratorProps {
  activeProfile?: any
}

const quickTemplates = [
  { id: 'skincare', label: '護膚心得分享', color: 'bg-pink-100 text-pink-700 border-pink-200' },
  { id: 'food', label: '美食評價攻略', color: 'bg-orange-100 text-orange-700 border-orange-200' },
  { id: 'fashion', label: '穿搭種草', color: 'bg-purple-100 text-purple-700 border-purple-200' },
  { id: 'daily', label: '熱門日常', color: 'bg-green-100 text-green-700 border-green-200' },
  { id: 'business', label: '商務好物推薦', color: 'bg-blue-100 text-blue-700 border-blue-200' }
]

export default function ContentGenerator({ activeProfile }: ContentGeneratorProps) {
  const [inputValue, setInputValue] = useState("")
  const [selectedTemplate, setSelectedTemplate] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [showResult, setShowResult] = useState(false)
  const [generatedContent, setGeneratedContent] = useState<any>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // 自動調整 textarea 高度
  const adjustTextareaHeight = () => {
    const textarea = textareaRef.current
    if (textarea) {
      textarea.style.height = 'auto'
      textarea.style.height = `${Math.max(120, textarea.scrollHeight)}px`
    }
  }

  useEffect(() => {
    adjustTextareaHeight()
  }, [inputValue])

  // 模擬 AI 生成過程
  const handleGenerate = async () => {
    if (!inputValue.trim()) {
      toast.error('請輸入創作內容')
      return
    }

    setIsGenerating(true)
    
    try {
      // 模擬 API 調用延遲
      await new Promise(resolve => setTimeout(resolve, 3000))
      
      const result = {
        title: "✨ 這款護膚神器真的太好用了！一週見效，姐妹們衝！",
        content: `姐妹們！今天要分享一個超級驚喜的護膚發現🔥

最近試了很多護膚品，但是這款精華真的讓我驚艷到了！

🌟 產品亮點：
• 質地清爽不黏膩，吸收超快
• 一週就能看到明顯改善
• 敏感肌也可以放心使用
• 性價比超高，學生黨友好

💡 使用心得：
${inputValue}

用了一個月下來，皮膚狀態真的提升了很多：
✅ 毛孔變小了
✅ 膚質更加細膩
✅ 痘印淡化明顯
✅ 整體亮了一個度

真的強烈推薦給大家！現在還有活動價，趕緊衝！

#護膚分享 #好物推薦 #護膚心得 #美容護膚 #種草筆記`,
        tags: ['護膚分享', '好物推薦', '護膚心得', '美容護膚', '種草筆記', '精華推薦'],
        performance: {
          views: '8.5K - 12K',
          engagement: '15-22%',
          shareability: '高',
          viral: '82%'
        },
        suggestions: {
          coverStyle: '清新護膚風',
          colors: ['粉色', '白色', '淺綠'],
          images: ['產品展示', '使用前後對比', '質地特寫', '上臉效果']
        }
      }

      setGeneratedContent(result)
      setShowResult(true)
      
      // 保存到本地存儲
      saveToDocuments(result)
      
      toast.success('內容生成完成！', {
        description: '已為您生成專業的小紅書文案'
      })
      
    } catch (error) {
      toast.error('生成失敗', {
        description: '請稍後重試'
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const saveToDocuments = (content: any) => {
    const savedDocuments = localStorage.getItem('creata_documents')
    const existingDocs = savedDocuments ? JSON.parse(savedDocuments) : []
    
    const newDocument = {
      id: 'doc_' + Math.random().toString(36).substr(2, 9),
      title: content.title,
      content: content.content,
      coverImage: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400',
      profileUsed: {
        id: activeProfile?.id || 'default',
        name: activeProfile?.name || '預設檔案'
      },
      platform: ['小紅書'],
      tags: content.tags,
      createdAt: new Date().toLocaleString('zh-HK'),
      folder: '小紅書文案',
      status: 'draft' as const,
      metadata: {
        wordCount: content.content.length,
        originalPrompt: inputValue,
        template: selectedTemplate
      }
    }
    
    const updatedDocs = [newDocument, ...existingDocs]
    localStorage.setItem('creata_documents', JSON.stringify(updatedDocs))
  }

  const handleTemplateSelect = (template: typeof quickTemplates[0]) => {
    setSelectedTemplate(template.id)
    // 可以根據模板類型設定預設的輸入提示
    const templatePrompts = {
      skincare: '分享一個超好用的護膚精華，用後感受和效果...',
      food: '推薦一家新發現的餐廳，環境和招牌菜...',
      fashion: '展示今天的穿搭，搭配心得和單品推薦...',
      daily: '記錄日常生活中的美好時刻...',
      business: '分享一款提升工作效率的好物...'
    }
    if (!inputValue) {
      setInputValue(templatePrompts[template.id as keyof typeof templatePrompts] || '')
    }
  }

  const handleInputKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleGenerate()
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('已複製到剪貼板')
  }

  const handleNewContent = () => {
    setShowResult(false)
    setGeneratedContent(null)
    setInputValue('')
    setSelectedTemplate('')
  }

  if (showResult && generatedContent) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-red-500 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">內容生成完成</h1>
                <p className="text-sm text-gray-500">已為您生成專業的小紅書文案</p>
              </div>
            </div>
            <Button onClick={handleNewContent} variant="outline" className="text-sm">
              <Wand2 className="w-4 h-4 mr-2" />
              創建新內容
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-4xl mx-auto p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Title */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-900 flex items-center">
                    <Hash className="w-4 h-4 mr-2" />
                    文案標題
                  </h3>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => copyToClipboard(generatedContent.title)}
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    複製
                  </Button>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="font-medium text-gray-900">{generatedContent.title}</p>
                </div>
              </div>

              {/* Content */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-900 flex items-center">
                    <FileText className="w-4 h-4 mr-2" />
                    正文內容
                  </h3>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => copyToClipboard(generatedContent.content)}
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    複製
                  </Button>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg max-h-96 overflow-y-auto">
                  <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">
                    {generatedContent.content}
                  </p>
                </div>
              </div>

              {/* Tags */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                  <Hash className="w-4 h-4 mr-2" />
                  推薦標籤
                </h3>
                <div className="flex flex-wrap gap-2">
                  {generatedContent.tags.map((tag: string, index: number) => (
                    <button
                      key={index}
                      onClick={() => copyToClipboard(`#${tag}`)}
                      className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm hover:bg-blue-200 transition-colors"
                    >
                      #{tag}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Performance */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  預期表現
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Eye className="w-4 h-4 text-blue-500" />
                      <span className="text-sm text-gray-600">預估觀看</span>
                    </div>
                    <span className="text-sm font-medium">{generatedContent.performance.views}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-red-500" />
                      <span className="text-sm text-gray-600">互動率</span>
                    </div>
                    <span className="text-sm font-medium">{generatedContent.performance.engagement}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Share2 className="w-4 h-4 text-green-500" />
                      <span className="text-sm text-gray-600">分享潛力</span>
                    </div>
                    <span className="text-sm font-medium">{generatedContent.performance.shareability}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="w-4 h-4 text-purple-500" />
                      <span className="text-sm text-gray-600">爆款機率</span>
                    </div>
                    <span className="text-sm font-medium">{generatedContent.performance.viral}</span>
                  </div>
                </div>
              </div>

              {/* Cover Suggestions */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                  <ImageIcon className="w-4 h-4 mr-2" />
                  封面建議
                </h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-2">風格：{generatedContent.suggestions.coverStyle}</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {generatedContent.suggestions.colors.map((color: string, index: number) => (
                        <span key={index} className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
                          {color}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-2">配圖建議：</p>
                    <div className="space-y-1">
                      {generatedContent.suggestions.images.map((image: string, index: number) => (
                        <p key={index} className="text-xs text-gray-600">• {image}</p>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-pink-500 to-red-500 text-white px-4 py-2 rounded-full text-sm font-medium">
            <Sparkles className="w-4 h-4" />
            <span>小紅書營銷文案生成</span>
          </div>
        </div>
      </div>

      {/* Profile Hint */}
      {!activeProfile && (
        <div className="bg-amber-50 border-b border-amber-200">
          <div className="max-w-4xl mx-auto px-6 py-3">
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 bg-amber-500 rounded-lg flex items-center justify-center">
                <Target className="w-3 h-3 text-white" />
              </div>
              <p className="text-sm text-amber-800">
                建立身份檔案後，AI 將根據您的目標受眾和內��風格生成更精準的文案
              </p>
              <Button size="sm" variant="outline" className="text-xs border-amber-300 text-amber-700 hover:bg-amber-100">
                <Users className="w-3 h-3 mr-1" />
                立即建立
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">開始創建您的小紅書內容</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            在下方輸入您的創意靈感，AI 將為您生成完整的爆款文案、標題和配圖
          </p>
        </div>

        {/* Quick Templates */}
        <div className="mb-8">
          <div className="flex flex-wrap justify-center gap-3">
            {quickTemplates.map((template) => (
              <button
                key={template.id}
                onClick={() => handleTemplateSelect(template)}
                className={cn(
                  "px-4 py-2 rounded-full text-sm font-medium border transition-all duration-200 hover:shadow-md",
                  selectedTemplate === template.id 
                    ? template.color + " shadow-md" 
                    : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"
                )}
              >
                {template.label}
              </button>
            ))}
          </div>
        </div>

        {/* Input Section */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-8">
          <div className="space-y-6">
            <Textarea
              ref={textareaRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleInputKeyDown}
              placeholder="請求您要製作的內容，比如：分享一個超好用的護膚小心得..."
              className="min-h-[120px] resize-none border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-4 focus:ring-pink-100 text-gray-900 placeholder:text-gray-400 text-base leading-relaxed p-4"
              style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif' }}
              disabled={isGenerating}
            />

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-gray-500 hover:text-gray-700"
                  disabled={isGenerating}
                >
                  <Paperclip className="w-4 h-4 mr-1" />
                  附件
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-gray-500 hover:text-gray-700"
                  disabled={isGenerating}
                >
                  <Mic className="w-4 h-4 mr-1" />
                  語音
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-gray-500 hover:text-gray-700"
                  disabled={isGenerating}
                >
                  <Smile className="w-4 h-4 mr-1" />
                  表情
                </Button>
              </div>

              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-500">
                  {inputValue.length}/2000
                </span>
                <Button
                  onClick={handleGenerate}
                  disabled={!inputValue.trim() || isGenerating}
                  className="bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white px-6 py-2 rounded-xl font-medium shadow-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      AI 創作中...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      生成內容
                    </>
                  )}
                </Button>
              </div>
            </div>

            <div className="text-center">
              <p className="text-sm text-gray-500">
                按 Enter 發送，Shift + Enter 換行
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}