import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Progress } from "./ui/progress"
import { 
  TrendingUp, 
  Users, 
  FileText, 
  Sparkles,
  Clock,
  Target,
  ChevronRight,
  Plus,
  Activity,
  BookOpen,
  Zap,
  BarChart3,
  ArrowUpRight,
  Eye,
  Heart,
  MessageCircle,
  Brain,
  Star,
  Lightbulb,
  Rocket,
  Award
} from "lucide-react"

interface DashboardProps {
  activeProfile?: any
}

export default function Dashboard({ activeProfile }: DashboardProps) {
  const stats = [
    {
      title: "本月產生文案",
      value: "127",
      change: "+23%",
      changeType: "positive" as const,
      icon: FileText,
      gradient: "from-blue-500 to-blue-600",
      bgGradient: "from-blue-50 to-blue-100"
    },
    {
      title: "AI 助手使用",
      value: "89",
      change: "+45%",
      changeType: "positive" as const,
      icon: Sparkles,
      gradient: "from-purple-500 to-pink-600",
      bgGradient: "from-purple-50 to-pink-100"
    },
    {
      title: "知識庫文檔",
      value: "34",
      change: "+12%",
      changeType: "positive" as const,
      icon: BookOpen,
      gradient: "from-green-500 to-teal-600",
      bgGradient: "from-green-50 to-teal-100"
    },
    {
      title: "社群互動",
      value: "256",
      change: "+67%",
      changeType: "positive" as const,
      icon: Users,
      gradient: "from-orange-500 to-red-600",
      bgGradient: "from-orange-50 to-red-100"
    }
  ]

  const recentProjects = [
    {
      title: "小紅書美妝推廣文案",
      status: "已完成",
      date: "2小時前",
      views: "2.3K",
      likes: "147",
      comments: "23",
      engagement: 85,
      aiScore: 94,
      category: "美妝護膚"
    },
    {
      title: "科技產品種草內容",
      status: "產生中",
      date: "30分鐘前",
      views: "0",
      likes: "0",
      comments: "0",
      engagement: 0,
      aiScore: 0,
      category: "科技數碼"
    },
    {
      title: "生活方式分享文案",
      status: "待優化",
      date: "1天前",
      views: "1.8K",
      likes: "203",
      comments: "45",
      engagement: 92,
      aiScore: 88,
      category: "生活方式"
    },
    {
      title: "旅行攻略推薦文案",
      status: "已完成",
      date: "3天前",
      views: "3.1K",
      likes: "289",
      comments: "67",
      engagement: 78,
      aiScore: 91,
      category: "旅行攻略"
    }
  ]

  const aiAgents = [
    {
      name: "文案創作專家",
      description: "專業的內容創作和優化",
      status: "線上",
      usage: 89,
      tasks: 23,
      icon: Lightbulb,
      gradient: "from-yellow-400 to-orange-500"
    },
    {
      name: "數據分析師",
      description: "內容表現深度分析",
      status: "線上",
      usage: 67,
      tasks: 15,
      icon: BarChart3,
      gradient: "from-blue-500 to-indigo-600"
    },
    {
      name: "SEO優化專家",
      description: "搜尋引擎優化建議",
      status: "忙碌",
      usage: 23,
      tasks: 8,
      icon: Target,
      gradient: "from-green-500 to-teal-600"
    }
  ]

  const quickActions = [
    {
      title: "建立新文案",
      description: "使用AI快速產生優質內容",
      icon: Plus,
      action: "generator",
      gradient: "from-blue-500 to-blue-600",
      bgClass: "from-blue-50 to-blue-100"
    },
    {
      title: "查看分析報告",
      description: "了解內容表現和用戶反饋",
      icon: BarChart3,
      action: "analytics",
      gradient: "from-green-500 to-teal-600",
      bgClass: "from-green-50 to-teal-100"
    },
    {
      title: "管理知識庫",
      description: "整理和優化您的內容素材",
      icon: BookOpen,
      action: "knowledge",
      gradient: "from-purple-500 to-pink-600",
      bgClass: "from-purple-50 to-pink-100"
    }
  ]

  return (
    <div className="space-y-8 animate-fade-in-up">
      {/* Welcome Section */}
      <div className="card-premium p-8 relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 neural-pattern opacity-30"></div>
        <div className="absolute top-0 right-0 w-64 h-64 gradient-ai opacity-5 rounded-full blur-3xl"></div>
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {activeProfile ? `歡迎回來，${activeProfile.name}` : '歡迎使用 CreaTA'}
                <span className="inline-block ml-2">👋</span>
              </h1>
              <p className="text-lg text-gray-600">
                讓AI幫您創造更優質的內容，釋放創作潛能
              </p>
            </div>
            
            <Button className="gradient-primary text-white shadow-neural hover:shadow-lg transition-all duration-300 button-press">
              <Rocket className="w-5 h-5 mr-2" />
              開始創作
            </Button>
          </div>
          
          {activeProfile && (
            <div className="glass-strong rounded-xl p-4 border-apple">
              <div className="flex items-center space-x-8 text-sm">
                <div className="flex items-center space-x-2">
                  <Target className="w-4 h-4 text-blue-600" />
                  <span className="text-gray-600">核心身份：</span>
                  <span className="font-semibold text-gray-900">{activeProfile.coreIdentity}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-green-600" />
                  <span className="text-gray-600">目標用戶：</span>
                  <span className="font-semibold text-gray-900">{activeProfile.audienceA}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Award className="w-4 h-4 text-purple-600" />
                  <span className="text-gray-600">AI匹配度：</span>
                  <span className="font-semibold text-green-600">96%</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={stat.title} className="card-premium hover-lift-apple relative overflow-hidden group">
            {/* Background gradient */}
            <div className={`absolute inset-0 bg-gradient-to-br ${stat.bgGradient} opacity-0 group-hover:opacity-50 transition-opacity duration-300`}></div>
            
            <CardContent className="p-6 relative z-10">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center shadow-lg`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex items-center text-green-600 text-sm font-semibold">
                  <ArrowUpRight className="w-4 h-4 mr-1" />
                  {stat.change}
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </CardContent>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Projects */}
        <div className="lg:col-span-2">
          <Card className="card-premium">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                    <Activity className="w-4 h-4 text-white" />
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-900">最近項目</CardTitle>
                </div>
                <Button variant="outline" size="sm" className="border-apple hover:glass-hover">
                  查看全部
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-gray-100">
                {recentProjects.map((project, index) => (
                  <div key={index} className="p-6 hover:glass-hover transition-all duration-300 group">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">{project.title}</h3>
                          <Badge variant="outline" className="text-xs px-2 py-1 text-purple-600 border-purple-200 bg-purple-50">
                            {project.category}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center space-x-6 text-sm text-gray-500 mb-3">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>{project.date}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Eye className="w-3 h-3" />
                            <span>{project.views}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Heart className="w-3 h-3" />
                            <span>{project.likes}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MessageCircle className="w-3 h-3" />
                            <span>{project.comments}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <Badge 
                          variant={project.status === '已完成' ? 'default' : project.status === '產生中' ? 'secondary' : 'outline'}
                          className={
                            project.status === '已完成' 
                              ? 'bg-green-100 text-green-700 border-green-200' 
                              : project.status === '產生中'
                              ? 'bg-blue-100 text-blue-700 border-blue-200'
                              : 'bg-yellow-100 text-yellow-700 border-yellow-200'
                          }
                        >
                          {project.status}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* AI Performance Metrics */}
                    {project.aiScore > 0 && (
                      <div className="flex items-center space-x-6">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs text-gray-500">互动率</span>
                          <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-500"
                              style={{ width: `${project.engagement}%` }}
                            />
                          </div>
                          <span className="text-xs font-semibold text-gray-700">{project.engagement}%</span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Brain className="w-3 h-3 text-purple-600" />
                          <span className="text-xs text-gray-500">AI评分</span>
                          <span className="text-xs font-bold text-purple-600">{project.aiScore}</span>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Content */}
        <div className="space-y-6">
          {/* AI Agents */}
          <Card className="card-premium">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 gradient-ai rounded-lg flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <CardTitle className="text-lg font-bold text-gray-900">AI 助手团队</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {aiAgents.map((agent, index) => (
                <div key={index} className="group p-4 rounded-xl hover:glass-hover transition-all duration-300 border border-transparent hover:border-apple">
                  <div className="flex items-start space-x-3">
                    <div className={`w-10 h-10 bg-gradient-to-br ${agent.gradient} rounded-xl flex items-center justify-center shadow-lg`}>
                      <agent.icon className="w-5 h-5 text-white" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="font-semibold text-gray-900 truncate text-sm">{agent.name}</h3>
                        <div className={`w-2 h-2 rounded-full ${
                          agent.status === '在线' ? 'bg-green-500' : 
                          agent.status === '忙碌' ? 'bg-yellow-500' : 'bg-gray-400'
                        }`} />
                      </div>
                      <p className="text-xs text-gray-600 mb-3">{agent.description}</p>
                      
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-500">使用率</span>
                          <span className="font-semibold text-gray-700">{agent.usage}%</span>
                        </div>
                        <Progress value={agent.usage} className="h-1.5" />
                        
                        <div className="flex items-center justify-between text-xs pt-1">
                          <span className="text-gray-500">活跃任务</span>
                          <Badge variant="secondary" className="text-xs px-2 py-0.5 bg-blue-50 text-blue-700">
                            {agent.tasks}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="card-premium">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                  <Zap className="w-4 h-4 text-white" />
                </div>
                <CardTitle className="text-lg font-bold text-gray-900">快速操作</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {quickActions.map((action, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="w-full justify-start h-auto p-4 hover:glass-hover rounded-xl transition-all duration-300 group"
                >
                  <div className={`w-10 h-10 bg-gradient-to-br ${action.bgClass} rounded-xl flex items-center justify-center mr-4 group-hover:shadow-lg transition-all duration-300`}>
                    <action.icon className="w-5 h-5 text-gray-700" />
                  </div>
                  
                  <div className="flex-1 text-left">
                    <div className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">{action.title}</div>
                    <div className="text-sm text-gray-500">{action.description}</div>
                  </div>
                  
                  <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all duration-300" />
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}