import { useState, useEffect } from "react"
import { 
  Search, 
  FileText, 
  Calendar, 
  Tag, 
  FolderOpen,
  Folder,
  Plus,
  MoreHorizontal,
  Copy,
  Trash2,
  Heart,
  Star,
  Eye,
  TrendingUp,
  Clock,
  Image as ImageIcon,
  Filter,
  Grid,
  List,
  SortAsc,
  ChevronDown,
  ArrowLeft,
  ArrowRight,
  Play,
  ChevronLeft,
  ChevronRight,
  PanelLeftClose,
  PanelLeftOpen,
  Users,
  Zap
} from "lucide-react"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Badge } from "./ui/badge"
import { Card, CardContent } from "./ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { toast } from "sonner@2.0.3"
import { cn } from "./ui/utils"

interface GeneratedDocument {
  id: string
  title: string
  content: string
  coverImage?: string
  contentImages: string[]
  profileUsed: {
    id: string
    name: string
  }
  platform: string[]
  tags: string[]
  createdAt: string
  updatedAt: string
  isBookmarked: boolean
  viewCount: number
  engagementScore: number
  folder: string
  status: 'draft' | 'published' | 'archived'
  metadata: {
    wordCount: number
    imageCount: number
    estimatedReadTime: number
  }
}

interface DocumentManagerProps {
  activeProfile: any
}

export default function DocumentManager({ activeProfile }: DocumentManagerProps) {
  const [documents, setDocuments] = useState<GeneratedDocument[]>([])
  const [filteredDocuments, setFilteredDocuments] = useState<GeneratedDocument[]>([])
  const [selectedDocument, setSelectedDocument] = useState<GeneratedDocument | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("所有檔案")
  const [isDirectoryCollapsed, setIsDirectoryCollapsed] = useState(false)

  // 載入文檔數據
  useEffect(() => {
    const savedDocuments = localStorage.getItem('creata_documents')
    if (savedDocuments) {
      const docs = JSON.parse(savedDocuments)
      setDocuments(docs)
    } else {
      // 模擬豐富的示例數據用於演示
      const mockDocuments: GeneratedDocument[] = [
        {
          id: 'doc_1',
          title: '🌟 港式奶茶的秘密配方大公開！',
          content: `作為一個地道香港人，我要和大家分享最正宗的港式奶茶製作方法！

🫖 材料準備：
• 紅茶葉 15g（推薦錫蘭茶）
• 淡奶 50ml
• 煉乳 2湯匙
• 開水 400ml

👨‍🍳 製作步驟：
1. 先用滾水沖茶葉，浸泡5分鐘
2. 用茶袋過濾，反覆拉茶3-4次
3. 加入淡奶和煉乳，攪拌均勻
4. 趁熱享用，香濃順滑！

💡 小貼士：
茶葉的品質很重要，建議選用斯里蘭卡錫蘭茶。拉茶的手法決定奶茶的順滑度，多練習就能掌握！

在香港茶餐廳工作多年的經驗分享，希望大家都能在家享受正宗港式奶茶的美味！

#港式奶茶 #茶餐廳 #香港美食 #飲品DIY`,
          coverImage: 'https://images.unsplash.com/photo-1571934811086-9c9ce8b8a518?w=800',
          contentImages: [
            'https://images.unsplash.com/photo-1571934811086-9c9ce8b8a518?w=400',
            'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400'
          ],
          profileUsed: { id: 'profile_1', name: '香港美食達人' },
          platform: ['小紅書', 'Instagram'],
          tags: ['港式奶茶', '美食', '香港', '飲品'],
          createdAt: '2025-09-08 15:17:03',
          updatedAt: '2025-09-08 15:17:03',
          isBookmarked: true,
          viewCount: 1892,
          engagementScore: 85,
          folder: '美食分享',
          status: 'published',
          metadata: {
            wordCount: 285,
            imageCount: 2,
            estimatedReadTime: 2
          }
        },
        {
          id: 'doc_2',
          title: '📱 iPhone 16 Pro 深度體驗：AI攝影真的超越人眼嗎？',
          content: `拿到iPhone 16 Pro已經一週了，今天來和大家分享一下真實使用感受！

📸 相機系統升級亮點：
• 48MP主鏡頭：細節表現確實有提升
• 5倍光學變焦：遠拍質素明顯改善
• AI智慧場景識別：夜景拍攝有驚喜
• 4K ProRes錄影：專業創作者的福音

🔋 續航表現：
一天重度使用（拍照、視頻剪輯、社交媒體）可以撐到晚上8點左右，比上代有所改善。

💫 新功能體驗：
• 動作按鈕：自訂功能很實用
• USB-C：終於可以和其他裝置共用充電線
• iOS 18新特性：桌面自訂功能很好玩

💰 值得升級嗎？
如果你還在用iPhone 13或更早的機型，升級很值得。但從iPhone 15 Pro升級就要看個人需求了。

整體來說，這是一台很全面的旗艦手機，特別適合內容創作者使用！

#iPhone16Pro #蘋果 #手機評測 #科技分享`,
          coverImage: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=800',
          contentImages: [
            'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400',
            'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400'
          ],
          profileUsed: { id: 'profile_2', name: '科技評測達人' },
          platform: ['小紅書', 'YouTube', 'Instagram'],
          tags: ['iPhone', '蘋果', '手機評測', '科技'],
          createdAt: '2025-09-07 20:45:12',
          updatedAt: '2025-09-07 20:45:12',
          isBookmarked: true,
          viewCount: 3254,
          engagementScore: 91,
          folder: '科技評測',
          status: 'published',
          metadata: {
            wordCount: 312,
            imageCount: 2,
            estimatedReadTime: 3
          }
        },
        {
          id: 'doc_3',
          title: '✈️ 日本關西5日遊完整攻略 | 大阪京都奈良一次玩透！',
          content: `剛從日本關西回來，這次5天4夜的行程安排得很充實，和大家分享一下詳細攻略！

🏨 住宿推薦：
選擇了大阪心齋橋附近的酒店，交通方便，去哪裡都很近。價格大概每晚700-800港元。

📅 行程安排：
Day 1: 抵達大阪 → 道頓堀 → 心齋橋購物
Day 2: 大阪城 → 環球影城 → 梅田空中庭園
Day 3: 京都一日遊（清水寺、金閣寺、嵐山）
Day 4: 奈良餵小鹿 → 春日大社 → 回大阪
Day 5: 臨空城購物 → 返程

🍜 美食推薦：
• 一蘭拉麵：必吃的豚骨拉麵
• 蟹道樂：螃蟹料理專門店
• 章魚燒：道頓堀隨便一家都很好吃
• 抹茶甜品：京都的抹茶真的無敵

💰 預算參考：
機票+酒店：約8000港元
餐飲：約2000港元
交通：約800港元（買了關西周遊券）
購物：約3000港元
總計：約14000港元左右

📝 貼心提醒：
• 記得買JR Pass很划算
• 現金要多準備，很多地方不能刷卡
• Google翻譯超好用，下載離線包
• 藥妝店記得退稅，能省不少錢

這次旅行真的很充實，關西地區的文化底蘊很深厚，值得細細品味！

#日本旅遊 #關西攻略 #大阪 #京都 #奈良`,
          coverImage: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800',
          contentImages: [
            'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=400',
            'https://images.unsplash.com/photo-1528164344705-47542687000d?w=400',
            'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=400'
          ],
          profileUsed: { id: 'profile_3', name: '旅遊生活博主' },
          platform: ['小紅書', 'Instagram'],
          tags: ['日本', '旅遊', '關西', '攻略'],
          createdAt: '2025-09-06 19:30:25',
          updatedAt: '2025-09-06 19:30:25',
          isBookmarked: false,
          viewCount: 2167,
          engagementScore: 78,
          folder: '旅遊攻略',
          status: 'published',
          metadata: {
            wordCount: 425,
            imageCount: 3,
            estimatedReadTime: 4
          }
        },
        {
          id: 'doc_4',
          title: '💄 秋冬底妝不脫妝秘訣 | 混合肌實測分享',
          content: `踏入秋冬季節，底妝最容易出現乾燥脫皮問題。作為混合肌，我試了很多方法，終於找到了完美解決方案！

🧴 妝前護膚步驟：
1. 溫和潔面：避免過度清潔
2. 保濕精華：重點在T區和兩頰
3. 面霜：選擇質地適中的保濕面霜
4. 妝前乳：一定要等護膚品完全吸收

💄 底妝產品推薦：
• 粉底液：Giorgio Armani Luminous Silk
• 遮瑕：NARS Soft Matte Complete Concealer
• 定妝粉：Laura Mercier Translucent Powder
• 定妝噴霧：MAC Fix+ Setting Spray

✨ 上妝技巧：
• 使用美妝蛋濕潤上妝，質感更服貼
• 分層薄塗，避免厚重感
• T區用少量散粉定妝
• 最後噴定妝噴霧鎖住妝容

⏰ 持妝測試結果：
早上7點上妝，晚上7點卸妝，底妝依然很完整！特別是鼻翼兩側，以前最容易脫妝的地方現在也很OK。

🌟 額外小貼士：
• 定期做面膜保持肌膚狀態
• 根據天氣調整護膚品用量
• 化妝刷要定期清洗
• 底妝不要貪心，自然最美

希望這些分享對大家有幫助，秋冬也要美美的！

#底妝 #不脫妝 #混合肌 #秋冬妝容 #美妝分享`,
          coverImage: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800',
          contentImages: [
            'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400'
          ],
          profileUsed: { id: 'profile_4', name: '美妝護膚博主' },
          platform: ['小紅書', 'Instagram'],
          tags: ['美妝', '底妝', '混合肌', '護膚'],
          createdAt: '2025-09-05 16:22:18',
          updatedAt: '2025-09-05 16:22:18',
          isBookmarked: true,
          viewCount: 1456,
          engagementScore: 82,
          folder: '美妝教學',
          status: 'published',
          metadata: {
            wordCount: 295,
            imageCount: 1,
            estimatedReadTime: 3
          }
        },
        {
          id: 'doc_5',
          title: '🏠 小户型裝修的5個神奇技巧',
          content: `在香港這樣寸土寸金的地方，如何讓小空間發揮最大功效？分享我的裝修心得！

🎯 技巧一：善用垂直空間
牆面收納是小户型的救星！安裝懸浮書架、掛勾系統，釋放地面空間。

🎯 技巧二：多功能家具
選擇儲物床、摺疊餐桌等，一物多用大大提升空間利用率。

🎯 技巧三：光線設計
增加鏡面元素，搭配適當照明，視覺上擴大空間感。

🎯 技巧四：色彩搭配
以淺色為主調，深色做點綴，讓空間看起來更寬敞明亮。

🎯 技巧五：去除不必要隔間
開放式設計讓空間更流暢，但要注意功能區劃分。

💡 預算控制：
• 重點投資在收納系統
• DIY一些簡單裝飾
• 選擇性價比高的家具

經過精心規劃，我的30平米小家變得既實用又美觀！期待看到大家的改造成果~

#小户型 #裝修 #家居設計 #收納`,
          coverImage: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800',
          contentImages: [],
          profileUsed: { id: 'profile_5', name: '家居設計師' },
          platform: ['小紅書', '微博'],
          tags: ['家居', '裝修', '小户型', '設計'],
          createdAt: '2025-09-04 17:00:50',
          updatedAt: '2025-09-04 17:00:50',
          isBookmarked: true,
          viewCount: 1840,
          engagementScore: 75,
          folder: '生活分享',
          status: 'published',
          metadata: {
            wordCount: 345,
            imageCount: 0,
            estimatedReadTime: 3
          }
        }
      ]
      setDocuments(mockDocuments)
      localStorage.setItem('creata_documents', JSON.stringify(mockDocuments))
    }
  }, [])

  // 篩選文檔
  useEffect(() => {
    let filtered = documents

    // 搜索篩選
    if (searchQuery) {
      filtered = filtered.filter(doc => 
        doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    }

    // 按時間排序
    filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    setFilteredDocuments(filtered)
  }, [documents, searchQuery])

  const handleDocumentSelect = (doc: GeneratedDocument) => {
    setSelectedDocument(doc)
  }

  const handleBookmark = (docId: string) => {
    const updatedDocs = documents.map(doc => 
      doc.id === docId ? { ...doc, isBookmarked: !doc.isBookmarked } : doc
    )
    setDocuments(updatedDocs)
    localStorage.setItem('creata_documents', JSON.stringify(updatedDocs))
    
    // 更新選中的文檔
    if (selectedDocument?.id === docId) {
      setSelectedDocument({ ...selectedDocument, isBookmarked: !selectedDocument.isBookmarked })
    }
    
    toast.success('已更新收藏狀態')
  }

  const handleDelete = (docId: string) => {
    const updatedDocs = documents.filter(doc => doc.id !== docId)
    setDocuments(updatedDocs)
    localStorage.setItem('creata_documents', JSON.stringify(updatedDocs))
    
    // 如果刪除的是當前選中的文檔，清除選中狀態
    if (selectedDocument?.id === docId) {
      setSelectedDocument(null)
    }
    
    toast.success('文檔已刪除')
  }

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content)
    toast.success('內容已複製到剪貼板')
  }

  // 格式化時間
  const formatDateTime = (dateStr: string) => {
    if (dateStr.includes(':')) {
      return dateStr
    }
    return dateStr + ' 09:30:15'
  }

  // 獲取狀態信息
  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'published': 
        return { 
          color: 'text-green-700 bg-green-50 border-green-200', 
          text: '已發佈'
        }
      case 'draft': 
        return { 
          color: 'text-gray-700 bg-gray-50 border-gray-200', 
          text: '草稿'
        }
      case 'archived': 
        return { 
          color: 'text-gray-600 bg-gray-50 border-gray-200', 
          text: '已歸檔'
        }
      default: 
        return { 
          color: 'text-blue-700 bg-blue-50 border-blue-200', 
          text: '處理中'
        }
    }
  }

  return (
    <div className="flex h-full w-full bg-white" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* 中間：檔案目錄面板 - Notion風格 */}
      <div className={cn(
        "bg-gray-50 border-r border-gray-200 flex flex-col transition-all duration-300",
        isDirectoryCollapsed ? "w-12" : "w-80"
      )}>
        {/* 頂部標題欄 */}
        <div className="flex items-center justify-between px-3 py-2 border-b border-gray-200 bg-white">
          {!isDirectoryCollapsed && (
            <>
              <div className="flex items-center space-x-2">
                <FolderOpen className="w-4 h-4 text-gray-500" />
                <span style={{ fontSize: '14px', fontWeight: '500', color: '#37352f', fontFamily: 'Inter, sans-serif' }}>所有檔案</span>
                <span style={{ fontSize: '12px', color: '#9b9a97', fontFamily: 'Inter, sans-serif' }}>({documents.length})</span>
              </div>
              <Button variant="ghost" size="sm" className="h-7 w-7 p-0 hover:bg-gray-100 rounded-md">
                <Plus className="w-4 h-4 text-gray-500" />
              </Button>
            </>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsDirectoryCollapsed(!isDirectoryCollapsed)}
            className="h-7 w-7 p-0 hover:bg-gray-100 rounded-md"
          >
            {isDirectoryCollapsed ? (
              <PanelLeftOpen className="w-4 h-4 text-gray-500" />
            ) : (
              <PanelLeftClose className="w-4 h-4 text-gray-500" />
            )}
          </Button>
        </div>

        {!isDirectoryCollapsed && (
          <>
            {/* 搜索框 */}
            <div className="p-2">
              <div className="relative">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="搜尋檔案..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 h-8 text-sm border-gray-200 focus:border-blue-500 bg-white rounded-md"
                  style={{ fontSize: '14px', fontFamily: 'Inter, sans-serif' }}
                />
              </div>
            </div>

            {/* 檔案列表 */}
            <div className="flex-1 overflow-auto scrollbar-apple">
              <div className="px-1">
                {filteredDocuments.map((doc) => (
                  <div
                    key={doc.id}
                    onClick={() => handleDocumentSelect(doc)}
                    className={cn(
                      "p-2 mx-1 my-0.5 cursor-pointer rounded-md transition-colors",
                      selectedDocument?.id === doc.id 
                        ? 'bg-blue-50 border border-blue-200' 
                        : 'hover:bg-gray-100'
                    )}
                  >
                    {/* 時間戳 */}
                    <div style={{ fontSize: '11px', color: '#9b9a97', marginBottom: '4px', fontFamily: 'Inter, sans-serif' }}>
                      {formatDateTime(doc.createdAt)}
                    </div>
                    
                    {/* 標題 */}
                    <div 
                      style={{ 
                        fontSize: '13px', 
                        color: '#37352f', 
                        lineHeight: '1.3',
                        marginBottom: '6px',
                        fontWeight: '400',
                        fontFamily: 'Inter, sans-serif'
                      }}
                      className="line-clamp-2"
                    >
                      {doc.title}
                    </div>
                    
                    {/* 統計和狀態 */}
                    <div className="flex items-center justify-between" style={{ fontSize: '11px', color: '#9b9a97', fontFamily: 'Inter, sans-serif' }}>
                      <div className="flex items-center space-x-2">
                        <span className="flex items-center space-x-1">
                          <Eye className="w-3 h-3" />
                          <span>{doc.viewCount}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{doc.metadata.estimatedReadTime}m</span>
                        </span>
                      </div>
                      
                      <div className="flex items-center space-x-1">
                        {doc.isBookmarked && (
                          <Heart className="w-3 h-3 text-red-500 fill-current" />
                        )}
                        <span className={cn(
                          "px-1.5 py-0.5 rounded text-xs",
                          getStatusInfo(doc.status).color
                        )} style={{ fontSize: '10px', fontFamily: 'Inter, sans-serif' }}>
                          {getStatusInfo(doc.status).text}
                        </span>
                      </div>
                    </div>
                    
                    {/* 分類 */}
                    <div className="mt-1">
                      <span 
                        className="inline-block px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded"
                        style={{ fontSize: '10px', fontFamily: 'Inter, sans-serif' }}
                      >
                        {doc.folder}
                      </span>
                    </div>
                  </div>
                ))}
                
                {filteredDocuments.length === 0 && (
                  <div className="flex flex-col items-center justify-center h-40 text-center p-6">
                    <FileText className="w-12 h-12 text-gray-300 mb-4" />
                    <p style={{ fontSize: '14px', color: '#9b9a97', fontFamily: 'Inter, sans-serif' }}>找不到符合條件的檔案</p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}

        {/* 摺疊狀態 */}
        {isDirectoryCollapsed && (
          <div className="flex-1 flex flex-col items-center justify-center p-2">
            <div className="w-7 h-7 bg-gray-100 rounded flex items-center justify-center mb-2">
              <FileText className="w-4 h-4 text-gray-600" />
            </div>
            <div style={{ fontSize: '10px', color: '#9b9a97', fontFamily: 'Inter, sans-serif' }}>{documents.length}</div>
          </div>
        )}
      </div>

      {/* 右側：文檔詳情查看區域 - Notion風格 */}
      <div className="flex-1 flex flex-col bg-white">
        {selectedDocument ? (
          <>
            {/* 頂部工具欄 */}
            <div className="px-6 py-3 border-b border-gray-100 bg-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={cn(
                    "px-2 py-1 rounded border text-xs",
                    getStatusInfo(selectedDocument.status).color
                  )} style={{ fontSize: '11px' }}>
                    {getStatusInfo(selectedDocument.status).text}
                  </div>
                  <div style={{ fontSize: '12px', color: '#9b9a97', fontFamily: 'Inter, sans-serif' }}>
                    {formatDateTime(selectedDocument.createdAt)}
                  </div>
                  <div style={{ fontSize: '12px', color: '#9b9a97', fontFamily: 'Inter, sans-serif' }}>
                    {selectedDocument.profileUsed.name}
                  </div>
                </div>
                
                <div className="flex items-center space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleBookmark(selectedDocument.id)}
                    className="h-7 w-7 p-0 hover:bg-gray-100 rounded-md"
                  >
                    <Heart className={`w-4 h-4 ${selectedDocument.isBookmarked ? 'fill-red-500 text-red-500' : 'text-gray-500'}`} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleCopy(selectedDocument.content)}
                    className="h-7 w-7 p-0 hover:bg-gray-100 rounded-md"
                  >
                    <Copy className="w-4 h-4 text-gray-500" />
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0 hover:bg-gray-100 rounded-md">
                        <MoreHorizontal className="w-4 h-4 text-gray-500" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="rounded-lg">
                      <DropdownMenuItem onClick={() => handleDelete(selectedDocument.id)} className="text-red-600 hover:bg-red-50">
                        <Trash2 className="w-4 h-4 mr-2" />
                        刪除
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>

            {/* 文檔內容 - Notion樣式 */}
            <div className="flex-1 overflow-auto scrollbar-apple">
              <div className="px-6 py-6 max-w-4xl">
                {/* 標題 - Notion風格 H1 (32px) */}
                <h1 
                  style={{ 
                    fontSize: '32px', 
                    fontWeight: '700', 
                    color: '#37352f',
                    lineHeight: '1.2',
                    marginBottom: '24px',
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                    letterSpacing: '-0.025em'
                  }}
                >
                  {selectedDocument.title}
                </h1>

                {/* 內容 - Notion段落樣式 Body Text (16px) 帶區塊間距 */}
                <div className="mb-8" style={{ marginBottom: '32px' }}>
                  <div 
                    style={{ 
                      fontSize: '16px', 
                      color: '#37352f',
                      lineHeight: '1.6',
                      fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                      whiteSpace: 'pre-wrap',
                      fontWeight: '400',
                      /* Notion特有的段落間距 */
                      marginBottom: '16px'
                    }}
                  >
                    {selectedDocument.content.split('\n\n').map((paragraph, index) => (
                      <p key={index} style={{ 
                        marginBottom: paragraph.trim() ? '16px' : '8px',
                        fontSize: '16px',
                        lineHeight: '1.6',
                        color: '#37352f'
                      }}>
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </div>

                {/* 封面圖片 - Notion區塊樣式 */}
                {selectedDocument.coverImage && (
                  <div className="mb-8" style={{ marginBottom: '32px' }}>
                    <h3 style={{ 
                      fontSize: '20px', 
                      fontWeight: '600', 
                      color: '#37352f', 
                      marginBottom: '16px',
                      fontFamily: 'Inter, sans-serif',
                      lineHeight: '1.4',
                      letterSpacing: '-0.01em'
                    }}>
                      封面圖片
                    </h3>
                    <div style={{ 
                      padding: '12px',
                      border: '1px solid #e9e9e7',
                      borderRadius: '8px',
                      backgroundColor: '#fafafa'
                    }}>
                      <img 
                        src={selectedDocument.coverImage} 
                        alt={selectedDocument.title}
                        className="w-full max-w-2xl rounded-md"
                        style={{ 
                          border: '1px solid #e9e9e7',
                          borderRadius: '6px'
                        }}
                      />
                    </div>
                  </div>
                )}

                {/* 正文配圖 - Notion Gallery 樣式 */}
                {selectedDocument.contentImages.length > 0 && (
                  <div className="mb-8" style={{ marginBottom: '32px' }}>
                    <h3 style={{ 
                      fontSize: '20px', 
                      fontWeight: '600', 
                      color: '#37352f', 
                      marginBottom: '16px',
                      fontFamily: 'Inter, sans-serif',
                      lineHeight: '1.4',
                      letterSpacing: '-0.01em'
                    }}>
                      正文配圖 ({selectedDocument.contentImages.length})
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3" style={{ gap: '12px' }}>
                      {selectedDocument.contentImages.map((image, index) => (
                        <div 
                          key={index}
                          style={{ 
                            padding: '8px',
                            border: '1px solid #e9e9e7',
                            borderRadius: '8px',
                            backgroundColor: '#fafafa'
                          }}
                        >
                          <img 
                            src={image} 
                            alt={`配圖 ${index + 1}`}
                            className="w-full rounded-md"
                            style={{ 
                              border: '1px solid #e9e9e7',
                              borderRadius: '6px'
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 標籤 - Notion Tag 樣式 */}
                {selectedDocument.tags.length > 0 && (
                  <div className="mb-8" style={{ marginBottom: '32px' }}>
                    <h3 style={{ 
                      fontSize: '20px', 
                      fontWeight: '600', 
                      color: '#37352f', 
                      marginBottom: '16px',
                      fontFamily: 'Inter, sans-serif',
                      lineHeight: '1.4',
                      letterSpacing: '-0.01em'
                    }}>
                      標籤
                    </h3>
                    <div className="flex flex-wrap" style={{ gap: '8px' }}>
                      {selectedDocument.tags.map((tag) => (
                        <span
                          key={tag} 
                          className="hover:bg-gray-200 cursor-pointer transition-colors"
                          style={{ 
                            fontSize: '14px', 
                            fontFamily: 'Inter, sans-serif',
                            backgroundColor: '#e9e9e7',
                            color: '#37352f',
                            padding: '4px 8px',
                            borderRadius: '4px',
                            fontWeight: '400'
                          }}
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* 統計信息 - Notion Callout 樣式 */}
                <div 
                  className="mt-12 rounded-lg" 
                  style={{ 
                    marginTop: '48px',
                    backgroundColor: '#f7f6f3',
                    border: '1px solid #e9e9e7',
                    borderRadius: '8px',
                    padding: '16px'
                  }}
                >
                  <div className="flex items-center" style={{ marginBottom: '16px' }}>
                    <div style={{ 
                      width: '20px',
                      height: '20px',
                      marginRight: '8px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      📊
                    </div>
                    <h3 style={{ 
                      fontSize: '16px', 
                      fontWeight: '600', 
                      color: '#37352f',
                      fontFamily: 'Inter, sans-serif',
                      lineHeight: '1.5',
                      margin: '0'
                    }}>
                      統計信息
                    </h3>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: '16px' }}>
                    <div>
                      <div style={{ 
                        fontSize: '14px', 
                        color: '#9b9a97', 
                        fontFamily: 'Inter, sans-serif',
                        marginBottom: '4px'
                      }}>
                        觀看次數
                      </div>
                      <div style={{ 
                        fontSize: '16px', 
                        fontWeight: '600', 
                        color: '#37352f',
                        fontFamily: 'Inter, sans-serif',
                        lineHeight: '1.5'
                      }}>
                        {selectedDocument.viewCount}
                      </div>
                    </div>
                    <div>
                      <div style={{ 
                        fontSize: '14px', 
                        color: '#9b9a97', 
                        fontFamily: 'Inter, sans-serif',
                        marginBottom: '4px'
                      }}>
                        字數
                      </div>
                      <div style={{ 
                        fontSize: '16px', 
                        fontWeight: '600', 
                        color: '#37352f',
                        fontFamily: 'Inter, sans-serif',
                        lineHeight: '1.5'
                      }}>
                        {selectedDocument.metadata.wordCount}
                      </div>
                    </div>
                    <div>
                      <div style={{ 
                        fontSize: '14px', 
                        color: '#9b9a97', 
                        fontFamily: 'Inter, sans-serif',
                        marginBottom: '4px'
                      }}>
                        參與度
                      </div>
                      <div style={{ 
                        fontSize: '16px', 
                        fontWeight: '600', 
                        color: '#37352f',
                        fontFamily: 'Inter, sans-serif',
                        lineHeight: '1.5'
                      }}>
                        {selectedDocument.engagementScore}%
                      </div>
                    </div>
                    <div>
                      <div style={{ 
                        fontSize: '14px', 
                        color: '#9b9a97', 
                        fontFamily: 'Inter, sans-serif',
                        marginBottom: '4px'
                      }}>
                        閱讀時間
                      </div>
                      <div style={{ 
                        fontSize: '16px', 
                        fontWeight: '600', 
                        color: '#37352f',
                        fontFamily: 'Inter, sans-serif',
                        lineHeight: '1.5'
                      }}>
                        {selectedDocument.metadata.estimatedReadTime}分鐘
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 style={{ 
                fontSize: '24px', 
                fontWeight: '600', 
                color: '#37352f', 
                marginBottom: '8px',
                fontFamily: 'Inter, sans-serif',
                lineHeight: '1.3',
                letterSpacing: '-0.025em'
              }}>
                選擇檔案查看詳情
              </h3>
              <p style={{ 
                fontSize: '16px', 
                color: '#9b9a97',
                fontFamily: 'Inter, sans-serif',
                lineHeight: '1.6'
              }}>
                從左側目錄中選擇一個檔案來查看完整內容
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}