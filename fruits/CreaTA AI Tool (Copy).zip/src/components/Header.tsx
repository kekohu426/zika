import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import { Bell, Sparkles, Zap, ChevronDown, Plus, User, Copy, Edit3, Trash2, ArrowLeftRight, Clock, Settings } from "lucide-react"

interface HeaderProps {
  user: any
  activeProfile?: any
  profiles?: any[]
  onProfileManager: () => void
  onProfileCreate: () => void
  onProfileSelect: (profile: any) => void
  onProfileEdit: (profile: any) => void
  onProfileDelete: (profileId: string) => void
  onProfileDuplicate: (profile: any) => void
}

export default function Header({ user, activeProfile, profiles = [], onProfileManager, onProfileCreate, onProfileSelect, onProfileEdit, onProfileDelete, onProfileDuplicate }: HeaderProps) {
  return (
    <header className="h-16 glass border-b border-apple flex items-center px-6 flex-shrink-0 relative z-50">
      {/* Subtle background pattern */}
      <div className="absolute inset-0 neural-pattern opacity-30"></div>
      
      <div className="flex items-center justify-between w-full relative z-10">
        {/* Logo and brand */}
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-4">
            {/* Premium logo with enhanced design */}
            <div className="relative group">
              {/* Main logo container */}
              <div className="relative w-10 h-10 rounded-2xl shadow-lg overflow-hidden">
                {/* Multi-layer gradient background */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500 via-purple-600 to-pink-500"></div>
                <div className="absolute inset-0 bg-gradient-to-tl from-transparent via-white/10 to-white/20"></div>
                
                {/* Logo content */}
                <div className="relative z-10 w-full h-full flex items-center justify-center">
                  {/* Creative 'C' with neural network inspired design */}
                  <div className="relative">
                    <span className="text-white font-bold text-lg tracking-tight">C</span>
                    {/* Small accent dots for AI/neural effect */}
                    <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-white/80 rounded-full animate-pulse"></div>
                    <div className="absolute -bottom-0.5 -left-0.5 w-1 h-1 bg-white/60 rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
                  </div>
                </div>
                
                {/* Inner highlight */}
                <div className="absolute top-1 left-1 right-1 h-1 bg-gradient-to-r from-white/30 to-transparent rounded-full"></div>
              </div>
              
              {/* Enhanced glow effects */}
              <div className="absolute inset-0 w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-500 via-purple-600 to-pink-500 opacity-20 blur-lg -z-10 group-hover:opacity-30 transition-opacity duration-300"></div>
              <div className="absolute inset-0 w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-400 to-purple-500 opacity-10 blur-xl -z-20 group-hover:opacity-20 transition-opacity duration-300"></div>
            </div>
            
            <div className="flex items-center space-x-3">
              {/* Enhanced brand text */}
              <div className="flex items-baseline space-x-1">
                <h1 className="text-xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-purple-800 bg-clip-text text-transparent tracking-tight">
                  Crea
                </h1>
                <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent tracking-tight">
                  TA
                </h1>
              </div>
              
              {/* Premium AI badge */}
              <div className="relative">
                <Badge className="bg-gradient-to-r from-blue-50 to-purple-50 text-transparent bg-clip-text border border-blue-200/50 shadow-sm px-2.5 py-0.5 text-xs font-semibold">
                  <div className="flex items-center space-x-1">
                    <Sparkles className="w-3 h-3 text-blue-600" />
                    <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">AI</span>
                  </div>
                </Badge>
                {/* Subtle pulse effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full opacity-0 animate-pulse"></div>
              </div>
            </div>
          </div>
          
          {/* Profile Selector - Enhanced */}
          <div className="hidden md:block">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="flex items-center space-x-3 px-4 py-2 h-auto hover:glass-hover rounded-xl border border-transparent hover:border-apple transition-all duration-300"
                >
                  {activeProfile ? (
                    <>
                      <div className="w-8 h-8 gradient-ai rounded-lg flex items-center justify-center shadow-sm">
                        <span className="text-sm font-semibold text-white">
                          {activeProfile.name.charAt(0)}
                        </span>
                      </div>
                      <div className="flex flex-col text-left">
                        <span className="text-sm font-semibold text-gray-900">{activeProfile.name}</span>
                        <span className="text-xs text-gray-500">{activeProfile.coreIdentity}</span>
                      </div>
                      <ChevronDown className="w-4 h-4 text-gray-400" />
                    </>
                  ) : (
                    <>
                      <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                        <User className="w-4 h-4 text-gray-400" />
                      </div>
                      <div className="flex flex-col text-left">
                        <span className="text-sm font-semibold text-gray-900">選擇身份檔案</span>
                        <span className="text-xs text-gray-500">開始創作內容</span>
                      </div>
                      <ChevronDown className="w-4 h-4 text-gray-400" />
                    </>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent 
                align="start" 
                className="w-80 glass border-apple shadow-floating rounded-xl animate-scale-in"
              >
                <DropdownMenuLabel className="text-sm font-semibold px-4 py-3">
                  選擇身份檔案
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                
                {/* Profile List */}
                <div className="max-h-64 overflow-y-auto scrollbar-apple">
                  {profiles.length > 0 ? (
                    profiles.map((profile) => (
                      <div key={profile.id} className="group">
                        <div className="flex items-center justify-between px-4 py-3 hover:glass-hover transition-all duration-200">
                          <div 
                            className="flex items-center space-x-3 flex-1 cursor-pointer"
                            onClick={() => onProfileSelect(profile)}
                          >
                            <div className="w-10 h-10 gradient-ai rounded-lg flex items-center justify-center shadow-sm">
                              <span className="text-sm font-semibold text-white">
                                {profile.name.charAt(0)}
                              </span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center space-x-2">
                                <span className="font-medium text-gray-900 truncate">{profile.name}</span>
                                {activeProfile?.id === profile.id && (
                                  <Badge className="ai-badge text-xs px-2 py-0.5">
                                    <Sparkles className="w-2.5 h-2.5 mr-1" />
                                    活躍
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center space-x-2 mt-1">
                                <span className="text-xs text-gray-500 truncate">{profile.coreIdentity}</span>
                                <div className="flex items-center space-x-1 text-xs text-gray-400">
                                  <Clock className="w-3 h-3" />
                                  <span>{profile.lastUsed}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Profile Actions */}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <Settings className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-48">
                              <DropdownMenuItem onClick={() => onProfileEdit(profile)}>
                                <Edit3 className="w-4 h-4 mr-2" />
                                編輯檔案
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => onProfileDuplicate(profile)}>
                                <Copy className="w-4 h-4 mr-2" />
                                複製檔案
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                onClick={() => onProfileDelete(profile.id)}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                刪除檔案
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-8 text-center">
                      <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                        <User className="w-6 h-6 text-gray-400" />
                      </div>
                      <p className="text-sm text-gray-500 mb-2">尚未建立檔案</p>
                      <p className="text-xs text-gray-400 mb-4">建立您的第一個身份檔案開始使用</p>
                    </div>
                  )}
                </div>
                
                <DropdownMenuSeparator />
                
                {/* Create New Profile */}
                <div className="p-2">
                  <Button
                    onClick={onProfileCreate}
                    className="w-full justify-start gradient-primary text-white hover:shadow-md transition-all duration-300"
                    size="sm"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    建立新檔案
                  </Button>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Mobile Profile Selector */}
        <div className="md:hidden">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-9 px-2 hover:glass-hover rounded-lg mr-2"
              >
                {activeProfile ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 gradient-ai rounded-md flex items-center justify-center">
                      <span className="text-xs font-semibold text-white">
                        {activeProfile.name.charAt(0)}
                      </span>
                    </div>
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-gray-400" />
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  </div>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent 
              align="end" 
              className="w-72 glass border-apple shadow-floating rounded-xl animate-scale-in"
            >
              <DropdownMenuLabel className="text-sm font-semibold px-4 py-3">
                選擇身份檔案
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              
              <div className="max-h-48 overflow-y-auto scrollbar-apple">
                {profiles.length > 0 ? (
                  profiles.slice(0, 3).map((profile) => (
                    <DropdownMenuItem 
                      key={profile.id}
                      onClick={() => onProfileSelect(profile)}
                      className="px-4 py-3 hover:glass-hover"
                    >
                      <div className="flex items-center space-x-3 w-full">
                        <div className="w-8 h-8 gradient-ai rounded-lg flex items-center justify-center">
                          <span className="text-sm font-semibold text-white">
                            {profile.name.charAt(0)}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <span className="font-medium text-gray-900 truncate">{profile.name}</span>
                            {activeProfile?.id === profile.id && (
                              <Badge className="ai-badge text-xs px-1.5 py-0.5">
                                活躍
                              </Badge>
                            )}
                          </div>
                          <span className="text-xs text-gray-500 truncate">{profile.coreIdentity}</span>
                        </div>
                      </div>
                    </DropdownMenuItem>
                  ))
                ) : (
                  <div className="px-4 py-6 text-center">
                    <p className="text-sm text-gray-500 mb-2">尚未建立檔案</p>
                  </div>
                )}
              </div>
              
              <DropdownMenuSeparator />
              <div className="p-2 space-y-1">
                <DropdownMenuItem onClick={onProfileCreate} className="px-3 py-2">
                  <Plus className="w-4 h-4 mr-2" />
                  建立新檔案
                </DropdownMenuItem>
                {profiles.length > 3 && (
                  <DropdownMenuItem onClick={onProfileManager} className="px-3 py-2">
                    <ArrowLeftRight className="w-4 h-4 mr-2" />
                    查看全部檔案
                  </DropdownMenuItem>
                )}
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Right section */}
        <div className="flex items-center space-x-3">
          {/* AI Quick Actions */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-9 px-3 hover:glass-hover neural-glow rounded-lg transition-all duration-300"
          >
            <Zap className="w-4 h-4 mr-2 text-yellow-600" />
            <span className="hidden sm:inline">AI助手</span>
          </Button>

          {/* Notifications */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="relative h-9 w-9 p-0 hover:glass-hover neural-glow rounded-lg transition-all duration-300"
          >
            <Bell className="w-4 h-4" />
            <div className="absolute -top-1 -right-1 w-5 h-5 gradient-primary rounded-full text-xs text-white flex items-center justify-center font-semibold shadow-sm">
              3
            </div>
            {/* Notification pulse */}
            <div className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 rounded-full animate-ping opacity-20"></div>
          </Button>
        </div>
      </div>
    </header>
  )
}