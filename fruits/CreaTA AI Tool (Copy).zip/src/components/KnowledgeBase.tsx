import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Input } from "./ui/input"
import { Textarea } from "./ui/textarea"
import { Label } from "./ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import KnowledgeGraph from "./KnowledgeGraph"
import AIKnowledgeAssistant from "./AIKnowledgeAssistant"
import { 
  Search, 
  BookOpen, 
  Plus,
  Folder,
  FileText,
  Star,
  Clock,
  Filter,
  MoreVertical,
  Heart,
  MessageCircle,
  Share2,
  Edit,
  Trash2,
  Tag,
  GitBranch,
  Bot,
  Brain,
  Sparkles
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"

export default function KnowledgeBase() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedFolder, setSelectedFolder] = useState("all")
  const [isCreatingCollection, setIsCreatingCollection] = useState(false)

  const collections = [
    {
      id: 1,
      name: "小紅書文案範本",
      description: "收集的各類爆款文案範本和寫作技巧",
      itemCount: 28,
      color: "purple",
      createdAt: "2024-01-15",
      tags: ["文案", "範本", "小紅書"]
    },
    {
      id: 2,
      name: "美妝種草內容",
      description: "美妝產品推廣文案和素材收集",
      itemCount: 15,
      color: "pink",
      createdAt: "2024-01-20",
      tags: ["美妝", "種草", "推廣"]
    },
    {
      id: 3,
      name: "科技產品評測",
      description: "科技產品的評測思路和文案框架",
      itemCount: 12,
      color: "blue",
      createdAt: "2024-02-01",
      tags: ["科技", "評測", "框架"]
    },
    {
      id: 4,
      name: "生活方式分享",
      description: "生活方式類內容的創作靈感和素材",
      itemCount: 22,
      color: "green",
      createdAt: "2024-02-10",
      tags: ["生活", "分享", "靈感"]
    }
  ]

  const savedItems = [
    {
      id: 1,
      title: "爆款標題的5個萬能公式",
      type: "template",
      content: "1. 数字型标题：XX个方法让你...\n2. 疑问型标题：为什么XX这么火？\n3. 对比型标题：XX vs XX，哪个更好？...",
      collection: "小红书文案模板",
      collectionColor: "purple",
      savedAt: "2小時前",
      likes: 234,
      views: 1567,
      tags: ["標題", "公式", "爆款"]
    },
    {
      id: 2,
      title: "口红试色文案套路总结",
      type: "note",
      content: "记录各种口红试色的文案写法：\n- 颜色描述要生动形象\n- 适合场合要明确\n- 肤色匹配度说明...",
      collection: "美妆种草内容",
      collectionColor: "pink",
      savedAt: "1天前",
      likes: 89,
      views: 456,
      tags: ["美妆", "口红", "试色"]
    },
    {
      id: 3,
      title: "手机评测文案框架",
      type: "framework",
      content: "手机评测的标准流程：\n1. 外观设计点评\n2. 性能测试数据\n3. 拍照效果对比\n4. 续航表现...",
      collection: "科技产品评测",
      collectionColor: "blue",
      savedAt: "3天前",
      likes: 156,
      views: 892,
      tags: ["手机", "评测", "框架"]
    },
    {
      id: 4,
      title: "早晨routine分享思路",
      type: "inspiration",
      content: "分享早晨routine的切入点：\n- 时间安排的合理性\n- 产品使用的真实感受\n- 生活态度的体现...",
      collection: "生活方式分享",
      collectionColor: "green",
      savedAt: "1周前",
      likes: 67,
      views: 234,
      tags: ["routine", "生活", "分享"]
    }
  ]

  const getColorClasses = (color: string) => {
    const colorMap = {
      purple: "bg-purple-100 text-purple-700 border-purple-200",
      pink: "bg-pink-100 text-pink-700 border-pink-200",
      blue: "bg-blue-100 text-blue-700 border-blue-200",
      green: "bg-green-100 text-green-700 border-green-200"
    }
    return colorMap[color as keyof typeof colorMap] || colorMap.purple
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "template": return <FileText className="w-4 h-4" />
      case "note": return <Edit className="w-4 h-4" />
      case "framework": return <Folder className="w-4 h-4" />
      case "inspiration": return <Star className="w-4 h-4" />
      default: return <FileText className="w-4 h-4" />
    }
  }

  const filteredItems = savedItems.filter(item =>
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="flex items-center space-x-2">
            <BookOpen className="w-6 h-6 text-purple-600" />
            <span>知识库</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            构建您的专属内容知识库，AI自动分析关联，沉淀创作经验和素材
          </p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="outline"
            onClick={() => setIsCreatingCollection(!isCreatingCollection)}
          >
            <Plus className="w-4 h-4 mr-2" />
            新建专题
          </Button>
          <Button variant="outline">
            <GitBranch className="w-4 h-4 mr-2" />
            生成图谱
          </Button>
          <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            添加内容
          </Button>
        </div>
      </div>

      {/* Knowledge Base Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">专题数量</p>
                <p className="text-2xl font-bold">{collections.length}</p>
              </div>
              <Folder className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">内容总数</p>
                <p className="text-2xl font-bold">{savedItems.length}</p>
              </div>
              <FileText className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">AI分析</p>
                <p className="text-2xl font-bold text-green-600">92%</p>
              </div>
              <Brain className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">知识关联</p>
                <p className="text-2xl font-bold text-orange-600">156</p>
              </div>
              <GitBranch className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Create Collection Form */}
      {isCreatingCollection && (
        <Card className="border-2 border-purple-200 bg-purple-50/50">
          <CardHeader>
            <CardTitle className="text-lg">创建新专题</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="collection-name">专题名称</Label>
                <Input id="collection-name" placeholder="输入专题名称..." />
              </div>
              <div className="space-y-2">
                <Label>专题颜色</Label>
                <div className="flex space-x-2">
                  {["purple", "pink", "blue", "green"].map(color => (
                    <div 
                      key={color}
                      className={`w-8 h-8 rounded-full cursor-pointer border-2 ${
                        color === 'purple' ? 'bg-purple-500 border-purple-600' :
                        color === 'pink' ? 'bg-pink-500 border-pink-600' :
                        color === 'blue' ? 'bg-blue-500 border-blue-600' :
                        'bg-green-500 border-green-600'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="collection-desc">专题描述</Label>
              <Textarea 
                id="collection-desc" 
                placeholder="描述这个专题的用途和内容..."
                className="h-20"
              />
            </div>
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setIsCreatingCollection(false)}>
                取消
              </Button>
              <Button className="bg-purple-600 hover:bg-purple-700">
                创建专题
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="collections" className="w-full">
        <TabsList className="grid w-full grid-cols-4 max-w-2xl">
          <TabsTrigger value="collections">专题集合</TabsTrigger>
          <TabsTrigger value="items">全部内容</TabsTrigger>
          <TabsTrigger value="graph">知识图谱</TabsTrigger>
          <TabsTrigger value="ai-assistant">AI助手</TabsTrigger>
        </TabsList>

        <TabsContent value="collections" className="space-y-6">
          {/* Collections Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {collections.map((collection) => (
              <Card key={collection.id} className={`hover:shadow-lg transition-shadow cursor-pointer border-2 ${getColorClasses(collection.color)}`}>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2 flex-1">
                        <h3 className="font-semibold">{collection.name}</h3>
                        <p className="text-sm opacity-80 line-clamp-2">
                          {collection.description}
                        </p>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Edit className="w-4 h-4 mr-2" />
                            编辑
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="w-4 h-4 mr-2" />
                            删除
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {collection.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span className="opacity-80">
                        {collection.itemCount} 个内容
                      </span>
                      <span className="opacity-60">
                        {collection.createdAt}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="items" className="space-y-6">
          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="搜索知识库内容..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              筛选
            </Button>
            <Button variant="outline">
              <Sparkles className="w-4 h-4 mr-2" />
              AI推荐
            </Button>
          </div>

          {/* Saved Items */}
          <div className="space-y-4">
            {filteredItems.map((item) => (
              <Card key={item.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-2">
                            {getTypeIcon(item.type)}
                            <h3 className="font-semibold">{item.title}</h3>
                          </div>
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${getColorClasses(item.collectionColor)}`}
                          >
                            {item.collection}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-3">
                          {item.content}
                        </p>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Edit className="w-4 h-4 mr-2" />
                            编辑
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Share2 className="w-4 h-4 mr-2" />
                            分享
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="w-4 h-4 mr-2" />
                            删除
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {item.tags.map((tag, index) => (
                        <div key={index} className="flex items-center space-x-1 bg-muted/50 rounded-full px-2 py-1">
                          <Tag className="w-3 h-3 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">{tag}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <Heart className="w-4 h-4" />
                          <span>{item.likes}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <MessageCircle className="w-4 h-4" />
                          <span>{item.views}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{item.savedAt}</span>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        查看详情
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="graph" className="space-y-6">
          <KnowledgeGraph />
        </TabsContent>

        <TabsContent value="ai-assistant" className="space-y-6">
          <AIKnowledgeAssistant />
        </TabsContent>
      </Tabs>
    </div>
  )
}