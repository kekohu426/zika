import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Input } from "./ui/input"
import { Progress } from "./ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { 
  GitBranch, 
  Zap, 
  Brain,
  Search,
  Filter,
  Maximize2,
  RotateCcw,
  Download,
  Settings,
  Play,
  Pause,
  Sparkles,
  Target,
  TrendingUp,
  Network,
  Eye,
  EyeOff,
  Layers,
  Share2
} from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select"
import { Slider } from "./ui/slider"

interface GraphNode {
  id: string
  label: string
  type: 'collection' | 'content' | 'tag' | 'concept'
  category: string
  connections: number
  importance: number
  x?: number
  y?: number
  color: string
  size: number
}

interface GraphLink {
  source: string
  target: string
  strength: number
  type: 'related' | 'contains' | 'tagged' | 'similar'
}

export default function KnowledgeGraph() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null)
  const [filterType, setFilterType] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [viewMode, setViewMode] = useState("full")
  const [connectionStrength, setConnectionStrength] = useState([0.3])
  const [isAutoLayout, setIsAutoLayout] = useState(true)

  // Mock graph data
  const graphNodes: GraphNode[] = [
    {
      id: "1",
      label: "小红书文案模板",
      type: "collection",
      category: "营销",
      connections: 15,
      importance: 0.9,
      color: "#8b5cf6",
      size: 24
    },
    {
      id: "2", 
      label: "美妆种草内容",
      type: "collection",
      category: "美妆",
      connections: 12,
      importance: 0.8,
      color: "#ec4899",
      size: 20
    },
    {
      id: "3",
      label: "爆款标题公式",
      type: "content",
      category: "技巧",
      connections: 8,
      importance: 0.7,
      color: "#3b82f6",
      size: 16
    },
    {
      id: "4",
      label: "口红试色文案",
      type: "content", 
      category: "美妆",
      connections: 6,
      importance: 0.6,
      color: "#ec4899",
      size: 14
    },
    {
      id: "5",
      label: "标题写作",
      type: "tag",
      category: "技能",
      connections: 10,
      importance: 0.5,
      color: "#10b981",
      size: 12
    },
    {
      id: "6",
      label: "用户心理",
      type: "concept",
      category: "理论",
      connections: 7,
      importance: 0.8,
      color: "#f59e0b",
      size: 18
    }
  ]

  const graphLinks: GraphLink[] = [
    { source: "1", target: "3", strength: 0.9, type: "contains" },
    { source: "2", target: "4", strength: 0.8, type: "contains" },
    { source: "3", target: "5", strength: 0.7, type: "tagged" },
    { source: "3", target: "6", strength: 0.6, type: "related" },
    { source: "4", target: "6", strength: 0.5, type: "similar" },
    { source: "1", target: "2", strength: 0.4, type: "similar" }
  ]

  const aiInsights = [
    {
      type: "发现关联",
      title: "美妆与心理学的深度关联",
      description: "AI发现您的美妆内容与用户心理学概念有很强的关联性",
      confidence: 0.85,
      suggestedAction: "建议创建心理学驱动的美妆营销专题"
    },
    {
      type: "内容缺口",
      title: "科技数码评测领域待补充",
      description: "您的知识库在科技评测方面内容较少，但该领域与现有内容有潜在关联",
      confidence: 0.72,
      suggestedAction: "建议添加科技产品评测相关内容"
    },
    {
      type: "优化建议",
      title: "标签体系可进一步细化",
      description: "当前标签分类可以更加精细化，提升内容发现效率",
      confidence: 0.68,
      suggestedAction: "建议使用AI自动标签细化功能"
    }
  ]

  // Canvas drawing simulation
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Set canvas size
    canvas.width = canvas.offsetWidth * window.devicePixelRatio
    canvas.height = canvas.offsetHeight * window.devicePixelRatio
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio)

    // Clear canvas
    ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight)

    // Draw background
    ctx.fillStyle = '#f8fafc'
    ctx.fillRect(0, 0, canvas.offsetWidth, canvas.offsetHeight)

    // Mock positions for nodes
    const positions = [
      { x: 200, y: 150 },
      { x: 400, y: 100 },
      { x: 300, y: 250 },
      { x: 500, y: 200 },
      { x: 150, y: 300 },
      { x: 450, y: 320 }
    ]

    // Draw connections
    ctx.strokeStyle = '#e2e8f0'
    ctx.lineWidth = 2
    graphLinks.forEach(link => {
      const sourceIndex = graphNodes.findIndex(n => n.id === link.source)
      const targetIndex = graphNodes.findIndex(n => n.id === link.target)
      
      if (sourceIndex !== -1 && targetIndex !== -1) {
        const sourcePos = positions[sourceIndex]
        const targetPos = positions[targetIndex]
        
        ctx.beginPath()
        ctx.moveTo(sourcePos.x, sourcePos.y)
        ctx.lineTo(targetPos.x, targetPos.y)
        ctx.stroke()
      }
    })

    // Draw nodes
    graphNodes.forEach((node, index) => {
      const pos = positions[index]
      
      // Node circle
      ctx.fillStyle = node.color
      ctx.beginPath()
      ctx.arc(pos.x, pos.y, node.size / 2, 0, 2 * Math.PI)
      ctx.fill()
      
      // Node border
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 3
      ctx.stroke()
      
      // Node label
      ctx.fillStyle = '#1e293b'
      ctx.font = '12px sans-serif'
      ctx.textAlign = 'center'
      ctx.fillText(node.label, pos.x, pos.y + node.size / 2 + 15)
    })

  }, [filterType, connectionStrength])

  const generateGraph = async () => {
    setIsGenerating(true)
    // Simulate AI generation
    await new Promise(resolve => setTimeout(resolve, 2000))
    setIsGenerating(false)
  }

  const getNodeStats = () => {
    const total = graphNodes.length
    const collections = graphNodes.filter(n => n.type === 'collection').length
    const content = graphNodes.filter(n => n.type === 'content').length
    const concepts = graphNodes.filter(n => n.type === 'concept').length
    
    return { total, collections, content, concepts }
  }

  const stats = getNodeStats()

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="flex items-center space-x-2">
            <GitBranch className="w-5 h-5 text-purple-600" />
            <span>知识图谱</span>
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            AI自动分析内容关联，构建智能知识网络
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setIsAutoLayout(!isAutoLayout)}
          >
            <RotateCcw className="w-4 h-4 mr-1" />
            {isAutoLayout ? '停止' : '自动'}布局
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={generateGraph}
            disabled={isGenerating}
          >
            {isGenerating ? (
              <><Pause className="w-4 h-4 mr-1" />生成中...</>
            ) : (
              <><Zap className="w-4 h-4 mr-1" />重新生成</>
            )}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Controls Panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">图谱控制</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-medium">视图模式</label>
                <Select value={viewMode} onValueChange={setViewMode}>
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full">完整视图</SelectItem>
                    <SelectItem value="simplified">简化视图</SelectItem>
                    <SelectItem value="focused">聚焦视图</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium">节点类型</label>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部节点</SelectItem>
                    <SelectItem value="collection">专题集合</SelectItem>
                    <SelectItem value="content">内容节点</SelectItem>
                    <SelectItem value="concept">概念节点</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium">连接强度</label>
                <Slider
                  value={connectionStrength}
                  onValueChange={setConnectionStrength}
                  max={1}
                  min={0}
                  step={0.1}
                  className="w-full"
                />
                <div className="text-xs text-muted-foreground">
                  {Math.round(connectionStrength[0] * 100)}%
                </div>
              </div>

              <div className="space-y-2">
                <Button variant="outline" size="sm" className="w-full">
                  <Download className="w-4 h-4 mr-1" />
                  导出图谱
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Graph Stats */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">图谱统计</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">总节点</span>
                <span className="font-medium">{stats.total}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">专题集合</span>
                <span className="font-medium">{stats.collections}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">内容节点</span>
                <span className="font-medium">{stats.content}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">概念节点</span>
                <span className="font-medium">{stats.concepts}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">连接数</span>
                <span className="font-medium">{graphLinks.length}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Graph View */}
        <div className="lg:col-span-3 space-y-4">
          <Card className="h-96">
            <CardContent className="p-0 relative h-full">
              {isGenerating && (
                <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-10">
                  <div className="text-center space-y-2">
                    <div className="w-8 h-8 border-2 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
                    <p className="text-sm text-muted-foreground">AI正在分析知识关联...</p>
                  </div>
                </div>
              )}
              <canvas 
                ref={canvasRef}
                className="w-full h-full cursor-pointer"
                style={{ width: '100%', height: '100%' }}
              />
              
              {/* Graph Controls Overlay */}
              <div className="absolute top-4 right-4 flex space-x-2">
                <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                  <Maximize2 className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                  <Settings className="w-4 h-4" />
                </Button>
              </div>

              {/* Legend */}
              <div className="absolute bottom-4 left-4 bg-background/90 backdrop-blur-sm rounded-lg p-3 border space-y-2">
                <div className="text-xs font-medium">节点类型</div>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                    <span>专题集合</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <span>内容节点</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                    <span>概念节点</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Node Details */}
          {selectedNode && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center space-x-2">
                  <span>节点详情</span>
                  <Badge variant="outline" className="text-xs">
                    {selectedNode.type}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <h4 className="font-medium">{selectedNode.label}</h4>
                  <p className="text-sm text-muted-foreground">类别: {selectedNode.category}</p>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground">连接数</div>
                    <div className="font-medium">{selectedNode.connections}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">重要度</div>
                    <div className="font-medium">{Math.round(selectedNode.importance * 100)}%</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">影响力</div>
                    <div className="font-medium">高</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* AI Insights */}
      <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-purple-700">
            <Brain className="w-5 h-5" />
            <span>AI 智能洞察</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {aiInsights.map((insight, index) => (
            <div key={index} className="bg-white rounded-lg p-4 border border-purple-100">
              <div className="flex items-start justify-between">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary" className="text-xs bg-purple-100 text-purple-700">
                      {insight.type}
                    </Badge>
                    <div className="flex items-center space-x-1">
                      <Sparkles className="w-4 h-4 text-yellow-500" />
                      <span className="text-sm text-muted-foreground">
                        置信度 {Math.round(insight.confidence * 100)}%
                      </span>
                    </div>
                  </div>
                  <h4 className="font-medium text-purple-700">{insight.title}</h4>
                  <p className="text-sm text-muted-foreground">{insight.description}</p>
                  <div className="text-sm text-purple-600 font-medium">
                    💡 {insight.suggestedAction}
                  </div>
                </div>
                <Button size="sm" variant="outline" className="text-purple-600 border-purple-200">
                  应用建议
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}