import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Input } from "./ui/input"
import { 
  User, 
  Plus,
  Settings,
  Edit,
  Trash2,
  Check,
  Star,
  Users,
  Target,
  Crown,
  Shield,
  MoreVertical,
  Copy,
  Eye,
  EyeOff
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog"

interface ProfileData {
  id: string
  name: string
  nickname: string
  coreIdentity: string
  oldIdentity: string
  newIdentity: string
  targetPlatform: string[]
  audienceA: string
  audienceB: string
  creatorValue: string
  contentPillar1: string
  contentPillar2: string
  contentPillar3: string
  commonQuestions: string[]
  proudAchievements: string[]
  avoidTags: string[]
  coreValues: string
  sensitiveWords: string[]
  products: string[]
  createdAt: string
  lastUsed: string
  isActive: boolean
}

interface ProfileManagerProps {
  profiles: ProfileData[]
  activeProfile: ProfileData | null
  onProfileSelect: (profile: ProfileData) => void
  onProfileCreate: () => void
  onProfileEdit: (profile: ProfileData) => void
  onProfileDelete: (profileId: string) => void
  onProfileDuplicate: (profile: ProfileData) => void
}

export default function ProfileManager({ 
  profiles, 
  activeProfile, 
  onProfileSelect,
  onProfileCreate,
  onProfileEdit,
  onProfileDelete,
  onProfileDuplicate
}: ProfileManagerProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [showDetails, setShowDetails] = useState<string | null>(null)

  const filteredProfiles = profiles.filter(profile =>
    profile.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    profile.coreIdentity.toLowerCase().includes(searchTerm.toLowerCase()) ||
    profile.targetPlatform.some(platform => platform.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  const getPlatformEmoji = (platform: string) => {
    const emojiMap: { [key: string]: string } = {
      'xiaohongshu': '📱',
      'douyin': '🎵',
      'weibo': '🐦',
      'wechat': '💬',
      'zhihu': '🤔',
      'bilibili': '📺'
    }
    return emojiMap[platform] || '📝'
  }

  const getPlatformLabel = (platform: string) => {
    const labelMap: { [key: string]: string } = {
      'xiaohongshu': '小紅書',
      'douyin': '抖音',
      'weibo': '微博',
      'wechat': '微信公眾號',
      'zhihu': '知乎',
      'bilibili': 'B站'
    }
    return labelMap[platform] || platform
  }

  const getCompletionScore = (profile: ProfileData) => {
    const fields = [
      profile.name,
      profile.coreIdentity,
      profile.audienceA,
      profile.audienceB,
      profile.creatorValue,
      profile.contentPillar1,
      profile.contentPillar2,
      profile.contentPillar3,
      profile.coreValues,
      ...profile.commonQuestions.filter(q => q.trim()),
      ...profile.proudAchievements.filter(a => a.trim()),
      ...profile.avoidTags.filter(t => t.trim())
    ]
    const filledFields = fields.filter(field => field && field.trim()).length
    return Math.round((filledFields / fields.length) * 100)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-purple-600" />
            <span>身份檔案管理</span>
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            管理您的多個身份檔案，快速切換不同創作身份
          </p>
        </div>
        <Button 
          onClick={onProfileCreate}
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          建立新身份
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Input
          placeholder="搜尋身份檔案..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
      </div>

      {/* Profiles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredProfiles.map((profile) => (
          <Card 
            key={profile.id} 
            className={`cursor-pointer transition-all hover:shadow-lg ${
              activeProfile?.id === profile.id 
                ? 'ring-2 ring-purple-500 bg-purple-50/50' 
                : 'hover:ring-1 hover:ring-purple-200'
            }`}
            onClick={() => onProfileSelect(profile)}
          >
            <CardContent className="p-6">
              <div className="space-y-4">
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback className="bg-gradient-to-br from-purple-600 to-blue-600 text-white font-medium">
                        {profile.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-semibold truncate">{profile.name}</h3>
                        {activeProfile?.id === profile.id && (
                          <Badge variant="default" className="bg-purple-600">
                            <Check className="w-3 h-3 mr-1" />
                            使用中
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {profile.nickname || profile.coreIdentity}
                      </p>
                    </div>
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onProfileEdit(profile) }}>
                        <Edit className="w-4 h-4 mr-2" />
                        編輯
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onProfileDuplicate(profile) }}>
                        <Copy className="w-4 h-4 mr-2" />
                        複製
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={(e) => { e.stopPropagation(); setShowDetails(showDetails === profile.id ? null : profile.id) }}
                      >
                        {showDetails === profile.id ? (
                          <>
                            <EyeOff className="w-4 h-4 mr-2" />
                            隱藏詳情
                          </>
                        ) : (
                          <>
                            <Eye className="w-4 h-4 mr-2" />
                            查看詳情
                          </>
                        )}
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={(e) => { e.stopPropagation(); onProfileDelete(profile.id) }}
                        className="text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        刪除
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {/* Identity Info */}
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm font-medium">{profile.coreIdentity}</span>
                  </div>
                  
                  {/* Platforms */}
                  <div className="flex flex-wrap gap-1">
                    {profile.targetPlatform.slice(0, 3).map((platform) => (
                      <Badge key={platform} variant="secondary" className="text-xs">
                        {getPlatformEmoji(platform)} {getPlatformLabel(platform)}
                      </Badge>
                    ))}
                    {profile.targetPlatform.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{profile.targetPlatform.length - 3}
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Completion Progress */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">檔案完整度</span>
                    <span className="font-medium">{getCompletionScore(profile)}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full transition-all" 
                      style={{ width: `${getCompletionScore(profile)}%` }}
                    />
                  </div>
                </div>

                {/* Meta Info */}
                <div className="text-xs text-muted-foreground space-y-1 border-t pt-2">
                  <div>建立時間: {profile.createdAt}</div>
                  <div>最後使用: {profile.lastUsed}</div>
                </div>

                {/* Detailed Info (expandable) */}
                {showDetails === profile.id && (
                  <div className="border-t pt-4 space-y-3 text-sm" onClick={(e) => e.stopPropagation()}>
                    <div>
                      <span className="font-medium text-muted-foreground">身份轉換:</span>
                      <p className="mt-1">{profile.oldIdentity} → {profile.newIdentity}</p>
                    </div>
                    
                    <div>
                      <span className="font-medium text-muted-foreground">受眾群體:</span>
                      <p className="mt-1">A: {profile.audienceA.slice(0, 50)}...</p>
                      <p>B: {profile.audienceB.slice(0, 50)}...</p>
                    </div>
                    
                    <div>
                      <span className="font-medium text-muted-foreground">核心價值觀:</span>
                      <p className="mt-1">{profile.coreValues.slice(0, 80)}...</p>
                    </div>

                    <div>
                      <span className="font-medium text-muted-foreground">內容支柱:</span>
                      <div className="mt-1 space-y-1">
                        {profile.contentPillar1 && <p>• {profile.contentPillar1.slice(0, 40)}...</p>}
                        {profile.contentPillar2 && <p>• {profile.contentPillar2.slice(0, 40)}...</p>}
                        {profile.contentPillar3 && <p>• {profile.contentPillar3.slice(0, 40)}...</p>}
                      </div>
                    </div>

                    {profile.products.length > 0 && (
                      <div>
                        <span className="font-medium text-muted-foreground">引流產品:</span>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {profile.products.slice(0, 3).map((product, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {product}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredProfiles.length === 0 && (
        <Card className="text-center p-12">
          <User className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">
            {searchTerm ? '沒有找到匹配的身份檔案' : '還沒有建立身份檔案'}
          </h3>
          <p className="text-muted-foreground mb-6">
            {searchTerm 
              ? '嘗試使用其他關鍵詞搜尋，或建立新的身份檔案' 
              : '建立您的第一個身份檔案，開始個人化的內容創作'
            }
          </p>
          <Button 
            onClick={onProfileCreate}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            {searchTerm ? '建立新身份' : '開始建立'}
          </Button>
        </Card>
      )}

      {/* Active Profile Summary (if exists) */}
      {activeProfile && (
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Avatar className="w-10 h-10">
                  <AvatarFallback className="bg-gradient-to-br from-purple-600 to-blue-600 text-white">
                    {activeProfile.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-purple-700">{activeProfile.name}</span>
                    <Badge className="bg-purple-600">目前身份</Badge>
                  </div>
                  <p className="text-sm text-purple-600">{activeProfile.coreIdentity}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-purple-600">
                  完整度 {getCompletionScore(activeProfile)}%
                </span>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => onProfileEdit(activeProfile)}
                  className="border-purple-200 text-purple-600 hover:bg-purple-100"
                >
                  <Settings className="w-4 h-4 mr-2" />
                  編輯檔案
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}