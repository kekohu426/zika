import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Textarea } from "./ui/textarea"
import { Label } from "./ui/label"
import { Progress } from "./ui/progress"
import { Badge } from "./ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { 
  User, 
  Users, 
  Target, 
  Crown,
  FileText,
  Mic,
  Upload,
  Check,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Brain,
  Heart,
  Shield,
  Zap,
  Plus,
  X
} from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select"

interface ProfileData {
  // 主理人基本資料
  name: string
  nickname: string
  coreIdentity: string
  oldIdentity: string
  newIdentity: string
  targetPlatform: string[]
  
  // 3×3內容矩陣
  audienceA: string
  audienceB: string
  creatorValue: string
  contentPillar1: string
  contentPillar2: string
  contentPillar3: string
  
  // 爆款基因
  commonQuestions: string[]
  proudAchievements: string[]
  avoidTags: string[]
  
  // 特殊要求
  coreValues: string
  sensitiveWords: string[]
  products: string[]
}

interface ProfileSetupProps {
  userData: any
  onComplete: (profileData: ProfileData) => void
  onSkip: () => void
}

export default function ProfileSetup({ userData, onComplete, onSkip }: ProfileSetupProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [isRecording, setIsRecording] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [profileData, setProfileData] = useState<ProfileData>({
    name: userData.name || '',
    nickname: '',
    coreIdentity: '',
    oldIdentity: '',
    newIdentity: '',
    targetPlatform: [],
    audienceA: '',
    audienceB: '',
    creatorValue: '',
    contentPillar1: '',
    contentPillar2: '',
    contentPillar3: '',
    commonQuestions: ['', '', ''],
    proudAchievements: ['', '', ''],
    avoidTags: ['', '', ''],
    coreValues: '',
    sensitiveWords: [],
    products: []
  })

  const totalSteps = 4
  const progress = (currentStep / totalSteps) * 100

  const platforms = [
    { value: 'xiaohongshu', label: '小紅書', icon: '📕', color: 'from-red-100 to-pink-100', selectedColor: 'from-red-50 to-pink-50' },
    { value: 'douyin', label: '抖音', icon: '🎵', color: 'from-gray-100 to-slate-100', selectedColor: 'from-gray-50 to-slate-50' },
    { value: 'weibo', label: '微博', icon: '🐦', color: 'from-orange-100 to-yellow-100', selectedColor: 'from-orange-50 to-yellow-50' },
    { value: 'wechat', label: '微信公眾號', icon: '💬', color: 'from-green-100 to-emerald-100', selectedColor: 'from-green-50 to-emerald-50' },
    { value: 'zhihu', label: '知乎', icon: '💡', color: 'from-blue-100 to-indigo-100', selectedColor: 'from-blue-50 to-indigo-50' },
    { value: 'bilibili', label: 'B站', icon: '📺', color: 'from-pink-100 to-purple-100', selectedColor: 'from-pink-50 to-purple-50' }
  ]

  const updateProfileData = (field: keyof ProfileData, value: any) => {
    setProfileData(prev => ({ ...prev, [field]: value }))
  }

  const updateArrayField = (field: keyof ProfileData, index: number, value: string) => {
    const array = [...(profileData[field] as string[])]
    array[index] = value
    setProfileData(prev => ({ ...prev, [field]: array }))
  }

  const addToArray = (field: keyof ProfileData, value: string = '') => {
    const array = [...(profileData[field] as string[]), value]
    setProfileData(prev => ({ ...prev, [field]: array }))
  }

  const removeFromArray = (field: keyof ProfileData, index: number) => {
    const array = (profileData[field] as string[]).filter((_, i) => i !== index)
    setProfileData(prev => ({ ...prev, [field]: array }))
  }

  const handleVoiceInput = async () => {
    setIsRecording(true)
    // Simulate voice recording
    await new Promise(resolve => setTimeout(resolve, 3000))
    setIsRecording(false)
    // In real app, convert speech to text and fill form
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    
    setIsUploading(true)
    // Simulate AI processing of uploaded material
    await new Promise(resolve => setTimeout(resolve, 2000))
    setIsUploading(false)
    
    // Mock AI auto-fill
    setProfileData(prev => ({
      ...prev,
      coreIdentity: "美妝博主",
      oldIdentity: "傳統美妝推薦者",
      newIdentity: "科學護膚倡導者",
      audienceA: "18-25歲護膚新手",
      audienceB: "25-35歲精緻女性"
    }))
  }

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1)
    } else {
      onComplete(profileData)
    }
  }

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return profileData.name && profileData.coreIdentity && profileData.targetPlatform.length > 0
      case 2:
        return profileData.audienceA && profileData.audienceB && profileData.creatorValue
      case 3:
        return profileData.commonQuestions.every(q => q.trim()) && 
               profileData.proudAchievements.every(a => a.trim()) &&
               profileData.avoidTags.every(t => t.trim())
      case 4:
        return profileData.coreValues
      default:
        return false
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 p-3 sm:p-4 lg:p-6 neural-pattern">
      <div className="max-w-5xl mx-auto space-y-6 sm:space-y-8">
        {/* Header */}
        <div className="text-center space-y-4 sm:space-y-6 animate-fade-in-up px-2">
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xl sm:text-2xl">C</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent text-center sm:text-left">
              CreaTA 身份檔案設定
            </h1>
          </div>
          <p className="text-gray-600 text-base sm:text-lg max-w-2xl mx-auto">
            建立您的專屬身份檔案，讓AI更了解您的創作需求
          </p>
          
          {/* Progress */}
          <div className="max-w-sm sm:max-w-md mx-auto space-y-3">
            <div className="flex justify-between text-sm text-gray-600">
              <span>步驟 {currentStep} / {totalSteps}</span>
              <span>{Math.round(progress)}% 完成</span>
            </div>
            <Progress value={progress} className="h-2 sm:h-3" />
          </div>
        </div>

        {/* AI助手提示 */}
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-100/50 shadow-lg animate-scale-in">
          <CardContent className="p-4 sm:p-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-purple-100 to-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                <Brain className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-purple-700 text-base sm:text-lg">智能填寫助手</h3>
                <p className="text-purple-600 text-sm sm:text-base">
                  您可以透過語音輸入或上傳資料，AI將自動幫您填寫表單
                </p>
              </div>
              <div className="flex flex-row sm:flex-row space-x-2 sm:space-x-3 w-full sm:w-auto">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleVoiceInput}
                  disabled={isRecording}
                  className="flex-1 sm:flex-none border-2 border-purple-200 text-purple-600 hover:bg-purple-50 transition-all duration-300 text-xs sm:text-sm"
                >
                  {isRecording ? (
                    <>
                      <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse mr-1 sm:mr-2"></div>
                      <span className="hidden sm:inline">录音中...</span>
                      <span className="sm:hidden">录音</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                      <span className="hidden sm:inline">语音输入</span>
                      <span className="sm:hidden">语音</span>
                    </>
                  )}
                </Button>
                <div className="relative flex-1 sm:flex-none">
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx,.txt"
                    onChange={handleFileUpload}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    disabled={isUploading}
                  />
                  <Button 
                    variant="outline" 
                    size="sm"
                    disabled={isUploading}
                    className="w-full border-2 border-purple-200 text-purple-600 hover:bg-purple-50 transition-all duration-300 text-xs sm:text-sm"
                  >
                    {isUploading ? (
                      <>
                        <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-purple-600 border-t-transparent rounded-full animate-spin mr-1 sm:mr-2"></div>
                        <span className="hidden sm:inline">處理中...</span>
                        <span className="sm:hidden">處理</span>
                      </>
                    ) : (
                      <>
                        <Upload className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                        <span className="hidden sm:inline">上傳資料</span>
                        <span className="sm:hidden">上傳</span>
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Step Content */}
        <Card className="shadow-2xl bg-white/90 backdrop-blur-xl animate-scale-in">
          <CardContent className="p-4 sm:p-6 lg:p-8">
            {/* Step 1: 基础信息 */}
            {currentStep === 1 && (
              <div className="space-y-8">
                <div className="text-center space-y-3 sm:space-y-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-purple-100 to-purple-50 rounded-2xl flex items-center justify-center mx-auto">
                    <User className="w-6 h-6 sm:w-8 sm:h-8 text-purple-600" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-semibold text-gray-800">主理人基本資料</h2>
                  <p className="text-gray-600 text-sm sm:text-base">告訴我們您的基本資料和身份定位</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="name" className="label-enhanced">真實姓名 *</Label>
                    <Input
                      id="name"
                      value={profileData.name}
                      onChange={(e) => updateProfileData('name', e.target.value)}
                      placeholder="輸入您的真實姓名"
                      className="input-enhanced"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="nickname" className="label-enhanced">對外暱稱</Label>
                    <Input
                      id="nickname"
                      value={profileData.nickname}
                      onChange={(e) => updateProfileData('nickname', e.target.value)}
                      placeholder="您希望別人如何稱呼您"
                      className="input-enhanced"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="coreIdentity" className="label-enhanced">核心身份 *</Label>
                    <Input
                      id="coreIdentity"
                      value={profileData.coreIdentity}
                      onChange={(e) => updateProfileData('coreIdentity', e.target.value)}
                      placeholder="例如：美妝博主、科技評測師"
                      className="input-enhanced"
                    />
                  </div>

                  <div className="space-y-4 lg:col-span-2">
                    <Label htmlFor="targetPlatform" className="label-enhanced">目標平台 *</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
                      {platforms.map((platform) => (
                        <div 
                          key={platform.value} 
                          className={`
                            relative group cursor-pointer rounded-2xl border-2 transition-all duration-300 overflow-hidden
                            transform hover:scale-[1.02] active:scale-[0.98]
                            ${profileData.targetPlatform.includes(platform.value) 
                              ? 'border-blue-500 bg-gradient-to-br from-blue-50 to-purple-50 shadow-xl shadow-blue-100/50 ring-2 ring-blue-100' 
                              : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-lg hover:shadow-gray-100/50'
                            }
                          `}
                          onClick={() => {
                            if (profileData.targetPlatform.includes(platform.value)) {
                              updateProfileData('targetPlatform', profileData.targetPlatform.filter(p => p !== platform.value))
                            } else {
                              updateProfileData('targetPlatform', [...profileData.targetPlatform, platform.value])
                            }
                          }}
                        >
                          {/* Selection indicator */}
                          <div className={`
                            absolute top-3 right-3 w-5 h-5 rounded-full border-2 transition-all duration-300
                            ${profileData.targetPlatform.includes(platform.value)
                              ? 'bg-blue-500 border-blue-500 shadow-sm'
                              : 'border-gray-300 bg-white group-hover:border-gray-400'
                            }
                          `}>
                            {profileData.targetPlatform.includes(platform.value) && (
                              <div className="absolute inset-0 flex items-center justify-center">
                                <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                </svg>
                              </div>
                            )}
                          </div>

                          {/* Content */}
                          <div className="p-4 sm:p-5 text-center">
                            <div className={`
                              inline-flex items-center justify-center w-12 h-12 sm:w-14 sm:h-14 rounded-2xl mb-3 transition-all duration-300
                              ${profileData.targetPlatform.includes(platform.value)
                                ? `bg-gradient-to-br ${platform.selectedColor} shadow-sm`
                                : `bg-gradient-to-br ${platform.color} group-hover:shadow-sm group-hover:scale-105`
                              }
                            `}>
                              <span className="text-2xl sm:text-3xl">{platform.icon}</span>
                            </div>
                            <h3 className={`
                              font-semibold text-sm sm:text-base transition-colors duration-300 leading-tight
                              ${profileData.targetPlatform.includes(platform.value)
                                ? 'text-blue-700'
                                : 'text-gray-700 group-hover:text-gray-900'
                              }
                            `}>
                              {platform.label}
                            </h3>
                            <div className={`
                              mt-1 text-xs transition-colors duration-300
                              ${profileData.targetPlatform.includes(platform.value)
                                ? 'text-blue-600'
                                : 'text-gray-500 group-hover:text-gray-600'
                              }
                            `}>
                              {profileData.targetPlatform.includes(platform.value) ? '已選擇' : '點擊選擇'}
                            </div>
                          </div>

                          {/* Selected overlay effect */}
                          {profileData.targetPlatform.includes(platform.value) && (
                            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 pointer-events-none animate-pulse" />
                          )}

                          {/* Hover shimmer effect */}
                          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-shimmer" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="lg:col-span-2 space-y-3">
                    <Label htmlFor="oldIdentity" className="label-enhanced">一句話舊身份</Label>
                    <Input
                      id="oldIdentity"
                      value={profileData.oldIdentity}
                      onChange={(e) => updateProfileData('oldIdentity', e.target.value)}
                      placeholder="過去您是如何定位自己的"
                      className="input-enhanced"
                    />
                  </div>

                  <div className="lg:col-span-2 space-y-3">
                    <Label htmlFor="newIdentity" className="label-enhanced">一句話新身份</Label>
                    <Input
                      id="newIdentity"
                      value={profileData.newIdentity}
                      onChange={(e) => updateProfileData('newIdentity', e.target.value)}
                      placeholder="現在您希望如何重新定位自己"
                      className="input-enhanced"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: 3*3内容矩陣 */}
            {currentStep === 2 && (
              <div className="space-y-8">
                <div className="text-center space-y-3 sm:space-y-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-100 to-blue-50 rounded-2xl flex items-center justify-center mx-auto">
                    <Users className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-semibold text-gray-800">3×3內容矩陣定義</h2>
                  <p className="text-gray-600 text-sm sm:text-base">定義您的受眾群體和內容架構</p>
                </div>

                <div className="space-y-4 sm:space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                    <div className="space-y-3">
                      <Label htmlFor="audienceA" className="label-enhanced">受眾群體 A *</Label>
                      <Textarea
                        id="audienceA"
                        value={profileData.audienceA}
                        onChange={(e) => updateProfileData('audienceA', e.target.value)}
                        placeholder="描述您的第一個主要受眾群體，包括年齡、特徵、需求等"
                        className="textarea-enhanced min-h-20"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="audienceB" className="label-enhanced">受眾群體 B *</Label>
                      <Textarea
                        id="audienceB"
                        value={profileData.audienceB}
                        onChange={(e) => updateProfileData('audienceB', e.target.value)}
                        placeholder="描述您的第二個主要受眾群體"
                        className="textarea-enhanced min-h-20"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="creatorValue" className="label-enhanced">主理人價值 *</Label>
                    <Textarea
                      id="creatorValue"
                      value={profileData.creatorValue}
                      onChange={(e) => updateProfileData('creatorValue', e.target.value)}
                      placeholder="您能為受眾提供什麼獨特價值？您的專業優勢是什麼？"
                      className="textarea-enhanced min-h-20"
                    />
                  </div>

                  <div className="space-y-4">
                    <Label className="label-enhanced">3層內容細分指令（3個內容支柱）</Label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      <div className="space-y-3">
                        <Label htmlFor="pillar1" className="text-sm text-gray-600 font-medium">內容支柱 1</Label>
                        <Textarea
                          id="pillar1"
                          value={profileData.contentPillar1}
                          onChange={(e) => updateProfileData('contentPillar1', e.target.value)}
                          placeholder="第一個核心內容方向"
                          className="textarea-enhanced min-h-24"
                        />
                      </div>
                      <div className="space-y-3">
                        <Label htmlFor="pillar2" className="text-sm text-gray-600 font-medium">內容支柱 2</Label>
                        <Textarea
                          id="pillar2"
                          value={profileData.contentPillar2}
                          onChange={(e) => updateProfileData('contentPillar2', e.target.value)}
                          placeholder="第二個核心內容方向"
                          className="textarea-enhanced min-h-24"
                        />
                      </div>
                      <div className="space-y-3">
                        <Label htmlFor="pillar3" className="text-sm text-gray-600 font-medium">內容支柱 3</Label>
                        <Textarea
                          id="pillar3"
                          value={profileData.contentPillar3}
                          onChange={(e) => updateProfileData('contentPillar3', e.target.value)}
                          placeholder="第三個核心內容方向"
                          className="textarea-enhanced min-h-24"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: 爆款基因 */}
            {currentStep === 3 && (
              <div className="space-y-8">
                <div className="text-center space-y-3 sm:space-y-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-yellow-100 to-yellow-50 rounded-2xl flex items-center justify-center mx-auto">
                    <Crown className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-600" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-semibold text-gray-800">爆款基因設定</h2>
                  <p className="text-gray-600 text-sm sm:text-base">設定您的內容爆款潛力基因</p>
                </div>

                <div className="space-y-8">
                  <div className="space-y-4">
                    <Label className="label-enhanced">常被問的3個問題</Label>
                    {profileData.commonQuestions.map((question, index) => (
                      <div key={index} className="space-y-2">
                        <Label htmlFor={`question-${index}`} className="text-sm text-gray-600 font-medium">問題 {index + 1}</Label>
                        <Input
                          id={`question-${index}`}
                          value={question}
                          onChange={(e) => updateArrayField('commonQuestions', index, e.target.value)}
                          placeholder={`受眾經常問您的第${index + 1}個問題`}
                          className="input-enhanced"
                        />
                      </div>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <Label className="label-enhanced">最引以為傲的3個成就/案例</Label>
                    {profileData.proudAchievements.map((achievement, index) => (
                      <div key={index} className="space-y-2">
                        <Label htmlFor={`achievement-${index}`} className="text-sm text-gray-600 font-medium">成就 {index + 1}</Label>
                        <Input
                          id={`achievement-${index}`}
                          value={achievement}
                          onChange={(e) => updateArrayField('proudAchievements', index, e.target.value)}
                          placeholder={`您最驕傲的第${index + 1}個成就或案例`}
                          className="input-enhanced"
                        />
                      </div>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <Label className="label-enhanced">最想避開的3個標籤</Label>
                    {profileData.avoidTags.map((tag, index) => (
                      <div key={index} className="space-y-2">
                        <Label htmlFor={`tag-${index}`} className="text-sm text-gray-600 font-medium">標籤 {index + 1}</Label>
                        <Input
                          id={`tag-${index}`}
                          value={tag}
                          onChange={(e) => updateArrayField('avoidTags', index, e.target.value)}
                          placeholder={`您不希望被貼上的第${index + 1}個標籤`}
                          className="input-enhanced"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: 特殊要求 */}
            {currentStep === 4 && (
              <div className="space-y-8">
                <div className="text-center space-y-3 sm:space-y-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-green-100 to-green-50 rounded-2xl flex items-center justify-center mx-auto">
                    <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-green-600" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-semibold text-gray-800">特殊要求設定</h2>
                  <p className="text-gray-600 text-sm sm:text-base">設定您的價值觀和特殊需求</p>
                </div>

                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label htmlFor="coreValues" className="label-enhanced">最強調的價值觀 *</Label>
                    <Textarea
                      id="coreValues"
                      value={profileData.coreValues}
                      onChange={(e) => updateProfileData('coreValues', e.target.value)}
                      placeholder="描述您最重視的價值觀，這將影響AI為您產生的內容風格"
                      className="textarea-enhanced min-h-24"
                    />
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="label-enhanced">需避開的敏感詞</Label>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => addToArray('sensitiveWords')}
                        className="border-2 border-blue-200 text-blue-600 hover:bg-blue-50"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        新增敏感詞
                      </Button>
                    </div>
                    <div className="space-y-3">
                      {profileData.sensitiveWords.map((word, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <Input
                            value={word}
                            onChange={(e) => updateArrayField('sensitiveWords', index, e.target.value)}
                            placeholder="輸入需要避開的敏感詞"
                            className="input-enhanced"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removeFromArray('sensitiveWords', index)}
                            className="h-12 px-3 border-2 border-red-200 text-red-600 hover:bg-red-50"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="label-enhanced">希望植入引流的產品</Label>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => addToArray('products')}
                        className="border-2 border-blue-200 text-blue-600 hover:bg-blue-50"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        新增產品
                      </Button>
                    </div>
                    <div className="space-y-3">
                      {profileData.products.map((product, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <Input
                            value={product}
                            onChange={(e) => updateArrayField('products', index, e.target.value)}
                            placeholder="輸入產品名稱或服務"
                            className="input-enhanced"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removeFromArray('products', index)}
                            className="h-12 px-3 border-2 border-red-200 text-red-600 hover:bg-red-50"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between pt-6 sm:pt-8 border-t-2 border-gray-100 space-y-3 sm:space-y-0">
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4 order-2 sm:order-1">
                {currentStep > 1 && (
                  <Button 
                    variant="outline" 
                    onClick={prevStep}
                    className="h-11 sm:h-12 px-4 sm:px-6 border-2 border-gray-200 text-gray-600 hover:bg-gray-50 text-sm sm:text-base"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    上一步
                  </Button>
                )}
                <Button 
                  variant="ghost" 
                  onClick={onSkip} 
                  className="h-11 sm:h-12 px-4 sm:px-6 text-gray-500 hover:text-gray-700 hover:bg-gray-50 text-sm sm:text-base"
                >
                  跳過設定
                </Button>
              </div>

              <Button 
                onClick={nextStep}
                disabled={!canProceed()}
                className="h-12 sm:h-12 px-6 sm:px-8 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 
                         shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-300 button-press 
                         order-1 sm:order-2 text-sm sm:text-base font-medium"
              >
                {currentStep === totalSteps ? (
                  <>
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                    完成設定
                  </>
                ) : (
                  <>
                    下一步
                    <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}