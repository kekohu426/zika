import { useState } from "react"
import { Button } from "./ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Textarea } from "./ui/textarea"
import { Switch } from "./ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Badge } from "./ui/badge"
import { Separator } from "./ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Progress } from "./ui/progress"
import { Alert, AlertDescription } from "./ui/alert"
import { 
  Settings as SettingsIcon,
  User,
  Bell,
  Shield,
  CreditCard,
  Database,
  Save,
  LogOut,
  AlertTriangle,
  Crown,
  Users,
  Activity,
  Check,
  Camera,
  Upload,
  Edit3,
  Plus,
  Trash2,
  Mail,
  Phone,
  MapPin,
  Building,
  Globe,
  Clock,
  Palette,
  Volume2,
  Eye,
  Lock,
  Key,
  Smartphone,
  Monitor,
  Moon,
  Sun,
  Languages,
  HardDrive,
  Download,
  RefreshCw,
  Sliders,
  Zap,
  Star,
  Gift,
  ChevronRight,
  ExternalLink,
  Info,
  TrendingUp,
  BarChart3,
  Calendar,
  FileText,
  Target,
  Sparkles,
  Award,
  MessageSquare
} from "lucide-react"

interface UserData {
  id: string
  email: string
  name: string
  profiles: ProfileData[]
}

interface ProfileData {
  id: string
  name: string
  nickname: string
  coreIdentity: string
  oldIdentity: string
  newIdentity: string
  targetPlatform: string[]
  createdAt: string
  lastUsed: string
  isActive: boolean
}

interface SettingsProps {
  user: UserData | null
  activeProfile: ProfileData | null
  profiles: ProfileData[]
  onUserUpdate: (userData: UserData) => void
  onProfileSelect: (profile: ProfileData) => void
  onProfileCreate: () => void
  onProfileEdit: (profile: ProfileData) => void
  onProfileDelete: (profileId: string) => void
  onProfileDuplicate: (profile: ProfileData) => void
  onLogout: () => void
}

export default function Settings({
  user,
  activeProfile,
  profiles,
  onUserUpdate,
  onProfileSelect,
  onProfileCreate,
  onProfileEdit,
  onProfileDelete,
  onProfileDuplicate,
  onLogout
}: SettingsProps) {
  // 處理用戶未登入的情況
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Card className="w-full max-w-md bg-white/80 backdrop-blur-sm border-0">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 gradient-ai rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
              <SettingsIcon className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Loading Settings</h3>
            <p className="text-gray-600 mb-2">Please wait while we load your settings...</p>
            <p className="text-sm text-gray-500">正在載入您的設定...</p>
            <div className="mt-6">
              <div className="loading-shimmer w-full h-2 bg-gray-100 rounded-full"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const [activeTab, setActiveTab] = useState('account')
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)
  
  // 個人信息狀態
  const [personalInfo, setPersonalInfo] = useState({
    firstName: user.name?.split(' ')[0] || 'User',
    lastName: user.name?.split(' ').slice(1).join(' ') || '',
    email: user.email || 'user@example.com',
    phone: '+852 9123 4567',
    bio: '一個熱愛創作的小紅書創作者，專注於分享生活美學和創意靈感。',
    location: 'Hong Kong',
    company: 'CreaTA',
    position: 'Content Creator',
    website: 'https://creata.ai',
    timezone: 'GMT+8 Hong Kong',
    language: 'English (US)'
  })

  // 系統偏好設定
  const [preferences, setPreferences] = useState({
    theme: 'light',
    language: 'en-US',
    timezone: 'Asia/Hong_Kong',
    dateFormat: 'DD/MM/YYYY',
    timeFormat: '24h',
    currency: 'HKD',
    autoSave: true,
    notifications: true,
    analytics: true,
    marketing: false,
    betaFeatures: true,
    aiAssistance: true
  })

  // 通知設定
  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    pushNotifications: true,
    contentAlerts: true,
    securityAlerts: true,
    productUpdates: true,
    weeklyReports: true,
    marketingEmails: false,
    aiInsights: true,
    profileUpdates: true,
    systemMaintenance: true
  })

  // 隱私設定
  const [privacy, setPrivacy] = useState({
    profileVisibility: 'private',
    dataSharing: false,
    analyticsOptOut: false,
    thirdPartyIntegrations: true,
    aiTraining: true,
    cookieConsent: true,
    twoFactorAuth: false,
    sessionTimeout: '30m',
    downloadData: false,
    deleteAccount: false
  })

  const handleSaveChanges = () => {
    const updatedUser: UserData = {
      ...user,
      name: `${personalInfo.firstName} ${personalInfo.lastName}`.trim(),
      email: personalInfo.email
    }
    onUserUpdate(updatedUser)
    setHasUnsavedChanges(false)
  }

  const accountStats = {
    memberSince: 'March 2024',
    contentGenerated: 1247,
    activeProfiles: profiles.length,
    lastActive: 'Today at 2:30 PM',
    storageUsed: 2.4,
    storageLimit: 10,
    aiCredits: 850,
    aiCreditsLimit: 1000,
    successRate: 94
  }

  const tabs = [
    { id: 'account', label: 'Account', labelZh: '帳戶', icon: User, color: 'from-blue-500 to-indigo-600' },
    { id: 'profiles', label: 'Profiles', labelZh: '檔案', icon: Database, color: 'from-purple-500 to-pink-600' },
    { id: 'preferences', label: 'Preferences', labelZh: '偏好', icon: Sliders, color: 'from-green-500 to-teal-600' },
    { id: 'notifications', label: 'Notifications', labelZh: '通知', icon: Bell, color: 'from-orange-500 to-red-600' },
    { id: 'privacy', label: 'Privacy', labelZh: '隱私', icon: Shield, color: 'from-gray-600 to-gray-700' },
    { id: 'billing', label: 'Billing', labelZh: '帳單', icon: CreditCard, color: 'from-emerald-500 to-green-600' }
  ]

  return (
    <div className="space-y-6 sm:space-y-8">
        {/* Premium Header */}
        <div className="relative">
          <Card className="border-0 rounded-3xl p-6 sm:p-8 shadow-lg bg-white/80 backdrop-blur-sm">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-6 lg:space-y-0">
              <div className="flex items-center space-x-4 sm:space-x-6">
                <div className="relative">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 gradient-ai rounded-2xl flex items-center justify-center shadow-neural">
                    <SettingsIcon className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 sm:w-6 sm:h-6 bg-green-500 rounded-full border-3 border-white status-online"></div>
                </div>
                <div>
                  <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gradient-premium">
                    Settings
                  </h1>
                  <p className="text-base sm:text-lg text-gray-600 mt-1">
                    Manage your account, preferences, and privacy
                  </p>
                  <p className="text-xs sm:text-sm text-gray-500">
                    管理您的帳戶、偏好設定和隱私設定
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 px-3 py-1.5 text-xs sm:text-sm font-medium shadow-lg">
                  <Crown className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  Pro Plan
                </Badge>
                <Badge className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white border-0 px-3 py-1.5 text-xs sm:text-sm font-medium shadow-lg">
                  <Users className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  {accountStats.activeProfiles} Profiles
                </Badge>
                <Badge className="bg-gradient-to-r from-purple-500 to-pink-600 text-white border-0 px-3 py-1.5 text-xs sm:text-sm font-medium shadow-lg">
                  <Activity className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  {accountStats.successRate}% Success
                </Badge>
              </div>
            </div>
          </Card>
        </div>

        {/* Unsaved Changes Alert */}
        {hasUnsavedChanges && (
          <Alert className="border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 shadow-lg animate-slide-in-right">
            <AlertTriangle className="w-5 h-5 text-amber-600" />
            <AlertDescription className="flex flex-col sm:flex-row sm:items-center sm:justify-between w-full space-y-3 sm:space-y-0">
              <div>
                <span className="text-amber-800 font-medium block sm:inline">You have unsaved changes</span>
                <span className="text-amber-600 text-sm block sm:inline sm:ml-2">• 您有未儲存的變更</span>
              </div>
              <Button onClick={handleSaveChanges} size="sm" className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white border-0 shadow-lg button-press">
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          {/* Premium Navigation */}
          <div className="relative">
            <Card className="border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
            <div className="border-b-0 overflow-x-auto p-2">
              <TabsList className="inline-flex h-14 sm:h-16 items-center justify-start w-full bg-transparent p-2 space-x-1 sm:space-x-2 min-w-max">
                {tabs.map((tab) => (
                  <TabsTrigger
                    key={tab.id}
                    value={tab.id}
                    className={`flex items-center space-x-2 sm:space-x-3 px-3 sm:px-6 py-3 sm:py-4 font-medium text-gray-600 hover:text-gray-900 data-[state=active]:text-white data-[state=active]:bg-gradient-to-r data-[state=active]:${tab.color} data-[state=active]:shadow-lg rounded-xl transition-all duration-300 whitespace-nowrap border-0 data-[state=active]:border-0 button-press`}
                  >
                    <tab.icon className="w-4 h-4 sm:w-5 sm:h-5" />
                    <div className="text-left hidden sm:block">
                      <div className="text-xs sm:text-sm font-semibold">{tab.label}</div>
                      <div className="text-[10px] sm:text-xs opacity-70">{tab.labelZh}</div>
                    </div>
                    <span className="text-xs sm:hidden">{tab.labelZh}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>
            </Card>
          </div>

          {/* Account Tab */}
          <TabsContent value="account" className="space-y-6 sm:space-y-8 animate-fade-in-up">
            <div className="grid lg:grid-cols-3 gap-6 sm:gap-8">
              {/* Enhanced Profile Card */}
              <Card className="lg:col-span-1 rounded-3xl overflow-hidden bg-white/80 backdrop-blur-sm border-0">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5"></div>
                <CardHeader className="relative text-center pb-6">
                  <div className="flex justify-center mb-6 sm:mb-8">
                    <div className="relative group">
                      <Avatar className="w-24 h-24 sm:w-28 sm:h-28 border-4 border-white shadow-floating hover-lift-apple">
                        <AvatarImage src="/api/placeholder/200/200" />
                        <AvatarFallback className="text-xl sm:text-2xl font-bold gradient-ai text-white">
                          {personalInfo.firstName.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <Button
                        size="sm"
                        className="absolute -bottom-2 -right-2 w-8 h-8 sm:w-10 sm:h-10 rounded-full p-0 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 shadow-xl border-4 border-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 button-press"
                      >
                        <Camera className="w-3 h-3 sm:w-4 sm:h-4" />
                      </Button>
                    </div>
                  </div>
                  <CardTitle className="text-xl sm:text-2xl font-bold text-gray-900">{personalInfo.firstName} {personalInfo.lastName}</CardTitle>
                  <CardDescription className="text-sm sm:text-base text-gray-600">{personalInfo.email}</CardDescription>
                  <div className="flex justify-center space-x-2 sm:space-x-3 mt-4">
                    <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 px-2 sm:px-3 py-1 text-xs sm:text-sm font-medium shadow-lg ai-badge">
                      <Check className="w-3 h-3 mr-1" />
                      Verified
                    </Badge>
                    <Badge className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white border-0 px-2 sm:px-3 py-1 text-xs sm:text-sm font-medium shadow-lg">
                      Pro Member
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="relative space-y-6">
                  <Button className="w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white border-0 shadow-lg rounded-xl py-3 hover-lift-apple button-press" size="lg">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload New Photo
                  </Button>
                  
                  <Separator className="bg-gradient-to-r from-transparent via-gray-200 to-transparent" />
                  
                  {/* Enhanced Stats */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-gray-900 text-base sm:text-lg">Account Overview</h4>
                    <div className="grid grid-cols-2 gap-3 sm:gap-4">
                      <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl hover-lift-apple">
                        <div className="text-xl sm:text-2xl font-bold text-blue-600">{accountStats.contentGenerated.toLocaleString()}</div>
                        <div className="text-xs sm:text-sm text-gray-600">Content Generated</div>
                      </div>
                      <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl hover-lift-apple">
                        <div className="text-xl sm:text-2xl font-bold text-purple-600">{accountStats.activeProfiles}</div>
                        <div className="text-xs sm:text-sm text-gray-600">Active Profiles</div>
                      </div>
                      <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl hover-lift-apple">
                        <div className="text-xl sm:text-2xl font-bold text-green-600">{accountStats.successRate}%</div>
                        <div className="text-xs sm:text-sm text-gray-600">Success Rate</div>
                      </div>
                      <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-orange-50 to-yellow-50 rounded-2xl hover-lift-apple">
                        <div className="text-xl sm:text-2xl font-bold text-orange-600">{accountStats.aiCredits}</div>
                        <div className="text-xs sm:text-sm text-gray-600">AI Credits</div>
                      </div>
                    </div>
                    
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600 font-medium">Member since</span>
                        <span className="font-semibold text-gray-900">{accountStats.memberSince}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600 font-medium">Last active</span>
                        <span className="font-semibold text-gray-900">{accountStats.lastActive}</span>
                      </div>
                    </div>

                    <Separator className="bg-gradient-to-r from-transparent via-gray-200 to-transparent" />

                    {/* Storage & Credits */}
                    <div className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600 font-medium text-sm">Storage used</span>
                          <span className="font-semibold text-gray-900 text-sm">{accountStats.storageUsed}GB / {accountStats.storageLimit}GB</span>
                        </div>
                        <div className="space-y-2">
                          <Progress value={(accountStats.storageUsed / accountStats.storageLimit) * 100} className="h-3 bg-gray-100" />
                          <div className="text-xs text-gray-500 text-center">
                            {Math.round((accountStats.storageUsed / accountStats.storageLimit) * 100)}% used
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600 font-medium text-sm">AI Credits</span>
                          <span className="font-semibold text-gray-900 text-sm">{accountStats.aiCredits} / {accountStats.aiCreditsLimit}</span>
                        </div>
                        <div className="space-y-2">
                          <Progress value={(accountStats.aiCredits / accountStats.aiCreditsLimit) * 100} className="h-3 bg-gray-100" />
                          <div className="text-xs text-gray-500 text-center">
                            {Math.round((accountStats.aiCredits / accountStats.aiCreditsLimit) * 100)}% remaining
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Enhanced Personal Information Form */}
              <Card className="lg:col-span-2 rounded-3xl overflow-hidden bg-white/80 backdrop-blur-sm border-0">
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-purple-500/5"></div>
                <CardHeader className="relative">
                  <CardTitle className="flex items-center space-x-3 text-xl sm:text-2xl font-bold text-gray-900">
                    <User className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                    <span>Personal Information</span>
                  </CardTitle>
                  <CardDescription className="text-sm sm:text-base text-gray-600">
                    Update your personal details and contact information
                    <br />
                    <span className="text-xs sm:text-sm text-gray-500">更新您的個人資料和聯絡方式</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="relative space-y-6 sm:space-y-8">
                  <div className="grid md:grid-cols-2 gap-4 sm:gap-6">
                    <div className="space-y-3">
                      <Label htmlFor="firstName" className="label-enhanced">
                        First Name • 名字
                      </Label>
                      <Input
                        id="firstName"
                        value={personalInfo.firstName}
                        onChange={(e) => {
                          setPersonalInfo(prev => ({ ...prev, firstName: e.target.value }))
                          setHasUnsavedChanges(true)
                        }}
                        className="input-enhanced"
                        placeholder="Enter your first name"
                      />
                    </div>
                    <div className="space-y-3">
                      <Label htmlFor="lastName" className="label-enhanced">
                        Last Name • 姓氏
                      </Label>
                      <Input
                        id="lastName"
                        value={personalInfo.lastName}
                        onChange={(e) => {
                          setPersonalInfo(prev => ({ ...prev, lastName: e.target.value }))
                          setHasUnsavedChanges(true)
                        }}
                        className="input-enhanced"
                        placeholder="Enter your last name"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 sm:gap-6">
                    <div className="space-y-3">
                      <Label htmlFor="email" className="label-enhanced">
                        Email Address • 電子郵件
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        value={personalInfo.email}
                        onChange={(e) => {
                          setPersonalInfo(prev => ({ ...prev, email: e.target.value }))
                          setHasUnsavedChanges(true)
                        }}
                        className="input-enhanced"
                        placeholder="your@email.com"
                      />
                    </div>
                    <div className="space-y-3">
                      <Label htmlFor="phone" className="label-enhanced">
                        Phone Number • 電話號碼
                      </Label>
                      <Input
                        id="phone"
                        value={personalInfo.phone}
                        onChange={(e) => {
                          setPersonalInfo(prev => ({ ...prev, phone: e.target.value }))
                          setHasUnsavedChanges(true)
                        }}
                        className="input-enhanced"
                        placeholder="+852 9123 4567"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 sm:gap-6">
                    <div className="space-y-3">
                      <Label htmlFor="company" className="label-enhanced">
                        Company • 公司
                      </Label>
                      <Input
                        id="company"
                        value={personalInfo.company}
                        onChange={(e) => {
                          setPersonalInfo(prev => ({ ...prev, company: e.target.value }))
                          setHasUnsavedChanges(true)
                        }}
                        className="input-enhanced"
                        placeholder="Your company name"
                      />
                    </div>
                    <div className="space-y-3">
                      <Label htmlFor="position" className="label-enhanced">
                        Position • 職位
                      </Label>
                      <Input
                        id="position"
                        value={personalInfo.position}
                        onChange={(e) => {
                          setPersonalInfo(prev => ({ ...prev, position: e.target.value }))
                          setHasUnsavedChanges(true)
                        }}
                        className="input-enhanced"
                        placeholder="Your job title"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="bio" className="label-enhanced">
                      Bio • 個人簡介
                    </Label>
                    <Textarea
                      id="bio"
                      value={personalInfo.bio}
                      onChange={(e) => {
                        setPersonalInfo(prev => ({ ...prev, bio: e.target.value }))
                        setHasUnsavedChanges(true)
                      }}
                      className="textarea-enhanced min-h-[100px] sm:min-h-[120px]"
                      placeholder="Tell us about yourself..."
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                    <div className="space-y-3">
                      <Label className="label-enhanced">Location • 地區</Label>
                      <Select value={personalInfo.location} onValueChange={(value) => {
                        setPersonalInfo(prev => ({ ...prev, location: value }))
                        setHasUnsavedChanges(true)
                      }}>
                        <SelectTrigger className="input-enhanced">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Hong Kong">🇭🇰 Hong Kong</SelectItem>
                          <SelectItem value="Taiwan">🇹🇼 Taiwan</SelectItem>
                          <SelectItem value="Singapore">🇸🇬 Singapore</SelectItem>
                          <SelectItem value="United States">🇺🇸 United States</SelectItem>
                          <SelectItem value="United Kingdom">🇬🇧 United Kingdom</SelectItem>
                          <SelectItem value="Canada">🇨🇦 Canada</SelectItem>
                          <SelectItem value="Australia">🇦🇺 Australia</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-3">
                      <Label className="label-enhanced">Timezone • 時區</Label>
                      <Select value={personalInfo.timezone} onValueChange={(value) => {
                        setPersonalInfo(prev => ({ ...prev, timezone: value }))
                        setHasUnsavedChanges(true)
                      }}>
                        <SelectTrigger className="input-enhanced">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="GMT+8 Hong Kong">GMT+8 Hong Kong</SelectItem>
                          <SelectItem value="GMT+8 Taipei">GMT+8 Taipei</SelectItem>
                          <SelectItem value="GMT+8 Singapore">GMT+8 Singapore</SelectItem>
                          <SelectItem value="GMT-5 New York">GMT-5 New York</SelectItem>
                          <SelectItem value="GMT+0 London">GMT+0 London</SelectItem>
                          <SelectItem value="GMT-8 Vancouver">GMT-8 Vancouver</SelectItem>
                          <SelectItem value="GMT+10 Sydney">GMT+10 Sydney</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-3">
                      <Label className="label-enhanced">Language • 語言</Label>
                      <Select value={personalInfo.language} onValueChange={(value) => {
                        setPersonalInfo(prev => ({ ...prev, language: value }))
                        setHasUnsavedChanges(true)
                      }}>
                        <SelectTrigger className="input-enhanced">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="English (US)">🇺🇸 English (US)</SelectItem>
                          <SelectItem value="繁體中文 (香港)">🇭🇰 繁體中文 (香港)</SelectItem>
                          <SelectItem value="繁體中文 (台灣)">🇹🇼 繁體中文 (台灣)</SelectItem>
                          <SelectItem value="简体中文">🇨🇳 简体中文</SelectItem>
                          <SelectItem value="English (UK)">🇬🇧 English (UK)</SelectItem>
                          <SelectItem value="日本語">🇯🇵 日本語</SelectItem>
                          <SelectItem value="한국어">🇰🇷 한국어</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-4 pt-6 sm:pt-8 border-t border-gray-100">
                    <Button variant="outline" onClick={() => setHasUnsavedChanges(false)} className="px-6 sm:px-8 py-3 rounded-xl border-2 hover:bg-gray-50 button-press">
                      Cancel
                    </Button>
                    <Button onClick={handleSaveChanges} className="px-6 sm:px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0 shadow-lg rounded-xl button-press">
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Profiles Tab */}
          <TabsContent value="profiles" className="animate-fade-in-up">
            <div className="space-y-6 sm:space-y-8">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Brand Profiles Management</h2>
                  <p className="text-gray-600">Create and manage multiple brand identities for different content strategies</p>
                  <p className="text-xs sm:text-sm text-gray-500">建立和管理多個品牌身份，用於不同的內容策略</p>
                </div>
                <Button onClick={onProfileCreate} className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white shadow-lg button-press">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Profile
                </Button>
              </div>

              {/* Active Profile Spotlight */}
              {activeProfile && (
                <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50/80 to-purple-50/80 backdrop-blur-sm rounded-3xl">
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 sm:w-16 sm:h-16 gradient-ai rounded-2xl flex items-center justify-center shadow-lg">
                          <span className="text-white font-bold text-lg sm:text-xl">{activeProfile.name.charAt(0)}</span>
                        </div>
                        <div>
                          <CardTitle className="flex items-center space-x-3 text-lg sm:text-xl">
                            <span>{activeProfile.name}</span>
                            <Badge className="bg-green-100 text-green-700 border-green-200">
                              <Activity className="w-3 h-3 mr-1" />
                              Active Profile
                            </Badge>
                          </CardTitle>
                          <CardDescription className="text-sm sm:text-base mt-1">{activeProfile.coreIdentity}</CardDescription>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" onClick={() => onProfileEdit(activeProfile)} className="button-press">
                          <Edit3 className="w-4 h-4 mr-2" />
                          Edit
                        </Button>
                        <Button variant="outline" className="button-press">
                          <BarChart3 className="w-4 h-4 mr-2" />
                          Analytics
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
                      <div className="text-center p-3 sm:p-4 bg-white/70 rounded-2xl">
                        <div className="text-xl sm:text-2xl font-bold text-blue-600">152</div>
                        <div className="text-xs sm:text-sm text-gray-600">Content Generated</div>
                      </div>
                      <div className="text-center p-3 sm:p-4 bg-white/70 rounded-2xl">
                        <div className="text-xl sm:text-2xl font-bold text-green-600">94%</div>
                        <div className="text-xs sm:text-sm text-gray-600">Success Rate</div>
                      </div>
                      <div className="text-center p-3 sm:p-4 bg-white/70 rounded-2xl">
                        <div className="text-xl sm:text-2xl font-bold text-purple-600">{activeProfile.targetPlatform?.length || 0}</div>
                        <div className="text-xs sm:text-sm text-gray-600">Target Platforms</div>
                      </div>
                      <div className="text-center p-3 sm:p-4 bg-white/70 rounded-2xl">
                        <div className="text-xl sm:text-2xl font-bold text-orange-600">12</div>
                        <div className="text-xs sm:text-sm text-gray-600">Days Active</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* All Profiles Grid */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {profiles.map((profile) => (
                  <Card key={profile.id} className={`group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 bg-white/80 backdrop-blur-sm border-0 ${
                    activeProfile?.id === profile.id ? 'ring-2 ring-blue-500 bg-blue-50/80' : 'hover:bg-white/90'
                  }`}>
                    <CardHeader className="pb-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 gradient-ai rounded-xl flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
                          <span className="text-white font-bold text-sm sm:text-base">{profile.name.charAt(0)}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <CardTitle className="text-base sm:text-lg truncate flex items-center space-x-2">
                            <span>{profile.name}</span>
                            {activeProfile?.id === profile.id && (
                              <Badge className="bg-green-100 text-green-700 text-xs px-2 py-0.5">Active</Badge>
                            )}
                          </CardTitle>
                          <CardDescription className="text-xs sm:text-sm truncate">{profile.coreIdentity}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex justify-between text-xs sm:text-sm text-gray-600">
                        <span>Created: {profile.createdAt}</span>
                        <span>Used: {profile.lastUsed}</span>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant={activeProfile?.id === profile.id ? "default" : "outline"}
                          className="flex-1 button-press"
                          onClick={() => onProfileSelect(profile)}
                          disabled={activeProfile?.id === profile.id}
                        >
                          {activeProfile?.id === profile.id ? 'Active' : 'Switch'}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onProfileEdit(profile)}
                          className="button-press"
                        >
                          <Edit3 className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onProfileDuplicate(profile)}
                          className="button-press"
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Preferences Tab */}
          <TabsContent value="preferences" className="animate-fade-in-up">
            <Card className="rounded-3xl bg-white/80 backdrop-blur-sm border-0">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-xl sm:text-2xl font-bold text-gray-900">
                  <Sliders className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                  <span>System Preferences</span>
                </CardTitle>
                <CardDescription className="text-sm sm:text-base text-gray-600">
                  Customize your experience and interface settings
                  <br />
                  <span className="text-xs sm:text-sm text-gray-500">自訂您的體驗和介面設定</span>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 sm:space-y-8">
                <div className="grid md:grid-cols-2 gap-6 sm:gap-8">
                  <div className="space-y-6">
                    <h4 className="font-semibold text-gray-900 text-base sm:text-lg flex items-center space-x-2">
                      <Palette className="w-5 h-5 text-purple-600" />
                      <span>Appearance • 外觀</span>
                    </h4>
                    <div className="space-y-4">
                      <div className="space-y-3">
                        <Label className="label-enhanced">Theme Mode • 主題模式</Label>
                        <Select value={preferences.theme} onValueChange={(value) => 
                          setPreferences(prev => ({ ...prev, theme: value }))
                        }>
                          <SelectTrigger className="input-enhanced">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="light">☀️ Light Mode</SelectItem>
                            <SelectItem value="dark">🌙 Dark Mode</SelectItem>
                            <SelectItem value="system">💻 Follow System</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="label-enhanced">Language • 語言</Label>
                        <Select value={preferences.language} onValueChange={(value) => 
                          setPreferences(prev => ({ ...prev, language: value }))
                        }>
                          <SelectTrigger className="input-enhanced">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="en-US">🇺🇸 English (US)</SelectItem>
                            <SelectItem value="zh-HK">🇭🇰 繁體中文 (香港)</SelectItem>
                            <SelectItem value="zh-TW">🇹🇼 繁體中文 (台灣)</SelectItem>
                            <SelectItem value="zh-CN">🇨🇳 简体中文</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <h4 className="font-semibold text-gray-900 text-base sm:text-lg flex items-center space-x-2">
                      <Zap className="w-5 h-5 text-orange-600" />
                      <span>Behavior • 行為</span>
                    </h4>
                    <div className="space-y-4">
                      {[
                        { key: 'autoSave', label: 'Auto-save content', labelZh: '自動儲存內容', description: 'Automatically save your work as you type' },
                        { key: 'notifications', label: 'Enable notifications', labelZh: '啟用通知', description: 'Receive system notifications' },
                        { key: 'analytics', label: 'Usage analytics', labelZh: '使用分析', description: 'Help improve the platform' },
                        { key: 'betaFeatures', label: 'Beta features', labelZh: '測試功能', description: 'Access experimental features' },
                        { key: 'aiAssistance', label: 'AI assistance', labelZh: 'AI 協助', description: 'Enhanced AI-powered suggestions' }
                      ].map((pref) => (
                        <div key={pref.key} className="flex items-center justify-between p-3 sm:p-4 bg-gray-50/50 rounded-xl hover:bg-gray-50 transition-colors">
                          <div>
                            <div className="font-medium text-sm text-gray-900">{pref.label} • {pref.labelZh}</div>
                            <div className="text-xs text-gray-600">{pref.description}</div>
                          </div>
                          <Switch
                            checked={preferences[pref.key as keyof typeof preferences] as boolean}
                            onCheckedChange={(checked) => 
                              setPreferences(prev => ({ ...prev, [pref.key]: checked }))
                            }
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="animate-fade-in-up">
            <Card className="rounded-3xl bg-white/80 backdrop-blur-sm border-0">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3 text-xl sm:text-2xl font-bold text-gray-900">
                  <Bell className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                  <span>Notification Settings</span>
                </CardTitle>
                <CardDescription className="text-sm sm:text-base text-gray-600">
                  Manage how you receive notifications
                  <br />
                  <span className="text-xs sm:text-sm text-gray-500">管理您如何接收通知</span>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {[
                  { key: 'emailNotifications', label: 'Email Notifications', labelZh: '電子郵件通知', description: 'Receive updates via email', icon: Mail, color: 'from-blue-500 to-indigo-600' },
                  { key: 'pushNotifications', label: 'Push Notifications', labelZh: '推送通知', description: 'Get browser notifications', icon: Bell, color: 'from-green-500 to-teal-600' },
                  { key: 'contentAlerts', label: 'Content Generation', labelZh: '內容生成提醒', description: 'AI content completion alerts', icon: Zap, color: 'from-yellow-500 to-orange-600' },
                  { key: 'securityAlerts', label: 'Security Alerts', labelZh: '安全提醒', description: 'Account security notifications', icon: Shield, color: 'from-red-500 to-pink-600' },
                  { key: 'productUpdates', label: 'Product Updates', labelZh: '產品更新', description: 'New features and improvements', icon: Sparkles, color: 'from-purple-500 to-violet-600' },
                  { key: 'weeklyReports', label: 'Weekly Reports', labelZh: '週報告', description: 'Usage statistics and insights', icon: BarChart3, color: 'from-emerald-500 to-green-600' },
                  { key: 'aiInsights', label: 'AI Insights', labelZh: 'AI 洞察', description: 'Personalized content suggestions', icon: Target, color: 'from-cyan-500 to-blue-600' },
                  { key: 'profileUpdates', label: 'Profile Updates', labelZh: '檔案更新', description: 'Profile activity notifications', icon: User, color: 'from-indigo-500 to-purple-600' }
                ].map((notification) => (
                  <div key={notification.key} className="flex items-center justify-between p-4 sm:p-6 bg-gradient-to-r from-gray-50/50 to-blue-50/30 rounded-2xl border border-gray-100/50 hover:from-gray-50 hover:to-blue-50/50 transition-all duration-300 card-premium">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br ${notification.color} rounded-xl flex items-center justify-center shadow-lg`}>
                        <notification.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900 text-sm sm:text-base">{notification.label} • {notification.labelZh}</div>
                        <div className="text-xs sm:text-sm text-gray-600">{notification.description}</div>
                      </div>
                    </div>
                    <Switch
                      checked={notifications[notification.key as keyof typeof notifications]}
                      onCheckedChange={(checked) => 
                        setNotifications(prev => ({ ...prev, [notification.key]: checked }))
                      }
                    />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Privacy Tab */}
          <TabsContent value="privacy" className="animate-fade-in-up">
            <div className="space-y-6 sm:space-y-8">
              <Card className="rounded-3xl bg-white/80 backdrop-blur-sm border-0">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3 text-xl sm:text-2xl font-bold text-gray-900">
                    <Shield className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                    <span>Privacy & Security</span>
                  </CardTitle>
                  <CardDescription className="text-sm sm:text-base text-gray-600">
                    Protect your account and data
                    <br />
                    <span className="text-xs sm:text-sm text-gray-500">保護您的帳戶和資料</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {[
                    { key: 'twoFactorAuth', label: 'Two-Factor Authentication', labelZh: '雙重驗證', description: 'Add an extra layer of security', icon: Key, color: 'from-green-500 to-emerald-600' },
                    { key: 'dataSharing', label: 'Data Sharing', labelZh: '資料分享', description: 'Share anonymized usage data', icon: Globe, color: 'from-blue-500 to-indigo-600' },
                    { key: 'aiTraining', label: 'AI Training', labelZh: 'AI 訓練', description: 'Use my data to improve AI models', icon: Zap, color: 'from-purple-500 to-pink-600' },
                    { key: 'thirdPartyIntegrations', label: 'Third-party Integrations', labelZh: '第三方整合', description: 'Allow external service connections', icon: ExternalLink, color: 'from-orange-500 to-red-600' }
                  ].map((setting) => (
                    <div key={setting.key} className="flex items-center justify-between p-4 sm:p-6 bg-gradient-to-r from-gray-50/50 to-blue-50/30 rounded-2xl border border-gray-100/50 hover:from-gray-50 hover:to-blue-50/50 transition-all duration-300">
                      <div className="flex items-center space-x-4">
                        <div className={`w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br ${setting.color} rounded-xl flex items-center justify-center shadow-lg`}>
                          <setting.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900 text-sm sm:text-base">{setting.label} • {setting.labelZh}</div>
                          <div className="text-xs sm:text-sm text-gray-600">{setting.description}</div>
                        </div>
                      </div>
                      <Switch
                        checked={privacy[setting.key as keyof typeof privacy]}
                        onCheckedChange={(checked) => 
                          setPrivacy(prev => ({ ...prev, [setting.key]: checked }))
                        }
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Data Management Section */}
              <Card className="rounded-3xl bg-white/80 backdrop-blur-sm border-0">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3 text-lg sm:text-xl font-bold text-gray-900">
                    <HardDrive className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" />
                    <span>Data Management • 資料管理</span>
                  </CardTitle>
                  <CardDescription className="text-sm sm:text-base text-gray-600">
                    Manage your personal data and account information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Button variant="outline" className="justify-start p-4 h-auto border-2 hover:border-blue-300 hover:bg-blue-50 button-press">
                      <div className="flex items-center space-x-3">
                        <Download className="w-5 h-5 text-blue-600" />
                        <div className="text-left">
                          <div className="font-medium text-sm">Download Data</div>
                          <div className="text-xs text-gray-600">Export your account data</div>
                        </div>
                      </div>
                    </Button>
                    <Button variant="outline" className="justify-start p-4 h-auto border-2 hover:border-red-300 hover:bg-red-50 button-press">
                      <div className="flex items-center space-x-3">
                        <Trash2 className="w-5 h-5 text-red-600" />
                        <div className="text-left">
                          <div className="font-medium text-sm">Delete Account</div>
                          <div className="text-xs text-gray-600">Permanently delete account</div>
                        </div>
                      </div>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Billing Tab */}
          <TabsContent value="billing" className="animate-fade-in-up">
            <div className="space-y-6 sm:space-y-8">
              {/* Subscription Overview */}
              <Card className="rounded-3xl bg-white/80 backdrop-blur-sm border-0">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3 text-xl sm:text-2xl font-bold text-gray-900">
                    <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                    <span>Billing & Subscription</span>
                  </CardTitle>
                  <CardDescription className="text-sm sm:text-base text-gray-600">
                    Manage your subscription and billing information
                    <br />
                    <span className="text-xs sm:text-sm text-gray-500">管理您的訂閱和帳單資訊</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Current Plan */}
                  <div className="p-4 sm:p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl border border-green-200">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                          <Crown className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <div className="text-lg font-bold text-gray-900">Pro Plan</div>
                          <div className="text-sm text-gray-600">Next billing: March 15, 2024</div>
                          <div className="text-xs text-gray-500">下次帳單：2024年3月15日</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-green-600">$29/month</div>
                        <div className="text-sm text-gray-600">Billed monthly</div>
                      </div>
                    </div>
                  </div>

                  {/* Usage Stats */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
                    <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl">
                      <div className="text-2xl font-bold text-blue-600">{accountStats.aiCredits}</div>
                      <div className="text-sm text-gray-600">AI Credits Used</div>
                      <div className="text-xs text-gray-500">of {accountStats.aiCreditsLimit} total</div>
                    </div>
                    <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl">
                      <div className="text-2xl font-bold text-purple-600">{accountStats.storageUsed}GB</div>
                      <div className="text-sm text-gray-600">Storage Used</div>
                      <div className="text-xs text-gray-500">of {accountStats.storageLimit}GB total</div>
                    </div>
                    <div className="text-center p-4 bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl">
                      <div className="text-2xl font-bold text-green-600">∞</div>
                      <div className="text-sm text-gray-600">Profiles</div>
                      <div className="text-xs text-gray-500">Unlimited</div>
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Button variant="outline" className="justify-start p-4 h-auto border-2 hover:border-blue-300 hover:bg-blue-50 button-press">
                      <div className="flex items-center space-x-3">
                        <FileText className="w-5 h-5 text-blue-600" />
                        <div className="text-left">
                          <div className="font-medium text-sm">View Invoices</div>
                          <div className="text-xs text-gray-600">Download billing history</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 ml-auto text-gray-400" />
                    </Button>
                    <Button variant="outline" className="justify-start p-4 h-auto border-2 hover:border-purple-300 hover:bg-purple-50 button-press">
                      <div className="flex items-center space-x-3">
                        <Star className="w-5 h-5 text-purple-600" />
                        <div className="text-left">
                          <div className="font-medium text-sm">Upgrade Plan</div>
                          <div className="text-xs text-gray-600">Get more features</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 ml-auto text-gray-400" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card className="rounded-3xl bg-white/80 backdrop-blur-sm border-0">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3 text-lg sm:text-xl font-bold text-gray-900">
                    <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" />
                    <span>Payment Methods • 付款方式</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-gray-600 to-gray-700 rounded-lg flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="font-medium text-sm">•••• •••• •••• 4242</div>
                        <div className="text-xs text-gray-600">Expires 12/2027</div>
                      </div>
                    </div>
                    <Badge className="bg-blue-100 text-blue-700">Primary</Badge>
                  </div>
                  <Button variant="outline" className="w-full mt-4 button-press">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Payment Method
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Account Actions */}
        <Card className="bg-gradient-to-r from-red-50/80 to-orange-50/80 backdrop-blur-sm border-red-200 rounded-3xl overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-orange-500/5"></div>
          <CardHeader className="relative">
            <CardTitle className="flex items-center space-x-3 text-lg sm:text-xl font-bold text-red-600">
              <AlertTriangle className="w-5 h-5 sm:w-6 sm:h-6" />
              <span>Account Actions • 帳戶操作</span>
            </CardTitle>
            <CardDescription className="text-sm sm:text-base text-gray-600">
              Important account actions and data management
              <br />
              <span className="text-xs sm:text-sm text-gray-500">重要的帳戶操作和資料管理</span>
            </CardDescription>
          </CardHeader>
          <CardContent className="relative space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-4 sm:p-6 bg-white/60 rounded-2xl space-y-3 sm:space-y-0">
              <div>
                <div className="font-semibold text-gray-900 text-sm sm:text-base">Sign Out • 登出</div>
                <div className="text-xs sm:text-sm text-gray-600">Sign out from this device • 從此設備登出</div>
              </div>
              <Button variant="outline" onClick={onLogout} className="px-4 sm:px-6 py-2 sm:py-3 border-2 hover:bg-red-50 hover:border-red-200 rounded-xl button-press">
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </CardContent>
        </Card>
    </div>
  )
}