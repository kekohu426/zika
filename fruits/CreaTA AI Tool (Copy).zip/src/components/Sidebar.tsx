import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { cn } from "./ui/utils"
import { useState } from "react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import {
  Sparkles,
  Users,
  BookOpen,
  BarChart3,
  Settings,
  HelpCircle,
  ChevronRight,
  Zap,
  Brain,
  TrendingUp,
  Lightbulb,
  Crown,
  CreditCard,
  LogOut,
  Menu,
  X,
  User,
  FolderOpen,
  ChevronLeft,
  PanelLeftOpen,
  PanelLeftClose,
  ChevronDown,
  Plus,
  Copy,
  Edit3,
  Trash2,
  ArrowLeftRight,
  Clock
} from "lucide-react"

interface UserData {
  id: string
  email: string
  name: string
  isNewUser: boolean
  profiles: any[]
}

interface SidebarProps {
  activeTab: string
  onTabChange: (tab: string) => void
  user: UserData
  activeProfile?: any
  profiles?: any[]
  onProfileSelect: (profile: any) => void
  onProfileCreate: () => void
  onProfileEdit: (profile: any) => void
  onProfileDelete: (profileId: string) => void
  onProfileDuplicate: (profile: any) => void
  onLogout: () => void
}

export default function Sidebar({ 
  activeTab, 
  onTabChange, 
  user, 
  activeProfile, 
  profiles = [], 
  onProfileSelect, 
  onProfileCreate, 
  onProfileEdit, 
  onProfileDelete, 
  onProfileDuplicate, 
  onLogout 
}: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false)

  // 核心功能
  const coreFeatures = [
    {
      id: 'generator',
      label: '內容產生器',
      icon: Sparkles,
      description: '一鍵產生小紅書文案',
      badge: '熱門',
      gradient: 'from-purple-500 to-pink-600',
      iconColor: 'text-purple-600',
      isAI: true
    },
    {
      id: 'community',
      label: 'AI 社群',
      icon: Users,
      description: 'AI助手和自動化項目',
      gradient: 'from-green-500 to-teal-600',
      iconColor: 'text-green-600',
      isAI: true
    }
  ]

  // 內容管理
  const contentManagement = [
    {
      id: 'documents',
      label: '檔案管理',
      icon: FolderOpen,
      description: '管理歷史生成內容',
      gradient: 'from-blue-500 to-indigo-600',
      iconColor: 'text-blue-600'
    }
  ]

  // 知識庫
  const knowledgeBase = [
    {
      id: 'knowledge',
      label: '知識庫',
      icon: BookOpen,
      description: '專題知識庫管理',
      gradient: 'from-orange-500 to-red-600',
      iconColor: 'text-orange-600'
    }
  ]

  // 升級Pro特殊項目
  const upgradeProItem = {
    id: 'upgrade',
    label: '升級Pro',
    icon: Crown,
    description: '解鎖無限AI功能',
    gradient: 'from-purple-500 to-pink-600',
    iconColor: 'text-purple-600',
    badge: '優惠'
  }

  // 帳戶與設定
  const accountSettings = [
    {
      id: 'usage',
      label: '使用情況',
      icon: BarChart3,
      description: '查看AI功能使用統計',
      gradient: 'from-blue-500 to-indigo-600',
      iconColor: 'text-blue-600'
    },
    upgradeProItem,
    {
      id: 'settings',
      label: '設定',
      icon: Settings,
      description: '個人資料與系統設定',
      gradient: 'from-gray-500 to-slate-600',
      iconColor: 'text-gray-600'
    }
  ]

  // 渲染導航項目
  const renderNavItems = (items: any[], title: string, icon?: any) => {
    const Icon = icon
    return (
      <div className="space-y-1">
        {/* 導航項目 */}
        {items.map((item) => {
          const isActive = activeTab === item.id
          
          // 特殊處理使用情況項目 - 顯示為簡潔卡片
          if (item.id === 'usage') {
            return (
              <div key={item.id} className="space-y-1">
                {!isCollapsed ? (
                  // 展開狀態的使用情況卡片
                  <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm hover:shadow-md transition-all duration-300">
                    <div className="space-y-3">
                      {/* 標題 */}
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                          <BarChart3 className="w-4 h-4 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 text-sm">本月使用情況</h3>
                          <Badge className="bg-blue-50 text-blue-600 border-blue-100 text-xs mt-1">免費版</Badge>
                        </div>
                      </div>
                      
                      {/* 使用統計 - 兩個主要功能 */}
                      <div className="space-y-2">
                        <div>
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="text-gray-600">AI文案生成</span>
                            <span className="font-medium text-gray-900">23/50</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-1.5">
                            <div className="bg-blue-500 h-1.5 rounded-full" style={{width: '46%'}}></div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="text-gray-600">AI助手對話</span>
                            <span className="font-medium text-gray-900">156/500</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-1.5">
                            <div className="bg-green-500 h-1.5 rounded-full" style={{width: '31%'}}></div>
                          </div>
                        </div>
                      </div>
                      
                      {/* 重置時間 */}
                      <div className="text-xs text-gray-500 text-center pt-1 border-t border-gray-100">
                        重置於 12月1日
                      </div>
                    </div>
                  </div>
                ) : (
                  // 摺疊狀態的使用情況按鈕
                  <div className="flex justify-center">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center shadow-sm">
                      <BarChart3 className="w-4 h-4 text-white" />
                    </div>
                  </div>
                )}
              </div>
            )
          }
          
          // 特殊處理升級Pro項目 - 顯示為卡片
          if (item.id === 'upgrade') {
            return (
              <div key={item.id} className="space-y-1">
                {!isCollapsed ? (
                  // 展開狀態的升級Pro卡片
                  <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-purple-500 via-purple-600 to-pink-500 p-4 shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300"
                       onClick={() => onTabChange(item.id)}>
                    {/* 背景圖案 */}
                    <div className="absolute inset-0 opacity-10">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full blur-2xl transform translate-x-16 -translate-y-16"></div>
                      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white rounded-full blur-xl transform -translate-x-12 translate-y-12"></div>
                    </div>
                    
                    <div className="relative z-10 space-y-3">
                      {/* 圖標和標題 */}
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                          <Crown className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <h3 className="font-bold text-white text-sm">升級 Pro</h3>
                            <Badge className="bg-white/20 text-white border-white/30 text-xs px-2 py-0.5 backdrop-blur-sm">
                              優惠
                            </Badge>
                          </div>
                          <p className="text-white/80 text-xs">解鎖無限AI功能</p>
                        </div>
                      </div>
                      
                      {/* 價格 */}
                      <div className="flex items-center space-x-2">
                        <span className="text-lg text-white/70 line-through">HK$199</span>
                        <span className="text-2xl font-bold text-white">HK$99</span>
                        <span className="text-sm text-white/80">/月</span>
                      </div>
                      
                      {/* CTA按鈕 */}
                      <Button 
                        size="sm" 
                        className="w-full bg-white/20 text-white border border-white/30 hover:bg-white/30 hover:scale-105 font-medium text-sm backdrop-blur-sm transition-all duration-300"
                        onClick={(e) => {
                          e.stopPropagation()
                          onTabChange(item.id)
                        }}
                      >
                        立即升級
                        <ArrowLeftRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  // 摺疊狀態的升級Pro按鈕
                  <Button
                    variant="ghost"
                    className="w-full h-12 p-0 justify-center relative overflow-hidden rounded-xl group"
                    onClick={() => onTabChange(item.id)}
                  >
                    <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                      <Crown className="w-4 h-4 text-white" />
                    </div>
                  </Button>
                )}
              </div>
            )
          }
          
          // 其他普通導航項目
          return (
            <Button
              key={item.id}
              variant="ghost"
              className={cn(
                "w-full relative group overflow-hidden rounded-xl transition-all duration-300",
                isCollapsed ? "justify-center h-12 p-0" : "justify-start h-auto p-4 text-left",
                isActive 
                  ? "glass-strong border-apple-medium shadow-apple" 
                  : "hover:glass-hover"
              )}
              onClick={() => onTabChange(item.id)}
            >
              {/* Active indicator */}
              {isActive && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-gradient-to-b from-blue-500 to-purple-600 rounded-r-full"></div>
              )}
              
              {/* Background gradient for active state */}
              {isActive && (
                <div className={`absolute inset-0 bg-gradient-to-r ${item.gradient} opacity-5`}></div>
              )}
              
              <div className={cn(
                "flex items-center w-full relative z-10",
                isCollapsed ? "justify-center" : "space-x-4"
              )}>
                {/* Icon container */}
                <div className={cn(
                  "rounded-xl flex items-center justify-center transition-all duration-300",
                  isCollapsed ? "w-8 h-8" : "w-10 h-10",
                  isActive 
                    ? `bg-gradient-to-br ${item.gradient} shadow-lg text-white` 
                    : `bg-gray-50 group-hover:bg-gray-100 ${item.iconColor}`
                )}>
                  <item.icon className={cn(isCollapsed ? "w-4 h-4" : "w-5 h-5")} />
                  
                  {/* AI glow effect */}
                  {item.isAI && isActive && (
                    <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-blue-400/20 to-purple-600/20 blur-lg"></div>
                  )}
                </div>
                
                {!isCollapsed && (
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className={cn(
                        "font-semibold truncate transition-colors",
                        isActive ? "text-gray-900" : "text-gray-700"
                      )}>
                        {item.label}
                      </span>
                      
                      {item.badge && (
                        <Badge 
                          className={cn(
                            "text-xs px-2 py-0.5 transition-all",
                            isActive
                              ? "bg-orange-100 text-orange-700 border-orange-200"
                              : "bg-orange-50 text-orange-600 border-orange-100"
                          )}
                        >
                          {item.badge}
                        </Badge>
                      )}
                      
                      {item.isAI && (
                        <div className="flex items-center space-x-0.5">
                          <div className={cn(
                            "w-1.5 h-1.5 rounded-full animate-pulse",
                            isActive ? "bg-blue-500" : "bg-gray-400"
                          )}></div>
                          <div className={cn(
                            "w-1.5 h-1.5 rounded-full animate-pulse",
                            isActive ? "bg-purple-500" : "bg-gray-300"
                          )} style={{animationDelay: '0.2s'}}></div>
                        </div>
                      )}
                    </div>
                    
                    <p className="text-xs text-gray-500 truncate">
                      {item.description}
                    </p>
                  </div>
                )}
                
                {!isCollapsed && (
                  <ChevronRight className={cn(
                    "w-4 h-4 transition-all duration-300",
                    isActive 
                      ? "text-blue-600 translate-x-1" 
                      : "text-gray-400 group-hover:text-gray-600 group-hover:translate-x-0.5"
                  )} />
                )}
              </div>

            </Button>
          )
        })}
      </div>
    )
  }

  return (
    <div className={cn(
      "glass border-r border-apple flex flex-col relative overflow-hidden transition-all duration-300",
      isCollapsed ? "w-20" : "w-80"
    )}>
      {/* Background pattern */}
      <div className="absolute inset-0 neural-pattern opacity-20"></div>
      
      <div className="relative z-10 flex flex-col h-full">
        {/* Logo and brand header */}
        <div className={cn(
          "p-6 border-b border-apple",
          isCollapsed ? "p-4" : ""
        )}>
          <div className={cn(
            "flex items-center",
            isCollapsed ? "justify-center" : "justify-between"
          )}>
            {/* Logo */}
            {!isCollapsed ? (
              <div className="flex items-center space-x-4">
                {/* Premium logo with enhanced design */}
                <div className="relative group">
                  {/* Main logo container */}
                  <div className="relative w-10 h-10 rounded-2xl shadow-lg overflow-hidden">
                    {/* Multi-layer gradient background */}
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-500 via-purple-600 to-pink-500"></div>
                    <div className="absolute inset-0 bg-gradient-to-tl from-transparent via-white/10 to-white/20"></div>
                    
                    {/* Logo content */}
                    <div className="relative z-10 w-full h-full flex items-center justify-center">
                      {/* Creative 'C' with neural network inspired design */}
                      <div className="relative">
                        <span className="text-white font-bold text-lg tracking-tight">C</span>
                        {/* Small accent dots for AI/neural effect */}
                        <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-white/80 rounded-full animate-pulse"></div>
                        <div className="absolute -bottom-0.5 -left-0.5 w-1 h-1 bg-white/60 rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
                      </div>
                    </div>
                    
                    {/* Inner highlight */}
                    <div className="absolute top-1 left-1 right-1 h-1 bg-gradient-to-r from-white/30 to-transparent rounded-full"></div>
                  </div>
                  
                  {/* Enhanced glow effects */}
                  <div className="absolute inset-0 w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-500 via-purple-600 to-pink-500 opacity-20 blur-lg -z-10 group-hover:opacity-30 transition-opacity duration-300"></div>
                  <div className="absolute inset-0 w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-400 to-purple-500 opacity-10 blur-xl -z-20 group-hover:opacity-20 transition-opacity duration-300"></div>
                </div>
                
                {/* Enhanced brand text */}
                <div className="flex items-center space-x-3">
                  <div className="flex items-baseline space-x-1">
                    <h1 className="text-xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-purple-800 bg-clip-text text-transparent tracking-tight">
                      Crea
                    </h1>
                    <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent tracking-tight">
                      TA
                    </h1>
                  </div>
                  
                  {/* Premium AI badge */}
                  <div className="relative">
                    <Badge className="bg-gradient-to-r from-blue-50 to-purple-50 text-transparent bg-clip-text border border-blue-200/50 shadow-sm px-2.5 py-0.5 text-xs font-semibold">
                      <div className="flex items-center space-x-1">
                        <Sparkles className="w-3 h-3 text-blue-600" />
                        <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">AI</span>
                      </div>
                    </Badge>
                  </div>
                </div>
              </div>
            ) : (
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-500 via-purple-600 to-pink-500 flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-sm">C</span>
              </div>
            )}
            
            {/* Collapse toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsCollapsed(!isCollapsed)}
              className="h-8 w-8 p-0 hover:glass-hover neural-glow rounded-lg transition-all duration-300 ml-2"
            >
              {isCollapsed ? (
                <PanelLeftOpen className="w-4 h-4 text-gray-600" />
              ) : (
                <PanelLeftClose className="w-4 h-4 text-gray-600" />
              )}
            </Button>
          </div>
        </div>

        {/* Compact Profile Selection */}
        {!isCollapsed && (
          <div className="mx-3 mb-3 mt-1">
            {activeProfile ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-100 rounded-lg p-2.5 cursor-pointer hover:from-blue-100 hover:to-purple-100 hover:border-blue-200 transition-all duration-200 group">
                    <div className="flex items-center space-x-2.5">
                      {/* Compact Circular Avatar */}
                      <div className="w-7 h-7 gradient-ai rounded-full flex items-center justify-center shadow-sm flex-shrink-0">
                        <span className="text-xs font-semibold text-white">
                          {activeProfile.name.charAt(0)}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-sm font-medium text-gray-900 truncate">{activeProfile.name}</span>
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                        </div>
                      </div>
                      <ChevronDown className="w-3.5 h-3.5 text-blue-500 group-hover:text-blue-600 transition-colors flex-shrink-0" />
                    </div>
                  </div>
                </DropdownMenuTrigger>
                <DropdownMenuContent 
                  align="start" 
                  className="w-72 glass border-apple shadow-floating rounded-xl animate-scale-in"
                  side="right"
                >
                  <DropdownMenuLabel className="text-sm font-medium px-3 py-2 text-gray-700">
                    身份檔案
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  
                  {/* Profile List */}
                  <div className="max-h-48 overflow-y-auto scrollbar-apple">
                    {profiles.length > 0 ? (
                      profiles.map((profile) => (
                        <div key={profile.id} className="group">
                          <div className="flex items-center justify-between px-3 py-2 hover:glass-hover transition-all duration-200">
                            <div 
                              className="flex items-center space-x-3 flex-1 cursor-pointer"
                              onClick={() => onProfileSelect(profile)}
                            >
                              {/* Circular Avatar in List */}
                              <div className="w-8 h-8 gradient-ai rounded-full flex items-center justify-center shadow-sm flex-shrink-0">
                                <span className="text-xs font-semibold text-white">
                                  {profile.name.charAt(0)}
                                </span>
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2">
                                  <span className="font-medium text-gray-900 truncate text-sm">{profile.name}</span>
                                  {activeProfile?.id === profile.id && (
                                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                  )}
                                </div>
                                <span className="text-xs text-gray-500 truncate block">{profile.coreIdentity}</span>
                              </div>
                            </div>
                            
                            {/* Profile Actions */}
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                  <Settings className="w-3.5 h-3.5" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-40">
                                <DropdownMenuItem onClick={() => onProfileEdit(profile)} className="text-sm">
                                  <Edit3 className="w-3.5 h-3.5 mr-2" />
                                  編輯
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => onProfileDuplicate(profile)} className="text-sm">
                                  <Copy className="w-3.5 h-3.5 mr-2" />
                                  複製
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem 
                                  onClick={() => onProfileDelete(profile.id)}
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50 text-sm"
                                >
                                  <Trash2 className="w-3.5 h-3.5 mr-2" />
                                  刪除
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="px-3 py-6 text-center">
                        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                          <User className="w-5 h-5 text-gray-400" />
                        </div>
                        <p className="text-sm text-gray-500 mb-1">尚未建立檔案</p>
                        <p className="text-xs text-gray-400">建立檔案開始使用</p>
                      </div>
                    )}
                  </div>
                  
                  <DropdownMenuSeparator />
                  
                  {/* Create New Profile */}
                  <div className="p-2">
                    <Button
                      onClick={onProfileCreate}
                      className="w-full justify-start gradient-primary text-white hover:shadow-md transition-all duration-300 h-8 text-sm"
                      size="sm"
                    >
                      <Plus className="w-3.5 h-3.5 mr-2" />
                      建立新檔案
                    </Button>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="bg-gray-50 border border-dashed border-gray-200 rounded-lg p-2.5 text-center cursor-pointer hover:bg-blue-50 hover:border-blue-300 transition-all duration-200 group"
                   onClick={onProfileCreate}>
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-6 h-6 bg-white border border-dashed border-gray-300 rounded-full flex items-center justify-center group-hover:border-blue-400 group-hover:bg-blue-50 transition-all duration-200">
                    <Plus className="w-3 h-3 text-gray-400 group-hover:text-blue-500" />
                  </div>
                  <span className="text-sm font-medium text-gray-700 group-hover:text-blue-700 transition-colors">建立檔案</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Collapsed Profile - Compact */}
        {isCollapsed && (
          <div className="px-4 pb-2">
            {activeProfile ? (
              <div className="w-7 h-7 gradient-ai rounded-full flex items-center justify-center shadow-sm mx-auto ring-1 ring-blue-100"
                   title={`${activeProfile.name} - ${activeProfile.coreIdentity}`}>
                <span className="text-xs font-semibold text-white">
                  {activeProfile.name.charAt(0)}
                </span>
              </div>
            ) : (
              <div className="w-7 h-7 bg-gray-50 border border-dashed border-gray-300 rounded-full flex items-center justify-center mx-auto cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all duration-200"
                   title="建立檔案開始使用"
                   onClick={onProfileCreate}>
                <Plus className="w-3 h-3 text-gray-400" />
              </div>
            )}
          </div>
        )}

        {/* Subtle Visual Separator */}
        <div className="mx-4 mb-2">
          <div className="h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 pb-4 pt-2 space-y-4 overflow-y-auto scrollbar-apple">
          {/* 核心功能 */}
          {renderNavItems(coreFeatures, "核心功能", Sparkles)}
          
          {/* 內容管理 */}
          {renderNavItems(contentManagement, "內容管理", FolderOpen)}
          
          {/* 知識庫 */}
          {renderNavItems(knowledgeBase, "知識庫", BookOpen)}
          
          {/* 帳戶與設定 */}
          {renderNavItems(accountSettings, "帳戶與設定", User)}
        </nav>

        {/* Footer section - now minimal */}

      </div>
    </div>
  )
}