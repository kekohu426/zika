import { Badge } from "./ui/badge"
import { Button } from "./ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { 
  Crown, 
  Check, 
  Sparkles, 
  Users, 
  BookOpen,
  BarChart3,
  Zap,
  Shield,
  Headphones,
  Star,
  Infinity,
  TrendingUp,
  Clock,
  Globe,
  ArrowRight,
  Rocket,
  Brain,
  Target,
  Award,
  ChevronRight,
  Play,
  Lightbulb,
  Database,
  Palette,
  MessageSquare,
  Eye,
  Heart
} from "lucide-react"

export default function UpgradePro() {
  const pricingTiers = [
    {
      id: 'starter',
      name: 'Starter',
      nameZh: '入門版',
      price: 0,
      period: 'forever',
      periodZh: '永久免費',
      description: 'Perfect for individuals getting started',
      descriptionZh: '適合個人用戶開始體驗',
      features: [
        { text: '50 AI generations/month', textZh: 'AI文案生成 50次/月', included: true },
        { text: '500 AI conversations/month', textZh: 'AI助手對話 500次/月', included: true },
        { text: 'Basic knowledge base', textZh: '基礎知識庫', included: true },
        { text: '3 brand profiles', textZh: '3個身份檔案', included: true },
        { text: 'Community support', textZh: '社群支援', included: true },
        { text: 'Priority support', textZh: '優先客服', included: false },
        { text: 'Advanced analytics', textZh: '高級分析', included: false },
        { text: 'Team collaboration', textZh: '團隊協作', included: false }
      ],
      buttonText: 'Current Plan',
      buttonTextZh: '目前方案',
      current: true
    },
    {
      id: 'pro',
      name: 'Pro',
      nameZh: '專業版',
      price: 29,
      originalPrice: 59,
      period: 'month',
      periodZh: '每月',
      description: 'For professionals and growing businesses',
      descriptionZh: '適合專業創作者和成長中的企業',
      badge: 'Most Popular',
      badgeZh: '最受歡迎',
      features: [
        { text: 'Unlimited AI generations', textZh: '無限 AI文案生成', included: true },
        { text: 'Unlimited AI conversations', textZh: '無限 AI助手對話', included: true },
        { text: 'Advanced knowledge base', textZh: '高級知識庫', included: true },
        { text: 'Unlimited brand profiles', textZh: '無限身份檔案', included: true },
        { text: 'Premium templates', textZh: '專業模板庫', included: true },
        { text: 'Priority support', textZh: '優先客服支援', included: true },
        { text: 'Advanced analytics', textZh: '高級數據分析', included: true },
        { text: 'API integrations', textZh: 'API 整合', included: true }
      ],
      buttonText: 'Upgrade Now',
      buttonTextZh: '立即升級',
      popular: true
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      nameZh: '企業版',
      price: 99,
      period: 'month',
      periodZh: '每月',
      description: 'For large teams and organizations',
      descriptionZh: '適合大型團隊和組織',
      features: [
        { text: 'Everything in Pro', textZh: '包含專業版所有功能', included: true },
        { text: 'Team collaboration', textZh: '團隊協作', included: true },
        { text: 'Custom branding', textZh: '自訂品牌', included: true },
        { text: 'SSO integration', textZh: 'SSO 單一登入', included: true },
        { text: 'Dedicated support', textZh: '專屬客服', included: true },
        { text: 'Custom integrations', textZh: '客製化整合', included: true },
        { text: 'Advanced security', textZh: '進階安全防護', included: true },
        { text: 'Usage analytics', textZh: '使用情況分析', included: true }
      ],
      buttonText: 'Contact Sales',
      buttonTextZh: '聯繫銷售'
    }
  ]

  const premiumFeatures = [
    {
      icon: Brain,
      title: 'Advanced AI Engine',
      titleZh: '進階AI引擎',
      description: 'Next-generation language models for superior content quality',
      descriptionZh: '次世代語言模型，提供卓越的內容品質',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Rocket,
      title: 'Lightning Fast Generation',
      titleZh: '閃電般快速生成',
      description: 'Generate content 10x faster with optimized processing',
      descriptionZh: '優化處理流程，內容生成速度提升10倍',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: Target,
      title: 'Precision Targeting',
      titleZh: '精準定位',
      description: 'Advanced audience targeting and content personalization',
      descriptionZh: '進階受眾定位和內容個人化',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: Database,
      title: 'Smart Knowledge Base',
      titleZh: '智慧知識庫',
      description: 'AI-powered knowledge management and instant insights',
      descriptionZh: 'AI驅動的知識管理和即時洞察',
      gradient: 'from-orange-500 to-red-500'
    },
    {
      icon: Palette,
      title: 'Creative Templates',
      titleZh: '創意模板庫',
      description: 'Professional templates designed by industry experts',
      descriptionZh: '業界專家設計的專業模板',
      gradient: 'from-indigo-500 to-purple-500'
    },
    {
      icon: BarChart3,
      title: 'Deep Analytics',
      titleZh: '深度分析',
      description: 'Comprehensive performance metrics and optimization tips',
      descriptionZh: '全面的效能指標和優化建議',
      gradient: 'from-teal-500 to-blue-500'
    }
  ]

  const testimonials = [
    {
      name: 'Sarah Chen',
      nameZh: '陳美玲',
      role: 'Content Creator',
      roleZh: '內容創作者',
      company: '@sarahcreates',
      avatar: 'SC',
      content: 'CreaTA Pro transformed my content workflow. The AI quality is incredible and saves me hours every day.',
      contentZh: 'CreaTA Pro徹底改變了我的內容工作流程。AI品質令人驚豔，每天為我節省數小時時間。',
      rating: 5,
      metrics: '300% productivity increase',
      metricsZh: '生產力提升300%'
    },
    {
      name: 'Marcus Johnson',
      nameZh: '約翰遜',
      role: 'Marketing Director',
      roleZh: '行銷總監',
      company: 'TechFlow Inc.',
      avatar: 'MJ',
      content: 'The analytics insights are game-changing. Our engagement rates improved by 150% since upgrading.',
      contentZh: '分析洞察改變了遊戲規則。升級後我們的互動率提升了150%。',
      rating: 5,
      metrics: '150% engagement boost',
      metricsZh: '互動率提升150%'
    },
    {
      name: 'Emma Rodriguez',
      nameZh: '羅德里格茲',
      role: 'Brand Manager',
      roleZh: '品牌經理',
      company: 'Creative Studio',
      avatar: 'ER',
      content: 'Premium templates and unlimited generations make CreaTA Pro essential for our creative process.',
      contentZh: '專業模板和無限生成功能讓CreaTA Pro成為我們創意流程的必需品。',
      rating: 5,
      metrics: '5x faster campaigns',
      metricsZh: '活動速度提升5倍'
    }
  ]

  const comparisonFeatures = [
    { feature: 'AI Content Generation', featureZh: 'AI內容生成', starter: '50/month', pro: 'Unlimited', enterprise: 'Unlimited' },
    { feature: 'Brand Profiles', featureZh: '品牌檔案', starter: '3', pro: 'Unlimited', enterprise: 'Unlimited' },
    { feature: 'Premium Templates', featureZh: '專業模板', starter: '✗', pro: '✓', enterprise: '✓' },
    { feature: 'Advanced Analytics', featureZh: '高級分析', starter: '✗', pro: '✓', enterprise: '✓' },
    { feature: 'Priority Support', featureZh: '優先支援', starter: '✗', pro: '✓', enterprise: '✓' },
    { feature: 'Team Collaboration', featureZh: '團隊協作', starter: '✗', pro: '✗', enterprise: '���' },
    { feature: 'Custom Branding', featureZh: '自訂品牌', starter: '✗', pro: '✗', enterprise: '✓' },
    { feature: 'API Integration', featureZh: 'API整合', starter: '✗', pro: '✓', enterprise: '✓' }
  ]

  return (
    <div className="max-w-7xl mx-auto space-y-16">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-1/4 w-72 h-72 bg-gradient-to-r from-blue-400/10 to-purple-600/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-purple-400/10 to-pink-600/10 rounded-full blur-3xl"></div>
          <div className="absolute top-1/2 left-0 w-64 h-64 bg-gradient-to-r from-cyan-400/10 to-blue-600/10 rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10 text-center space-y-8 py-16">
          {/* Premium Badge */}
          <div className="flex justify-center mb-6">
            <Badge className="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0 text-sm font-medium">
              <Sparkles className="w-4 h-4 mr-2" />
              Unlock Premium Features
              <span className="ml-2 text-xs">解鎖專業功能</span>
            </Badge>
          </div>

          {/* Main Heading */}
          <div className="space-y-4">
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-gray-900 via-blue-900 to-purple-900 bg-clip-text text-transparent leading-tight">
              Supercharge
              <br />
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Your Creativity
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Experience unlimited AI-powered content creation with premium tools designed for professionals
            </p>
            <p className="text-lg text-gray-500 max-w-2xl mx-auto">
              體驗無限制的AI內容創作，享受為專業人士設計的高端工具
            </p>
          </div>

          {/* Hero CTA */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
            <Button size="lg" className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 text-lg font-semibold">
              <Play className="w-5 h-5 mr-2" />
              Start 7-Day Free Trial
            </Button>
            <Button variant="outline" size="lg" className="px-8 py-4 border-2 border-gray-300 hover:border-gray-400 text-gray-700 hover:bg-gray-50 text-lg">
              View Pricing
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-wrap justify-center items-center gap-8 pt-12 text-sm text-gray-500">
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4 text-green-500" />
              <span>7-day free trial</span>
            </div>
            <div className="flex items-center space-x-2">
              <Heart className="w-4 h-4 text-red-500" />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-blue-500" />
              <span>Cancel anytime</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-12 border-t border-b border-gray-100">
        {[
          { number: '10M+', label: 'Content Generated', labelZh: '內容生成量' },
          { number: '50K+', label: 'Active Creators', labelZh: '活躍創作者' },
          { number: '99.9%', label: 'Uptime', labelZh: '正常運行時間' },
          { number: '4.9/5', label: 'User Rating', labelZh: '用戶評分' }
        ].map((stat, index) => (
          <div key={index} className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">{stat.number}</div>
            <div className="text-sm text-gray-600">{stat.label}</div>
            <div className="text-xs text-gray-500">{stat.labelZh}</div>
          </div>
        ))}
      </div>

      {/* Pricing Section */}
      <div className="space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900">
            Choose Your Plan
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Flexible pricing options designed to scale with your creative needs
          </p>
          <p className="text-lg text-gray-500">
            靈活的定價選項，隨您的創意需求擴展
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {pricingTiers.map((tier, index) => (
            <Card key={tier.id} className={`relative overflow-hidden transition-all duration-300 hover:shadow-2xl ${
              tier.popular 
                ? 'border-2 border-blue-500 shadow-xl scale-105 bg-gradient-to-b from-blue-50/50 to-purple-50/50' 
                : 'border border-gray-200 hover:border-gray-300'
            }`}>
              {tier.popular && (
                <div className="absolute -top-0 left-0 right-0 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-center py-2 text-sm font-semibold">
                  {tier.badge} • {tier.badgeZh}
                </div>
              )}
              
              <CardHeader className={`text-center ${tier.popular ? 'pt-8' : 'pt-6'} pb-4`}>
                <div className="space-y-2">
                  <CardTitle className="text-2xl font-bold text-gray-900">
                    {tier.name}
                  </CardTitle>
                  <p className="text-sm text-gray-500">{tier.nameZh}</p>
                  <CardDescription className="text-gray-600 min-h-[2.5rem]">
                    {tier.description}
                  </CardDescription>
                  <p className="text-sm text-gray-500">{tier.descriptionZh}</p>
                </div>

                <div className="pt-4 space-y-2">
                  {tier.originalPrice && (
                    <div className="text-lg text-gray-500 line-through">
                      ${tier.originalPrice}/{tier.period === 'month' ? 'mo' : tier.period}
                    </div>
                  )}
                  <div className="flex items-center justify-center space-x-2">
                    <span className="text-5xl font-bold text-gray-900">
                      {tier.price === 0 ? 'Free' : `$${tier.price}`}
                    </span>
                    {tier.price > 0 && (
                      <span className="text-lg text-gray-500">
                        /{tier.period === 'month' ? 'mo' : tier.period}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-500">{tier.periodZh}</p>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <div className="space-y-3">
                  {tier.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start space-x-3">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                        feature.included 
                          ? (tier.popular ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600')
                          : 'bg-gray-100 text-gray-400'
                      }`}>
                        <Check className="w-3 h-3" />
                      </div>
                      <div className="space-y-1">
                        <span className={`text-sm ${feature.included ? 'text-gray-900' : 'text-gray-500'}`}>
                          {feature.text}
                        </span>
                        <p className="text-xs text-gray-500">{feature.textZh}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <Button 
                  className={`w-full py-3 font-semibold transition-all duration-300 ${
                    tier.current
                      ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                      : tier.popular
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl'
                      : 'bg-gray-900 hover:bg-gray-800 text-white'
                  }`}
                  disabled={tier.current}
                >
                  {tier.buttonText}
                  {!tier.current && <ArrowRight className="w-4 h-4 ml-2" />}
                </Button>
                <p className="text-xs text-center text-gray-500">{tier.buttonTextZh}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Premium Features */}
      <div className="space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl font-bold text-gray-900">
            Premium Features
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Advanced tools and capabilities that set professionals apart
          </p>
          <p className="text-lg text-gray-500">
            讓專業人士脫穎而出的進階工具和功能
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {premiumFeatures.map((feature, index) => (
            <Card key={index} className="group relative overflow-hidden border-0 bg-gradient-to-br from-white to-gray-50/50 hover:shadow-2xl transition-all duration-500 hover:-translate-y-1">
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-5 transition-opacity duration-500" 
                   style={{ background: `linear-gradient(135deg, var(--tw-gradient-stops))` }}></div>
              
              <CardHeader className="space-y-4">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-r ${feature.gradient} flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <div className="space-y-2">
                  <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-gray-800 transition-colors">
                    {feature.title}
                  </CardTitle>
                  <p className="text-sm font-medium text-gray-600">{feature.titleZh}</p>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-2">
                  <p className="text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                  <p className="text-sm text-gray-500">
                    {feature.descriptionZh}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Success Stories */}
      <div className="space-y-12 bg-gradient-to-r from-gray-50 to-blue-50/30 rounded-3xl p-8 md:p-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl font-bold text-gray-900">
            Success Stories
          </h2>
          <p className="text-xl text-gray-600">
            See how professionals transform their workflow with CreaTA Pro
          </p>
          <p className="text-lg text-gray-500">
            看看專業人士如何透過CreaTA Pro改變工作流程
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                      <span className="text-white font-bold text-sm">{testimonial.avatar}</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.role}</p>
                      <p className="text-xs text-blue-600 font-medium">{testimonial.company}</p>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <blockquote className="text-gray-700 italic">
                  "{testimonial.content}"
                </blockquote>
                <p className="text-sm text-gray-500 italic">
                  "{testimonial.contentZh}"
                </p>
                <div className="pt-2 border-t border-gray-100">
                  <Badge className="bg-green-100 text-green-700 border-0">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    {testimonial.metrics}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Feature Comparison Table */}
      <div className="space-y-8">
        <div className="text-center space-y-4">
          <h2 className="text-4xl font-bold text-gray-900">
            Compare Plans
          </h2>
          <p className="text-xl text-gray-600">
            Detailed feature comparison across all plans
          </p>
          <p className="text-lg text-gray-500">
            所有方案的詳細功能比較
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse bg-white rounded-2xl shadow-lg overflow-hidden">
            <thead>
              <tr className="bg-gradient-to-r from-gray-50 to-blue-50/30">
                <th className="text-left p-6 font-bold text-gray-900">Features</th>
                <th className="text-center p-6 font-bold text-gray-600">Starter</th>
                <th className="text-center p-6 font-bold text-blue-600 bg-blue-50/50">Pro</th>
                <th className="text-center p-6 font-bold text-gray-900">Enterprise</th>
              </tr>
            </thead>
            <tbody>
              {comparisonFeatures.map((feature, index) => (
                <tr key={index} className="border-t border-gray-100 hover:bg-gray-50/50 transition-colors">
                  <td className="p-6">
                    <div className="space-y-1">
                      <span className="font-medium text-gray-900">{feature.feature}</span>
                      <p className="text-sm text-gray-500">{feature.featureZh}</p>
                    </div>
                  </td>
                  <td className="text-center p-6 text-gray-600">{feature.starter}</td>
                  <td className="text-center p-6 text-blue-600 bg-blue-50/30 font-semibold">{feature.pro}</td>
                  <td className="text-center p-6 text-gray-900 font-medium">{feature.enterprise}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Final CTA */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-3xl p-8 md:p-12 text-center space-y-8 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full blur-3xl transform translate-x-32 -translate-y-32"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-white rounded-full blur-2xl transform -translate-x-24 translate-y-24"></div>
        </div>
        
        <div className="relative z-10 space-y-6">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold text-white">
              Ready to Transform Your Creativity?
            </h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Join thousands of professionals who've already upgraded their content creation workflow
            </p>
            <p className="text-lg text-white/80 max-w-2xl mx-auto">
              加入數千名已經升級內容創作工作流程的專業人士
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button size="lg" className="px-10 py-4 bg-white text-blue-600 hover:bg-white/90 hover:scale-105 font-bold text-lg shadow-xl transition-all duration-300">
              <Rocket className="w-5 h-5 mr-2" />
              Start Free Trial
            </Button>
            <Button variant="outline" size="lg" className="px-8 py-4 border-2 border-white/30 text-white hover:bg-white/10 backdrop-blur-sm text-lg">
              Schedule Demo
              <Eye className="w-5 h-5 ml-2" />
            </Button>
          </div>
          
          <div className="flex flex-wrap justify-center items-center gap-6 pt-6 text-white/80 text-sm">
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4" />
              <span>7-day free trial • 7天免費試用</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4" />
              <span>No setup fees • 無設定費用</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4" />
              <span>Cancel anytime • 隨時取消</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}