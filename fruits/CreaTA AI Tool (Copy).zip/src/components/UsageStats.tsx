import { Badge } from "./ui/badge"
import { Button } from "./ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Progress } from "./ui/progress"
import { 
  BarChart3, 
  Sparkles, 
  Users, 
  TrendingUp, 
  Calendar,
  Clock,
  Target,
  Crown,
  Zap
} from "lucide-react"

export default function UsageStats() {
  const stats = [
    {
      id: 'content_generation',
      label: 'AI文案生成',
      used: 23,
      total: 50,
      percentage: 46,
      icon: Sparkles,
      color: 'blue',
      trend: '+12%',
      description: '本月已生成 23 篇優質內容'
    },
    {
      id: 'ai_chat',
      label: 'AI助手對話',
      used: 156,
      total: 500,
      percentage: 31,
      icon: Users,
      color: 'green',
      trend: '+8%',
      description: '智能對話次數持續增長'
    },
    {
      id: 'knowledge_queries',
      label: '知識庫查詢',
      used: 34,
      total: 100,
      percentage: 34,
      icon: BarChart3,
      color: 'purple',
      trend: '+25%',
      description: '知識庫使用率大幅提升'
    },
    {
      id: 'image_generation',
      label: 'AI圖片生成',
      used: 8,
      total: 20,
      percentage: 40,
      icon: Zap,
      color: 'orange',
      trend: '+5%',
      description: '視覺內容創作需求穩定'
    }
  ]

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue':
        return {
          bg: 'bg-blue-500',
          text: 'text-blue-600',
          badge: 'bg-blue-50 text-blue-600 border-blue-200'
        }
      case 'green':
        return {
          bg: 'bg-green-500',
          text: 'text-green-600',
          badge: 'bg-green-50 text-green-600 border-green-200'
        }
      case 'purple':
        return {
          bg: 'bg-purple-500',
          text: 'text-purple-600',
          badge: 'bg-purple-50 text-purple-600 border-purple-200'
        }
      case 'orange':
        return {
          bg: 'bg-orange-500',
          text: 'text-orange-600',
          badge: 'bg-orange-50 text-orange-600 border-orange-200'
        }
      default:
        return {
          bg: 'bg-gray-500',
          text: 'text-gray-600',
          badge: 'bg-gray-50 text-gray-600 border-gray-200'
        }
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
            <BarChart3 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1>使用情況</h1>
            <p>查看您的 AI 功能使用統計與趨勢分析</p>
          </div>
        </div>
      </div>

      {/* Current Plan */}
      <Card className="border-apple shadow-apple">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <Badge className="bg-blue-50 text-blue-600 border-blue-200">免費版</Badge>
                <span>當前方案</span>
              </CardTitle>
              <CardDescription className="mt-2">
                您正在使用 CreaTA 免費版，每月提供基礎 AI 功能額度
              </CardDescription>
            </div>
            <Button className="gradient-primary">
              <Crown className="w-4 h-4 mr-2" />
              升級 Pro
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Usage Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {stats.map((stat) => {
          const colors = getColorClasses(stat.color)
          const Icon = stat.icon
          
          return (
            <Card key={stat.id} className="border-apple shadow-apple hover:shadow-floating transition-all duration-300">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${colors.bg} rounded-xl flex items-center justify-center shadow-sm`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{stat.label}</CardTitle>
                      <CardDescription>{stat.description}</CardDescription>
                    </div>
                  </div>
                  <Badge className={colors.badge}>
                    <TrendingUp className="w-3 h-3 mr-1" />
                    {stat.trend}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-gray-900">
                      {stat.used}
                      <span className="text-sm font-normal text-gray-500 ml-1">/ {stat.total}</span>
                    </span>
                    <span className="text-sm font-medium text-gray-600">
                      {stat.percentage}% 已使用
                    </span>
                  </div>
                  
                  <Progress 
                    value={stat.percentage} 
                    className="h-3"
                  />
                  
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>剩餘 {stat.total - stat.used} 次</span>
                    <span>本月重置於 12月1日</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Usage History */}
      <Card className="border-apple shadow-apple">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-gray-600" />
            <CardTitle>使用歷史</CardTitle>
          </div>
          <CardDescription>
            查看過去 30 天的使用趨勢
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Placeholder for usage chart */}
            <div className="h-64 bg-gray-50 rounded-xl flex items-center justify-center">
              <div className="text-center space-y-2">
                <BarChart3 className="w-12 h-12 text-gray-400 mx-auto" />
                <p className="text-sm text-gray-500">使用趨勢圖表</p>
                <p className="text-xs text-gray-400">圖表功能開發中</p>
              </div>
            </div>
            
            {/* Recent Activity */}
            <div className="border-t pt-4">
              <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                <Clock className="w-4 h-4 mr-2 text-gray-600" />
                近期活動
              </h4>
              <div className="space-y-3">
                {[
                  { action: 'AI文案生成', time: '2小時前', count: 3 },
                  { action: 'AI助手對話', time: '4小時前', count: 12 },
                  { action: '知識庫查詢', time: '昨天', count: 5 },
                  { action: 'AI圖片生成', time: '2天前', count: 2 }
                ].map((activity, index) => (
                  <div key={index} className="flex items-center justify-between py-2 px-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm font-medium text-gray-900">{activity.action}</span>
                    </div>
                    <div className="flex items-center space-x-3 text-sm text-gray-500">
                      <span>{activity.count} 次</span>
                      <span>•</span>
                      <span>{activity.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upgrade Suggestion */}
      <Card className="border-apple shadow-apple bg-gradient-to-br from-purple-50 to-pink-50">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center shadow-lg">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">需要更多功能？</h3>
                <p className="text-sm text-gray-600 mt-1">
                  升級到 Pro 版本，享受無限 AI 功能與專業模板
                </p>
              </div>
            </div>
            <Button className="gradient-primary shadow-lg">
              <Crown className="w-4 h-4 mr-2" />
              立即升級
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}